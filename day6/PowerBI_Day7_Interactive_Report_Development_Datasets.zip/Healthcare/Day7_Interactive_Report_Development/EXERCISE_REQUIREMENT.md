# Day 7 — Interactive Report Development: Healthcare Payor
## Business Scenario
Build an interactive healthcare payor report that lets a business user move from overall medical-cost performance to line of business, provider and member-level analysis.

## Required Pages
1. Payor Executive Overview
2. Provider / LOB Analysis
3. Member / Claim Detail

## Required Interactions
- Drill-down: Year → Quarter → Month on claims cost/revenue trends.
- Drill-through: LOB/Payer → Provider Analysis.
- Drill-through: Provider → Member / Claim Detail.
- Bookmarks: Cost View vs Utilization View.
- Buttons: Home, Back, Reset Filters and navigation.
- Dynamic title for selected LOB, Payer or Region.
- Report-page tooltip for provider/member or cost detail.
- Slicers: Date, LOB, Payer, Region, Specialty; sync relevant slicers.

## KPIs
Total Claims Cost, Claim Count, Member Count, PMPM, Avg Claim Cost, Revenue, Medical Cost Ratio, YoY Cost Growth.

## Explain & Demonstrate
Explain the intended user journey and how the interactions support investigation of cost and utilization.

## Validation
Validate at least 5 KPIs independently; test drill-through, bookmarks, Reset Filters, Back, and dynamic titles. Record 10 user-journey test cases.
