# Day 7 — Interactive Report Development: Retail
## Business Scenario
Build an interactive Sales & Customer 360 report that lets executives move from overall sales performance to salesperson, customer, product and order-level detail.

## Required Pages
1. Executive Sales Overview
2. Salesperson Analysis
3. Customer / Order Detail

## Required Interactions
- Drill-down: Year → Quarter → Month on the sales trend.
- Drill-through: Executive/Salesperson → Salesperson Analysis.
- Drill-through: Customer → Customer / Order Detail.
- Bookmarks: Executive View vs Analysis View.
- Buttons: Home, Back, Reset Filters and page navigation.
- Dynamic title reflecting selected Region, Category or Salesperson.
- Report-page tooltip for Product/Region detail.
- Slicers: Date, Region, Category, Segment; sync relevant slicers across pages.

## KPIs
Revenue, Profit, Margin %, Orders, Customers, AOV, YoY Growth.

## Explain & Demonstrate
Explain the intended user journey, how drill-down, drill-through, bookmarks, buttons, tooltips and filters support it, and why the interactions were designed this way.

## Validation
Validate at least 5 KPIs independently; test navigation, drill-through, Reset Filters, bookmark states and dynamic titles. Record 10 user-journey test cases.
