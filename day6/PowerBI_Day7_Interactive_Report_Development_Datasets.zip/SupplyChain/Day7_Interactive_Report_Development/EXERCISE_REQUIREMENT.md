# Day 7 — Interactive Report Development: Supply Chain
## Business Scenario
Build an interactive Supply Chain Command Center that lets operations leaders move from network-level inventory and service performance to supplier and warehouse detail.

## Required Pages
1. Supply Chain Executive
2. Supplier Analysis
3. Warehouse / Inventory Detail

## Required Interactions
- Drill-down: Year → Quarter → Month on inventory/shipments.
- Drill-through: Supplier → Supplier Analysis.
- Drill-through: Warehouse → Warehouse / Inventory Detail.
- Bookmarks: Inventory View vs Logistics View.
- Buttons: Home, Back, Reset Filters and navigation.
- Dynamic title for selected Region, Supplier or Warehouse.
- Report-page tooltip for supplier or warehouse performance.
- Slicers: Date, Region, Supplier, Warehouse, Product Category; sync relevant slicers.

## KPIs
Inventory Value, Inventory Units, PO Value, Open PO Value, Supplier Count, Stock-Out %, On-Time Delivery %, Avg Transit Days.

## Explain & Demonstrate
Explain the intended operations user journey, how the interactions help identify exceptions, and why the drill paths and navigation were designed this way.

## Validation
Validate at least 5 KPIs independently; test drill-through, bookmarks, Reset Filters, Back and dynamic titles. Record 10 user-journey test cases.
