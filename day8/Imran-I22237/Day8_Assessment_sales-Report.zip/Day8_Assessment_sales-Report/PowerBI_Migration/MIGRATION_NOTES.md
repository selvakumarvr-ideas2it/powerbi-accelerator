# Sales Overview — Cognos → Power BI migration notes

**Source:** `claude-powerbi_Cognos/SalesOverview_report.xml` (Cognos Analytics report spec, schema 16.0) + 6 CSVs
**Target:** `SalesOverview.pbip` (Power BI Project: TMDL semantic model + PBIR report)
**Built:** 30 Sep 2026

## 1. How to open

1. Open **`SalesOverview.pbip`** in Power BI Desktop (a 2025-or-later release that supports PBIR / TMDL projects).
2. Desktop loads the model from the CSVs through the **`DataFolder`** parameter, which is set to
   `C:\Users\naveenkumar\Documents\Powerbi\Projects\Assessment_sales-Report\claude-powerbi_Cognos\`.
   If you move the CSVs, change it under *Transform data → Edit parameters*, then **Refresh**.
3. Open **DAX query view**, paste `Verification_Query.dax` and run it. All 31 rows should show **Match = True**.
4. **Save** (Ctrl+S). Desktop then writes its own metadata into the project.

## 2. What is in the folder

| Path | Contents |
|---|---|
| `SalesOverview.pbip` | Project file — open this |
| `SalesOverview.SemanticModel/` | TMDL model: 9 tables, 5 relationships, 52 measures |
| `SalesOverview.Report/` | PBIR report: 3 report pages, 6 tooltip pages, 3 bookmarks, "Forest Lavender" theme |
| `Verification_Query.dax` | Checks the migrated numbers against values calculated independently from the CSVs |
| `MIGRATION_NOTES.md` | This file |

## 3. Cognos → Power BI mapping

### Data module → semantic model
| Cognos | Power BI |
|---|---|
| Data module `claude-powerbi` (6 query subjects) | 6 import tables loaded with Power Query from the CSVs (typed with the en-US culture) |
| 5 joins, dimension 1..n → FactSales | 5 many-to-one, single-direction relationships on the same keys |
| DimCustomer.RegionKey / DimSalesperson.RegionKey left unjoined | Kept **unrelated** and hidden, with a description on each column saying why |
| `Year Month` / `YearMonthSort` calculated in the query | Power Query columns on DimDate; `Year Month` sorts by `YearMonthSort`. DimDate is marked as the date table |
| Prompt `pYear` (integer, default 2026) | Disconnected **`Year Selection`** table + synced single-select slicer. It defaults to **"Latest year"**, which always follows the newest year in DimDate instead of a hard-coded 2026 |
| Prompt `pMetric` (1 = Sales, 2 = Profit) | Disconnected **`Trend Metric`** table + a Sales/Profit button slicer. The checklist said field parameter; I used a disconnected table because it matches the original model the Cognos header describes, and because a field parameter's visual binding can't be written reliably by hand |

### Data items → DAX measures (folder `_Measures`)
| Cognos data item | DAX measure(s) |
|---|---|
| Sales/Profit/Cost CY = `total(case when Year = pYear …)` | `Sales CY`, `Profit CY`, `Cost CY` = `CALCULATE([Base], DimDate[Year] = [Selected Year])` |
| Sales/Profit/Cost LY | `… LY` (same, with `[Prior Year]`) |
| Margin CY / LY = `Profit / nullif(Sales,0)` | `Margin CY`, `Margin LY` (`DIVIDE`) |
| `*YoY` = `(CY-LY)/nullif(LY,0)`, format `+0.00%`, missing = "n/a" | `… YoY %` (number) + `… YoY Label` (text, shows **n/a** when blank) |
| `Margin YoY pts` = `(Margin CY − Margin LY)×100`, "+0.0 pts" | `Margin YoY pts` + `Margin YoY Label` |
| `Header Subtitle` | `Header Subtitle` ("Fiscal year 2026 · compared with 2025") |
| `Sales Rank` + post-aggregation filter `<= 5` | `Sales Rank CY` (RANKX over products) → `Sales CY Top 5`, `Sales LY Top 5` |
| `Trend Value` | `Trend Value` (Sales or Profit, selected year and prior year) + dynamic `Trend Title` |
| *(new)* | `Units …`, `Transactions`, `… Change`, badge colour measures, page title measures |

### Layout → visuals (page **Sales Overview**, 1280×720)
| Cognos object | Power BI visual |
|---|---|
| 80px forest-green sidebar (empty) | Same sidebar, now holding **navigation buttons** (Overview / Products / Regions) plus **Reset** and **Info** |
| Title "Overview" + `sHeaderSubtitle` | Text box + dynamic subtitle (button text driven by a measure) |
| `promptYear` dropdown | Year slicer (dropdown, single select, synced across pages) |
| 4 KPI singletons (value + lime YoY badge + "vs. last year") | 4 KPI tiles: value card, YoY badge coloured by a measure, "vs. last year" label, **report-page tooltip** |
| `ctRevenueBreakdown` crosstab (Region > Segment) | **Decomposition tree**, restoring the original Power BI visual. It opens with Region expanded and West → Segment |
| `chSegment`, `chRegion` (horizontal bars, This year / Last year) | Clustered bar charts, same colours (#29654B / #C4CAEE), sorted by Sales CY descending, $K axis |
| `chTrend` area + `promptMetric` radio | Area chart by Year Month + Sales/Profit slicer (the slicer only affects the trend chart) |
| `chTopProducts` (rank ≤ 5) | Clustered bar chart driven by `Sales CY Top 5` / `Sales LY Top 5` |
| CSS palette | Custom theme `ForestLavender.json` (canvas #F6F5F3, borders #E6E4DF, Segoe UI) |

## 4. Enhancements (not in the Cognos report)

- **Product Analysis** page: 4 KPIs (Sales, Profit, Margin, Units), monthly this-year vs last-year columns, sales by region, customer table, segment donut.
  It is a **drill-through target** on `DimProduct[Product]` (right-click a product → Drill through), and it's also reachable from the nav, where it shows "All products".
- **Region & Salesperson** page: drill-through on `DimRegion[Region]`, with salesperson bars, monthly line, salesperson performance table and product-category donut.
- **Tooltip pages:** one per KPI (this year, last year, change, YoY) and one breakdown tooltip on every bar, donut and the decomposition tree.
- **Bookmarks:** *Reset view* (Year → Latest year, Trend → Sales, on all pages), *Info · show* / *Info · hide* (how-to-read panel on the Overview page).
- **Back** buttons on the drill-through pages. Pages are synced through the Year slicer sync group.
- **YoY badges coloured by direction:** lime = favourable, soft red = unfavourable, grey = n/a. **Cost is inverted**, so a cost increase shows red. Cognos showed lime for every value, including negative ones.

## 5. Reconciliation (expected values, computed from the CSVs)

| KPI | 2026 (default) | 2025 selected |
|---|---:|---:|
| Sales | $1,202,147 (+3.63%) | $1,160,027 (n/a) |
| Profit | $357,452 (-2.16%) | $365,351 (n/a) |
| Profit margin | 29.7% (-1.8 pts) | 31.5% (n/a) |
| Cost | $844,695 (+6.29%) | $794,675 (n/a) |
| Units | 3,960 (+7.17%) | 3,695 (n/a) |

**Revenue by segment (2026)**

| Item | This year | Last year |
|---|---:|---:|
| SMB | $463,490 | $464,987 |
| Consumer | $392,493 | $392,258 |
| Enterprise | $346,164 | $302,781 |

**Revenue by region (2026)**

| Item | This year | Last year |
|---|---:|---:|
| West | $314,889 | $282,010 |
| North | $314,658 | $291,152 |
| South | $299,537 | $289,508 |
| East | $273,064 | $297,356 |

**Top 5 products (2026)**

| Item | This year | Last year |
|---|---:|---:|
| Keyboard | $140,619 | $98,333 |
| Headset | $136,440 | $136,112 |
| Mouse | $128,580 | $112,876 |
| Laptop | $127,856 | $104,007 |
| Tablet | $124,096 | $144,600 |

Historical trend (2025–2026, 24 months): Sales total **$2,362,174**, Profit total **$722,803**.

## 6. Differences from Cognos and known limitations

1. **Future-dated rows are included** (you chose this). FactSales runs to 31 Dec 2026, so the 2026 figures include Oct–Dec transactions dated after today. That matches Cognos. To exclude them later, filter FactSales in Power Query on `DateKey <= today`.
2. **"Latest year" follows the data.** If a 2027 row arrives, the default flips to 2027 automatically, even if it's a single future-dated row.
3. **Decomposition tree vs crosstab.** A decomposition tree shows one expanded path per level, so it can't show every Region × Segment cell at once the way the crosstab did. The saved expansion (West → Segment) is fixed; West leads North by only about $231 in 2026, and in 2025 East is first. If you need the full grid, swap the visual for a matrix (Region > Segment rows, Sales CY values).
4. **KPI tiles are centred.** The classic card visual centres its value, while Cognos was left-aligned. Everything else (sizes, colours, formats) follows the spec.
5. **Data quality in the source:** 500 of 1,500 rows (33%) have negative profit. Profit always equals Sales − Cost, so it's consistent, but please confirm with the data owner that this is expected.
6. **Written as source files and schema-checked, but not yet opened in Desktop.** Every PBIR file was checked against Microsoft's published JSON schemas, every formatting property against the Power BI theme schema, every field reference against the model, and the TMDL was loaded successfully by the Power BI modeling tools. The report has **not** been opened in Power BI Desktop yet, so do the checks below on first open.
7. The report theme is set as a custom theme only, with no base theme. If Desktop asks for a theme on open, re-apply `StaticResources/RegisteredResources/ForestLavender.json` via *View → Themes → Browse for themes*.

## 7. First-open checklist (about 5 minutes)

- [ ] Refresh succeeds (DataFolder path correct)
- [ ] `Verification_Query.dax`: all rows Match = True
- [ ] Overview: Year slicer shows "Latest year"; KPI values match section 5; badges coloured correctly (Cost +6.29% is red)
- [ ] Switch Year to 2025: YoY badges show n/a (grey); trend shows only 2025 data
- [ ] Trend slicer Sales ↔ Profit changes only the trend chart and its title
- [ ] Hover a KPI and a bar: the custom tooltips appear
- [ ] Right-click a product in Top 5 → Drill through → Product Analysis; Back returns
- [ ] Right-click a region → Drill through → Region & Salesperson
- [ ] Info → panel shows; Close hides it. Reset → Year returns to Latest year and Trend to Sales
- [ ] Decomposition tree opens expanded; if not, expand Region → Segment once and save
