# Cognos → Power BI migration: complex_sales_report.xml

## How to open
1. Extract the zip, e.g. to `C:\Users\naveenkumar\Documents\Powerbi\Projects\Cognos_Sales\`.
2. Copy the three CSVs in `Data\` to `C:\Users\naveenkumar\Documents\Powerbi\Data\Cognos_Sales\`. That is the default value of the `DataFolder` parameter. If you use another folder, change the parameter in Transform data → Manage parameters.
3. Before opening, turn on **File → Options → Preview features → Power BI Project (.pbip) save option** and **Store reports using enhanced metadata format (PBIR)**. Then open `Cognos_Sales.pbip`.
4. Click **Refresh**, check the numbers below, then File → Save As → `.pbix`.

## Cognos → Power BI mapping
| Cognos | Power BI | Note |
|---|---|---|
| query FactSales | table `FactSales` | `DateKey` is derived in Power Query as OrderYear×100+OrderMonth. The Cognos query has no key to DimDate. |
| query DimProduct | table `DimProduct` + hierarchy Category > ProductLine > ProductName | |
| query DimDate | table `DimDate` (monthly grain) + hierarchy Year > Quarter > Month | Adds MonthYear (sorted by DateKey), YearQuarter (sorted), MonthStart |
| Total Revenue / Total Cost / Total Quantity (`aggregate="total"`) | `SUM` measures | |
| Gross Profit = Revenue − Cost | `[Total Revenue] - [Total Cost]` | Row-level vs aggregate subtraction gives the same result for SUM. |
| Net Revenue = Revenue − Discount | `[Total Revenue] - [Total Discount]` | **Assumes Discount is a currency amount.** If the real Cognos Discount is a rate, this measure is wrong. |
| Avg Unit Price (`aggregate="average"` of Price) | `Avg Unit Price (Cognos)` = AVERAGE(Price) **and** `Avg Unit Price (Weighted)` = Revenue ÷ Quantity | See the "pricing" note below. |
| page Revenue Overview: list SalesDetail, vizColumn RevenueByRegion | table (Month × Region × Product) + **sorted horizontal bar** | Plus KPI tiles |
| page Product Analysis: crosstab ProductMatrix, vizPie RevenueByLine | matrix (Category > Line > Product) + **sorted bar instead of pie** | 12 product lines: a pie that size can't be read |
| page Trend: vizLine MonthlyTrend, list CalendarDetail | line (Revenue + Gross Profit, same $ axis) + calendar table | |

Added, not in Cognos: gross margin %, YoY (only when one year is selected), product rank, dynamic titles, synced Year/Region/Category slicers, reset button, page navigation.

## Design decisions to review
- **DimDate is not marked as a date table.** Its grain is monthly because the fact table has no day. Power BI requires contiguous daily dates to mark a date table. Time intelligence is therefore handled by the explicit `Revenue PY` measure (same months, prior year) instead of SAMEPERIODLASTYEAR.
- **Pricing.** The Cognos average (simple AVERAGE of row prices) gives $377.61 for 2025. The quantity-weighted price gives $213.91. The simple average over-weights expensive, low-quantity bike lines. Only the weighted measure is on the visuals. The Cognos version is kept for parity checks.
- **Region is a fact column**, as in Cognos. If regions gain attributes (manager, country), move them to a DimRegion table.
- **Visual field bindings were inferred.** The XML only names each visual and its query. It doesn't say which fields go on axes, rows or values.

## KPI validation (computed with Python from the CSVs)
| KPI | 2024 | 2025 | All years |
|---|---|---|---|
| Total Revenue | $3,265,788.13 | $3,355,641.90 | $6,621,430.03 |
| Total Cost | $1,898,892.87 | $1,954,529.12 | $3,853,421.99 |
| Total Discount | $125,825.92 | $117,153.29 | $242,979.21 |
| Net Revenue | $3,139,962.21 | $3,238,488.61 | $6,378,450.82 |
| Gross Profit | $1,366,895.26 | $1,401,112.78 | $2,768,008.04 |
| Gross Margin % | 42% (41.86%) | 42% (41.75%) | 42% |
| Units | 15,527 | 15,687 | 31,214 |
| Order lines | 3,216 | 3,324 | 6,540 |
| Avg Unit Price (Cognos) | $373.85 | $377.61 | $375.76 |
| Avg Unit Price (Weighted) | $210.33 | $213.91 | $212.13 |
| Revenue YoY | — (no prior year) | +3% (+2.75%) | — (select one year) |

## Test cases
1. Open the report. The Year slicer shows 2025, and the Total Revenue tile shows $3,355,641.90.
2. Clear the Year slicer. The Revenue YoY tile shows "—" and the note says "Select one year for YoY". The tile must never show (Blank) or a false +100%.
3. Select 2024. Revenue YoY shows "—" and the note says "No prior year in data".
4. 2025, Revenue by Region: bars are sorted North $863,291.95 > East $816,188.39 > South $656,957.77 > West $564,981.68 > Central $454,222.11.
5. Hover West (2025). The tooltip shows Revenue YoY −2%. West is the only region that declined.
6. Product Analysis, 2025: the top product line is Road Bikes at $682,028.16. Expand Bikes → Road Bikes: Carbon Road Pro is rank 1 at $331,596.99.
7. Trend, 2025, calendar table: Jun 2025 Revenue YoY is −6% (Jun 2025 $289,293.48 vs Jun 2024 $306,561.25).
8. Select Region = West on Overview, then go to Trend. The Region slicer still shows West (sync group).
9. Click Reset filters. All slicers clear, and the YoY tile goes to "—".
10. Page buttons: each button opens its page, and the active page's button is charcoal. In Desktop, use Ctrl+click while editing.
