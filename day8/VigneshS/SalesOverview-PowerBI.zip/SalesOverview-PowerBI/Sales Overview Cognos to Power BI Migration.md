# Sales Overview: Cognos to Power BI Migration

Oct 5, 2026 · @Vignesh

The Cognos Sales Overview report is rebuilt in Power BI. The logic reconciliation is clean: 158 of 158 checks match, with zero variance. Sign-off waits on three items: a first open in Power BI Desktop, a live DAX check, and a production data source.

| Stage | Result | Status |
| --- | --- | --- |
| Legacy inventory | 1 report, 7 queries, 2 prompts, 9 visual containers, 6 tables | Closed |
| Metric mapping | Every Cognos data item mapped; 15 helper measures added | Closed |
| Prompts and filters | 2 prompts become slicers; 4 new filters and a drill-through added | Closed |
| DAX recreation | 31 measures in the FactSales table | Closed |
| Reconciliation | 158 / 158 logic checks match; live model run pending | In progress |
| Gaps and risks | 12 items, 3 high | In progress |

Project: `Documents\SalesOverview-PowerBI` (SalesOverview.pbip, Optum Healthcare theme).

## Legacy inventory

The source is one Cognos Analytics report, Sales Overview (spec schema 16.0, `SalesOverview.report.xml`). It has 1 page, 7 queries, 2 prompts and 9 data containers, all built on the data module `claude-powerbi` over six CSV tables. No MicroStrategy objects were supplied, so this migration covers Cognos only.

**Data module (6 query subjects, 1,500 sales rows)**

| Query subject | Rows | Key columns | Role |
| --- | --- | --- | --- |
| FactSales | 1,500 | SalesID, DateKey, CustomerKey, ProductKey, SalespersonKey, RegionKey | Fact: Quantity, SalesAmount, CostAmount, ProfitAmount |
| DimDate | 730 | DateKey | Calendar 2025-01-01 to 2026-12-31 |
| DimCustomer | 50 | CustomerKey | Segment (Enterprise, SMB, Consumer), home RegionKey |
| DimProduct | 10 | ProductKey | Product, Category |
| DimRegion | 4 | RegionKey | North, South, East, West |
| DimSalesperson | 10 | SalespersonKey | Salesperson, home RegionKey |

**Queries**

| Query | Feeds | Grain | Filter |
| --- | --- | --- | --- |
| qYears | Year prompt values | Year | none |
| qKPI | 4 KPI cards, header subtitle | Total | Year in pYear-1 to pYear |
| qBreakdown | Revenue breakdown crosstab | Region > Segment | Year = pYear |
| qSegment | Revenue by segment bar | Segment | Year in pYear-1 to pYear |
| qRegion | Revenue by region bar | Region | Year in pYear-1 to pYear |
| qTrend | Historical trends area | Year Month | Year in pYear-1 to pYear |
| qTopProducts | Top 5 products bar | Product | Year in pYear-1 to pYear, then rank <= 5 |

**Layout components**

| Cognos component | Count | Power BI equivalent |
| --- | --- | --- |
| Singleton text (title, subtitle, KPI values) | 5 | Card visuals + text boxes |
| Value prompt (dropdown, radio group) | 2 | Slicers in the left filter panel |
| Crosstab (Region / Segment) | 1 | Decomposition tree |
| Combination chart, horizontal bar | 3 | Clustered bar charts |
| Combination chart, area | 1 | Area chart |
| Static text and layout tables | many | Text boxes, shapes, the Optum theme |

## Metric mapping

Every Cognos data item across the 7 queries maps to a Power BI measure or column; none were dropped. The measures live on the FactSales table, grouped by display folder.

| Cognos data item | Cognos expression (short) | Power BI object | Format |
| --- | --- | --- | --- |
| Sales CY | total(case Year = pYear then SalesAmount) | FactSales\[Sales CY\] | $#,0 |
| Sales LY | same, Year = pYear - 1 | FactSales\[Sales LY\] | $#,0 |
| Profit CY / LY | same on ProfitAmount | FactSales\[Profit CY\], \[Profit LY\] | $#,0 |
| Cost CY / LY | same on CostAmount | FactSales\[Cost CY\], \[Cost LY\] | $#,0 |
| Margin CY / LY | Profit / nullif(Sales, 0) | FactSales\[Margin CY\], \[Margin LY\] | 0.0% |
| Sales / Profit / Cost YoY | (CY - LY) / nullif(LY, 0) | FactSales\[Sales YoY\], \[Profit YoY\], \[Cost YoY\] | +0.00% |
| Margin YoY pts | (Margin CY - Margin LY) × 100 | FactSales\[Margin YoY pts\] | +0.0 pts |
| Header Subtitle | 'Fiscal year ' + pYear + ' · compared with ' + (pYear - 1) | FactSales\[Header Subtitle\] | text |
| Sales CY Top 5 / Sales LY Top 5 | rank(Sales CY) <= 5, post-aggregation | FactSales\[Sales CY Top 5\], \[Sales LY Top 5\] | $#,0 |
| Sales Rank | rank(Sales CY Top 5) | Inside the Top 5 measures (RANKX) | not shown |
| Trend Value | case pMetric 2 then Profit else Sales | FactSales\[Trend Value\] | $#,0 |
| Year Month | Month + ' ' + Year | DimDate\[Year Month\] (Power Query) | text |
| YearMonthSort | Year × 100 + MonthNo | DimDate\[YearMonthSort\], sort column | hidden |
| Region, Segment, Product, Year | model columns | DimRegion\[Region\], DimCustomer\[Segment\], DimProduct\[Product\], DimDate\[Year\] | text / int |

**Added in Power BI (no Cognos source)**

| Power BI object | Why |
| --- | --- |
| Selected Year | Reads the Year slicer; replaces the pYear prompt value |
| Sales / Profit / Cost / Margin YoY Label and Badge | Text for the yellow (now orange) badge: shows "n/a" when there is no prior year |
| Quantity CY / LY / YoY / YoY Badge | Units sold card on the Product Overview page |
| Product Title, Product Subtitle | Header of the Product Overview drill-through page |

## Prompts and filters

Both Cognos prompts became slicers on disconnected tables, so the measures still compare the selected year against the year before. Every detail filter is now applied inside a measure rather than on the query.

| Cognos item | Type and default | Power BI replacement | Behaviour |
| --- | --- | --- | --- |
| pYear | Integer value prompt, dropdown, default 2026, values from qYears | 'Year Selector'\[Year\] slicer (calculated table, single select) read by \[Selected Year\] | No selection falls back to the latest year in DimDate (2026) |
| pMetric | Integer radio group, 1 = Sales, 2 = Profit, default 1 | 'Trend Metric'\[Metric\] slicer (DATATABLE: Sales, Profit) read by \[Trend Value\] | No selection shows Sales |
| Year in pYear - 1 to pYear | Detail filter on qKPI, qSegment, qRegion, qTrend, qTopProducts | CALCULATE(..., DimDate\[Year\] = y) in each CY / LY measure; KEEPFILTERS(DimDate\[Year\] IN {y - 1, y}) in \[Trend Value\] | Same rows; the year filter lives in the measure, so other visuals are not limited |
| Year = pYear | Detail filter on qBreakdown | \[Sales CY\] used as the decomposition tree's value | Same |
| Sales Rank <= 5 | Post-aggregation detail filter on qTopProducts | RANKX(ALL(DimProduct\[Product\]), \[Sales CY\]) <= 5 inside the Top 5 measures | Ranking ignores other product filters; ties can return more than 5 |

**New filters (requested, no Cognos source)**

| Filter | Page | Selection |
| --- | --- | --- |
| Region | Sales Overview, Product Overview | Multi |
| Segment | Sales Overview, Product Overview | Multi |
| Category | Sales Overview | Multi |
| Product | Sales Overview | Multi |
| Drill-through on DimProduct\[Product\] | Product Overview (hidden page) | From Top 5 products or the breakdown tree; keeps all filters |

## DAX recreation

The model holds 31 measures, built from four patterns below; Profit, Cost and Quantity repeat the Sales pattern on their own column. All are in `SalesOverview.SemanticModel/definition/tables/FactSales.tmdl`.

| Pattern | Measures | Replaces in Cognos |
| --- | --- | --- |
| Year-pinned sum | Sales / Profit / Cost / Quantity CY and LY | case-when on pYear + total() |
| Safe ratio (DIVIDE) | Margin CY / LY, all YoY measures | nullif(x, 0) division |
| Rank filter | Sales CY Top 5, Sales LY Top 5 | rank() + post-aggregation filter |
| Disconnected switch | Trend Value | pMetric case expression |

```
Selected Year =
SELECTEDVALUE ( 'Year Selector'[Year],
    CALCULATE ( MAX ( DimDate[Year] ), REMOVEFILTERS ( DimDate ) ) )

Sales CY =
VAR y = [Selected Year]
RETURN CALCULATE ( SUM ( FactSales[SalesAmount] ), DimDate[Year] = y )

Sales LY =
VAR y = [Selected Year] - 1
RETURN CALCULATE ( SUM ( FactSales[SalesAmount] ), DimDate[Year] = y )

Sales YoY = DIVIDE ( [Sales CY] - [Sales LY], [Sales LY] )

Margin CY = DIVIDE ( [Profit CY], [Sales CY] )

Margin YoY pts =
IF ( NOT ISBLANK ( [Margin LY] ), ( [Margin CY] - [Margin LY] ) * 100 )

Sales CY Top 5 =
IF ( ISINSCOPE ( DimProduct[Product] )
        && RANKX ( ALL ( DimProduct[Product] ), [Sales CY],, DESC ) <= 5,
    [Sales CY] )

Trend Value =
VAR y = [Selected Year]
VAR m = SELECTEDVALUE ( 'Trend Metric'[Metric], "Sales" )
RETURN IF ( m = "Profit",
    CALCULATE ( SUM ( FactSales[ProfitAmount] ), KEEPFILTERS ( DimDate[Year] IN { y - 1, y } ) ),
    CALCULATE ( SUM ( FactSales[SalesAmount] ), KEEPFILTERS ( DimDate[Year] IN { y - 1, y } ) ) )
```

## Reconciliation

All 158 checks match with zero variance: the Cognos query logic and the DAX measure logic give identical results for pYear 2026 and 2025. Both were computed independently from the same six CSVs. Each engine followed its own rules: Cognos used detail filter then total(case when), DAX used filter context, CALCULATE year pin and DIVIDE.

| Area | Checks (2026) | Checks (2025) | Variance |
| --- | --- | --- | --- |
| KPI cards (CY, LY, YoY, margin) | 11 | 11 | 0 |
| Revenue by region (CY, LY) | 8 | 8 | 0 |
| Revenue by segment (CY, LY) | 6 | 6 | 0 |
| Revenue breakdown (Region × Segment) | 12 | 12 | 0 |
| Top 5 products (set + values) | 6 | 6 | 0 |
| Historical trend (Sales and Profit by month) | 48 | 24 | 0 |

**KPI values, pYear 2026**

| KPI | This year | Last year | Change |
| --- | --- | --- | --- |
| Sales | $1,202,146.99 | $1,160,026.63 | +3.63% |
| Profit | $357,452.09 | $365,351.24 | -2.16% |
| Cost | $844,694.90 | $794,675.39 | +6.29% |
| Profit margin | 29.7% | 31.5% | -1.8 pts |

For pYear 2025 there is no 2024 data, so every LY and YoY value is blank in both tools. Cognos prints "n/a" and Power BI shows the same through the badge measures. The 2025 Top 5 is Tablet, Router, Headset, Monitor, Dock; 2026 is Keyboard, Headset, Mouse, Laptop, Tablet. Neither year has a tie at rank 5.

This is a logic reconciliation; the live model run is still open (see Gaps and risks). To close it, run `Migration/Reconciliation_Checks.dax` in Power BI Desktop's DAX query view. Then compare the results with `Migration/Reconciliation_Expected.csv`; both files are in the project folder.

## Gaps and risks

Three high items block sign-off. The report has not yet been opened in Power BI Desktop. The live DAX reconciliation has not been run. The data source still points at a local CSV folder.

| Gap or risk | Severity | Impact | Action | Status |
| --- | --- | --- | --- | --- |
| Report never opened in Power BI Desktop | High | The model (TMDL) and parts of the report were written by hand; a load error is possible | Open SalesOverview.pbip, refresh, and note any error | Open |
| Live reconciliation not run | High | The 158 matches are logic-level; the model's own results are unconfirmed | Run Migration/Reconciliation\_Checks.dax and compare with the expected CSV | Open |
| Data source is a local CSV path (DataFolder parameter) | High | Refresh fails in the Power BI service; no schedule or gateway | Repoint to the production source (warehouse or SharePoint) before publishing | Open |
| Drill-through link written by hand | Medium | Right-click "Drill through" may not appear | Test it; if missing, drag DimProduct\[Product\] into the page's Drill-through well | Open |
| Year default differs | Medium | Cognos defaults to a fixed 2026; Power BI defaults to the latest year in DimDate, so it moves to 2027 when 2027 dates load | Confirm the rolling default is wanted | Open |
| Top 5 ignores Category and Product slicers when ranking | Medium | With a Category selected, fewer than 5 products can show (no Cognos baseline: these slicers are new) | Decide: rank within the filtered set (ALLSELECTED) or across all products | Open |
| 500 of 1,500 sales rows (33%) have negative profit | Medium | Margin looks low; it may be a source data issue rather than a business fact | Confirm with the data owner | Open |
| Security not migrated | Medium | The Cognos spec carries no permissions; any folder or data security in Cognos is lost | List Cognos access rules; add row-level security if needed | Open |
| Sales region vs customer home region | Low | They agree on only 23% of rows; users may expect the customer's region | Kept unrelated as the Cognos notes require; label it "Sales region" in the report | Open |
| Breakdown is a decomposition tree, not a crosstab | Low | Users expand levels by clicking; exports differ from the Cognos crosstab | Add a matrix visual if a printable crosstab is needed | Open |
| MicroStrategy assets | Low | None supplied, so out of scope | Send any MicroStrategy reports to start their inventory | Closed |
| Leftover theme files (ForestLavender, CY24SU10) | Low | Unused; no effect on the report | Delete from StaticResources when convenient | Open |
