---
name: centene-powerbi-dashboard
description: Use when building, modifying, reviewing or QA-ing the Centene Payment Integrity (PI) Power BI report (centene.pbip) - covers the star-schema model over datasets\*.csv, the validated DAX measure catalog, the 3-30-300 layout grid, every interactive feature (nav, drill, tooltips, filter panel bookmarks, Top N, segment selector), Centene branding via centene-theme.json, PBIR authoring gotchas, anti-hallucination rules and the final QA checklist.
---

# Centene Payment Integrity Dashboard - Build Standard

Project root: `C:\Users\DELL\Music\Capstone`. Artifacts: `centene.pbip`, `centene.Report\` (PBIR), `centene.SemanticModel\` (TMDL), `datasets\` (12 CSVs, **read-only**), theme: `centene-theme.json` (this folder).
Tools: `powerbi-modeling-mcp` for model/DAX (connect to the running Desktop instance), `powerbi-report-mcp` (`pbir_*`) for pages/visuals. Model first, then report. Status: report built and QA-passed 2026-10-05 (7 pages, 119 measures).

## 1. Business context and audience

Centene (centene.com, verified 2026-10-04): 25.9M managed-care members (30 Jun 2026), "more than 1 in 15 individuals across all 50 states"; segments Medicaid, Medicare, Health Insurance Marketplace. FWA is led by the Special Investigations Unit (SIU) with Program Integrity functions company-wide; "every single claim through 75 algorithms every day".

**Payment Integrity (PI)** = analytics that flag incorrect claims. **Pre-pay savings** = cost avoided before payment (preferred: no recovery effort). **Post-pay savings** = overpayments identified/recovered after payment.

| Audience | Key questions | Primary pages |
|---|---|---|
| PI leadership / SIU | Savings vs PY? Pre vs post mix? Which analytics are accurate (TPR)? | Executive Summary, Analytic Performance |
| Finance | Savings rate, paid-to-billed, YTD vs PY, best/worst segments | Executive Summary, Savings Analysis |
| Provider relations | Which providers drive savings, where, in which services? | Provider Insights, Provider Detail |

## 2. Anti-hallucination rules (mandatory)

1. **Never invent** tables, columns, measures, values, targets, benchmarks or industry averages. No target exists in the data: compare to prior year only and say so on the page.
2. **Verify names before binding**: list tables/columns/measures via the modeling MCP and copy names exactly. Use the exact CSV column names; rename only per visual (`displayName`).
3. **Validate every measure** with a DAX query and compare to the control totals (section 5) before using it in a visual.
4. **Small steps**: one table / relationship / measure group / page at a time -> validate -> continue.
5. **Never claim done** without re-reading model/report state and running section 13. Ask the user for screenshots - you cannot see Desktop.
6. **Never modify `datasets\`**. All fixes happen in Power Query or the model.
7. **State assumptions** (`ASSUMPTION:`) on the Definitions page and in the hand-off message.
8. Numbers in titles, captions, tooltips and alt text come from measures, never typed by hand.

## 3. Data model

### 3.1 Source file -> model table (contents of two dim files are SWAPPED)

| CSV file | Actual content | Model table |
|---|---|---|
| `fact_pi_measures.csv` | PI results, monthly grain | `fact_pi_measures` |
| `dim_date.csv` | Calendar 2022-01-01..2028-12-31 | `dim_date` |
| `dim_client.csv` / `dim_line_of_business.csv` / `dim_funding_type.csv` / `dim_claim_type.csv` / `dim_source_system.csv` | as named | same name |
| `dim_analytic.csv` / `dim_provider.csv` | SCD2 dims | same name |
| `dim_claim_status.csv` | Claim statuses | `dim_claim_status` (disconnected) |
| **`dim_employer_group.csv`** | **PI services** (`pi_service_*`) | **`dim_pi_service`** |
| **`dim_pi_service.csv`** | **Employer group** (`employer_group_*`) | **`dim_employer_group`** |
| (calculated) | Top N parameter `GENERATESERIES(3,7,1)` | `Top N` (column `Value`) |
| (calculated) | Segment list (5 dims) - section 8.3 | `Segment` (`Dimension`, `Member`, `Dimension Order` H) |

### 3.2 Tables and exact columns (H = hidden)

| Table | Columns (exact) |
|---|---|
| `fact_pi_measures` (248 rows) | ALL hidden: `pi_measures_key`, `client_key`, `lob_key`, `funding_type_key`, `pi_service_key`, `claim_type_key`, `analytic_key`, `provider_key`, `employer_group_key`, `source_system_key`, `date_key`, `total_claims_submitted_amount`, `total_claims_pre_edit_allowed_amount`, `total_claims_processed_amount`, `total_billed_amount`, `total_paid_amount`, `pre_pay_savings_amount`, `post_pay_savings_amount`, `total_savings_amount`, `true_positive_rate_pct`, `updated_at` |
| `dim_date` | `date_key` H, `full_date`, `year`, `quarter` H, `quarter_name`, `month` H, `month_name`, `week_of_year`, `day`, `day_of_week` H, `day_name`, `is_weekend`, `updated_at` H, derived `date_yyyymmdd` H |
| `dim_client` | `client_key` H, `client_code`, `client_name`, `client_category`, `effective_date`, `expiration_date`, `is_current`, `updated_at` H |
| `dim_line_of_business` | `lob_key` H, `lob_code`, `lob_name`, `lob_desc`, `updated_at` H |
| `dim_funding_type` | `funding_type_key` H, `funding_type_code`, `funding_type_name`, `funding_type_desc`, `updated_at` H |
| `dim_pi_service` | `pi_service_key` H, `pi_service_code`, `pi_service_name`, `pi_service_timing`, `pi_service_desc`, `updated_at` H |
| `dim_claim_type` | `claim_type_key` H, `claim_type_code`, `claim_type_name`, `claim_type_desc`, `updated_at` H |
| `dim_analytic` | `analytic_key` H, `analytic_code`, `analytic_name`, `analytic_desc`, `pi_service_code` H, `analytic_go_live_date`, `analytic_retire_date`, `is_active`, `status`, `updated_at` H |
| `dim_provider` | `provider_key` H, `provider_tin`, `provider_npi` (text), `provider_name`, `provider_type`, `provider_state`, `effective_date`, `expiration_date`, `is_current`, `updated_at` H |
| `dim_employer_group` | `employer_group_key` H, `employer_group_code`, `employer_group_name`, `client_key` H, `primary_lob_code`, `primary_funding_type_code`, `effective_date`, `expiration_date`, `is_current`, `updated_at` H |
| `dim_source_system` | `source_system_key` H, `source_system_code`, `source_system_name`, `source_system_category`, `source_system_desc`, `updated_at` H |
| `dim_claim_status` | `claim_status_key` H, `claim_status_code`, `claim_status_name`, `claim_status_desc`, `is_terminal`, `requires_action`, `updated_at` H |
| `_Measures` | hidden placeholder `_`; all 119 measures in 9 display folders |

### 3.3 Power Query (identical pattern for all 12 queries)

```m
let
    Source = Csv.Document(File.Contents(DataFolder & "<file>.csv"), [Delimiter=",", Encoding=65001, QuoteStyle=QuoteStyle.Csv]),
    Promoted = Table.PromoteHeaders(Source, [PromoteAllScalars=true]),
    NullsAsNull = Table.ReplaceValue(Promoted, "null", null, Replacer.ReplaceValue, Table.ColumnNames(Promoted)),
    Typed = Table.TransformColumnTypes(NullsAsNull, { ... }, "en-US"),
    UpdatedAtUtc = Table.TransformColumns(Typed, {{"updated_at", DateTimeZone.RemoveZone, type datetime}})
in UpdatedAtUtc
```
- `DataFolder` = text parameter pointing to `datasets\` (ends with `\`).
- **`QuoteStyle.Csv` is mandatory**: `QuoteStyle.None` (Desktop's default) splits "Fraud, Waste & Abuse" across columns.
- Types: `*_key`, `total_claims_*` -> Int64; currency columns -> `Currency.Type` (model type Decimal); `true_positive_rate_pct` -> number; dates -> date; `is_*` -> logical; `updated_at` -> datetimezone then `RemoveZone` (UTC).
- `dim_date`: add `date_yyyymmdd = [year]*10000 + [month]*100 + [day]` (Int64). Never relate on `dim_date[date_key]` (surrogate 1..2557).

### 3.4 Relationships (all `*:1`, single direction dim -> fact)

`fact_pi_measures[client_key|lob_key|funding_type_key|pi_service_key|claim_type_key|analytic_key|provider_key|employer_group_key|source_system_key]` -> the matching dim key; `fact_pi_measures[date_key]` -> `dim_date[date_yyyymmdd]`. `dim_claim_status`, `Top N`, `Segment` stay disconnected.
**Delete all auto-detected relationships first**: Desktop creates wrong ones (date_key->date_key, a bidirectional 1:1 snowflake via employer group, analytic->service by code). Turn auto date/time off and delete its `LocalDateTable_*` tables.

### 3.5 Date table and hierarchies

Mark `dim_date` as date table on `full_date`. Sort by: `month_name`->`month`, `quarter_name`->`quarter`, `day_name`->`day_of_week`. Fact grain is month (1st of month, 2023-01..2025-12). Hierarchies: Calendar (`year`>`quarter_name`>`month_name`), Service (`pi_service_timing`>`pi_service_name`), Provider Geography (`provider_state`>`provider_type`>`provider_name`), Client (`client_category`>`client_name`).

### 3.6 Known data issues

| # | Issue | Handling |
|---|---|---|
| D1 | `dim_employer_group.csv` / `dim_pi_service.csv` contents swapped | Load by content (3.1) |
| D2 | Fact `date_key` YYYYMMDD vs `dim_date[date_key]` surrogate | `date_yyyymmdd` join |
| D3 | `employer_group_key` 124/248 null; keys 2-6 (50 rows) orphaned | "(Blank)"; totals unaffected |
| D4 | Employer group 1 belongs to client 2 but 59 client-1 rows use it | No employer-group -> client filtering |
| D5 | `dim_analytic[pi_service_code]` disagrees with fact on 96 rows | No Service->Analytic hierarchy |
| D6 | SCD windows violated (analytic 8, provider 8 used early; keys 7 unused) | Use fact key; no `is_current` filter |
| D7 | `true_positive_rate_pct` row-level 0-100 rate | Never SUM; weighted measure |
| D8 | `total_claims_*_amount` are counts (561-24,878) | ASSUMPTION: claim counts |
| D9 | `dim_claim_status` has no fact key | Disconnected, not reported |
| D10 | RX claims across 6 source systems | Informational |
| D11 | Rows per year 92 / 69 / 87 | YoY reflects the extract (Definitions page) |

## 4. Measure catalog (`_Measures`, 132 measures, every one described)

Rules: explicit measures only (`discourageImplicitMeasures` = true); `DIVIDE()` for every ratio; **never SUM a rate**; format string on every numeric measure; display folder + `///` description on every measure.

| Folder | Measures (key DAX) |
|---|---|
| 01 Base | `Total Billed/Paid`, `Pre-Pay/Post-Pay/Total Savings` = SUM of the amount column; `Claims Submitted/Pre-Edit Allowed/Processed` = SUM (counts) |
| 02 Ratios | `Savings Rate %` = DIVIDE(Savings, Billed) (ASSUMPTION); `Paid to Billed %`; `Pre-Pay Share %`; `Post-Pay Share %`; `Savings per Processed Claim` |
| 03 Time | PY, YoY %, Δ pp and YTD for every KPI (pattern below) |
| 04 Accuracy | `True Positive Rate %` (weighted), `(Simple Avg)`, `PY`, `Δ pp` |
| 05 QA & Meta | `Savings Check Difference/Status`, `Fact Row Count`, `Data As Of`, `Latest Data Month`, `Data Through Label` |
| 06 UI | `<KPI> Var Text` / `<KPI> Var Color`, `Neutral Color`, `Selected * Text`, `Header Context`, titles, `Active Filter Count`, `Filters Button Text`, alt text |
| 07 Provider & Analytic | `Providers with Savings`, `Top Provider Share %/Name`, `Avg Savings per Provider`, `Analytics Contributing`, `Portfolio True Positive Rate %`, `TPR Color vs Portfolio`, `Provider Savings Rank`, `Top N Value`, `Provider In Top N`, `TopN *` |
| 08 KPI Display | `KPI <name>` = card text ("$54.5M", "2.40%", or "No data") |
| 09 Segment | `Segment *` measures + titles (section 8.3) |
| 09 Optum | `Optum Services Active`, `Top Service Share %`, `Top Service Name`, `Analytics Below Portfolio Text`, `Optum Services Caption`, `Optum Impact Summary`, `Optum Neutral Color`, `YTD Focus Year`, `Savings YTD Focus Year`, `Savings PY YTD Focus Year`, `Title Optum YTD` (+ `KPI Optum Services Active`, `KPI Top Service Share` in 08) |

**Currency format** (all money measures): `\$#,0,,.0\M` -> "$54.5M" everywhere, locale-proof. The scaling commas must sit immediately left of the decimal point (`#,0.0,,` does NOT scale). Charts using it need display units = None (`labelDisplayUnits 1D`), otherwise "$0.0MM".

```DAX
-- Weighted TPR (ASSUMPTION: weight = claims processed)
True Positive Rate % = DIVIDE ( SUMX ( fact_pi_measures, fact_pi_measures[true_positive_rate_pct] * fact_pi_measures[total_claims_processed_amount] ),
                                SUM ( fact_pi_measures[total_claims_processed_amount] ) ) / 100
-- PY: guard with HASONEVALUE - dim_date spans 2022-2028, so an all-years PY equals the current value (false 0% YoY)
Total Savings PY = IF ( HASONEVALUE ( dim_date[year] ), CALCULATE ( [Total Savings], SAMEPERIODLASTYEAR ( dim_date[full_date] ) ) )
-- YoY / Δ pp: require BOTH periods (else 2026+ shows -100%)
Total Savings YoY % = IF ( NOT ISBLANK ( [Total Savings] ) && NOT ISBLANK ( [Total Savings PY] ), DIVIDE ( [Total Savings] - [Total Savings PY], [Total Savings PY] ) )
Savings Rate Δ pp = IF ( NOT ISBLANK ( [Savings Rate %] ) && NOT ISBLANK ( [Savings Rate % PY] ), ( [Savings Rate %] - [Savings Rate % PY] ) * 100 )
Total Savings YTD = TOTALYTD ( [Total Savings], dim_date[full_date] )   -- charts only (equals full year when a whole year is selected)
-- Card comparison line + colour (test BLANK first: BLANK() >= 0 is TRUE in DAX)
Total Savings Var Text = VAR d = [Total Savings YoY %]
  RETURN IF ( ISBLANK ( d ), "No prior-year data", IF ( d >= 0, "▲ ", "▼ " ) & FORMAT ( ABS ( d ), "0.0%" ) & " vs PY $" & FORMAT ( [Total Savings PY] / 1000000, "#,0.0" ) & "M" )
Total Savings Var Color = VAR d = [Total Savings YoY %] RETURN SWITCH ( TRUE (), ISBLANK ( d ), "#6E6E6E", d >= 0, "#2C8641", "#B72032" )
Neutral Color = "#00598C"   -- volume KPIs (Billed, Paid, Paid to Billed, Claims Processed): direction without good/bad
-- Card text (no "(Blank)", en-US formatting regardless of Windows locale)
KPI Total Savings = VAR x = [Total Savings] RETURN IF ( ISBLANK ( x ), "No data", "$" & FORMAT ( x / 1000000, "#,0.0" ) & "M" )
-- Provider rank: strip other provider columns the table groups by, or every provider ranks #1 within its own state
Provider Savings Rank =
  VAR Cur = [Total Savings]
  VAR Ranked = CALCULATETABLE ( ADDCOLUMNS ( VALUES ( dim_provider[provider_name] ), "@s", [Total Savings] ),
                 REMOVEFILTERS ( dim_provider[provider_npi], dim_provider[provider_type], dim_provider[provider_state] ), ALLSELECTED ( dim_provider[provider_name] ) )
  RETURN IF ( ISINSCOPE ( dim_provider[provider_name] ) && NOT ISBLANK ( Cur ), RANKX ( Ranked, [@s], Cur, DESC, DENSE ) )
Provider In Top N = VAR r = [Provider Savings Rank] RETURN IF ( NOT ISBLANK ( r ), IF ( r <= [Top N Value], 1, 0 ) )
-- Top N table measures: blank outside Top N (rows disappear), total row = Top N subtotal (repeat for Pre-Pay Share, Paid to Billed, TPR)
TopN Total Savings = VAR TopProviders = TOPN ( [Top N Value], ALLSELECTED ( dim_provider[provider_name] ), [Total Savings], DESC )
  RETURN IF ( ISINSCOPE ( dim_provider[provider_name] ), IF ( [Provider In Top N] = 1, [Total Savings] ), CALCULATE ( [Total Savings], KEEPFILTERS ( TopProviders ) ) )
Active Filter Count = INT ( ISFILTERED ( dim_date[quarter_name] ) ) + INT ( ISFILTERED ( dim_client[client_name] ) ) + ... (9 slicer columns, year excluded)
Data Through Label = "Data through " & FORMAT ( CALCULATE ( [Latest Data Month], REMOVEFILTERS () ), "mmm yyyy" ) & "  ·  Refreshed " & FORMAT ( [Data As Of], "mmm d, yyyy" )
```

## 5. Control totals (validate against these)

```DAX
EVALUATE SUMMARIZECOLUMNS ( dim_date[year], "Savings", [Total Savings], "Pre", [Pre-Pay Savings], "Post", [Post-Pay Savings],
  "Billed", [Total Billed], "Paid", [Total Paid], "TPR", [True Positive Rate %], "YoY", [Total Savings YoY %], "Check", [Savings Check Status] )
```

| Scope | Total Savings | Pre-Pay | Post-Pay | Billed | Paid | Savings Rate | Paid/Billed | TPR (wtd) |
|---|---|---|---|---|---|---|---|---|
| All | 156,764,903.24 | 69,744,660.79 | 87,020,242.45 | 6,332,770,753.40 | 4,391,703,679.79 | 2.48% | 69.35% | 63.35% |
| 2023 | 58,039,611.22 | 24,103,504.57 | 33,936,106.65 | 2,194,102,565.08 | 1,531,488,726.16 | 2.65% | 69.80% | 63.08% |
| 2024 | 44,207,864.48 | 21,072,596.35 | 23,135,268.13 | 1,870,521,095.12 | 1,276,688,725.86 | 2.36% | 68.25% | 66.01% |
| 2025 | 54,517,427.54 | 24,568,559.87 | 29,948,867.67 | 2,268,147,093.20 | 1,583,526,227.77 | 2.40% | 69.82% | 61.39% |

Also: YoY 2024 -23.8%, 2025 +23.3%; PY/YoY blank for 2023, 2026+ and all-years; Claims Processed 2,715,219; 2025 Top 5 provider subtotal 45,419,136.49; 2025 LOB: Medicare 16.11M, Commercial 14.34M, Exchange/ACA 13.82M, Medicaid 10.24M; `Savings Check Status` PASS every year.

## 6. The 3-30-300 rule

| Tier | Viewer question | Zone | Visual types | Rules |
|---|---|---|---|---|
| **3 s** | "Are we on track?" | KPI row y 128-232 | 5 KPI cards: value + ▲/▼ comparison | Max 5; colour only on the comparison line |
| **30 s** | "Where / why is it moving?" | Rows y 240-708 | Combo trend, ranked bars, scatter, segment selector | Max 4 content visuals; sorted desc; dynamic titles |
| **300 s** | "Which provider / analytic exactly?" | Drill-through, tooltip, matrices, filter panel | Provider Detail fact-row table, TT Month, expandable matrix | Reached by click, never crowding page 1 |

## 7. Layout grid (1280x720, FitToPage, background `#F4F4F4`, every page identical)

| Zone | x | y | w | h |
|---|---|---|---|---|
| Header band (shape `#262768`, title text 16pt bold white, margins top/bottom 0, left 16) | 0 | 0 | 1280 | 56 |
| Header context card `[Header Context]` / data card `[Data Through Label]` | 500 / 736 | 8 | 230 / 304 | 40 |
| Filters / Reset / i buttons (text margins 0) | 1048 / 1148 / 1228 | 10 | 92 / 72 / 36 | 36 |
| Left nav rail (white) + 1px divider `#DCDDDE` at x 176 | 0 | 56 | 176 | 664 |
| Nav rail (rail shape tinted: Optum pages `#FFF4EF`, Centene pages `#EAF1F6`): group labels = non-clickable buttons (padding 0) OPTUM (charcoal) y 64 / CENTENE (`#00598C`) y 180, 9pt bold, x 16 h 24, 4x16 brand bar at x 8; buttons Impact on Centene 90, Services & Analytics 130, Executive Summary 206, Provider Insights 246, Definitions 300 (9pt; other pages = tint fill; current page = white fill, bold brand text + 4x36 brand accent bar; hover `#FFD3C2` / `#CCDEE8`) | 8 | see text | 160 | 36 |
| Rail footnote (8pt grey, valign middle) | 8 | 600 | 160 | 108 |
| Slicer bar: Year, Quarter, Client, Line of Business, Funding Type, PI Service | 188 + 181i | 60 | 170 | 60 |
| KPI panel (rounded white shape) at x 188/405/622/839/1056 | - | 128 | 205 (last 208) | 104 |
| KPI value card (title = KPI name 9pt; value 18pt bold indigo) | panel x+4 | 130 | w-8 | 70 |
| KPI comparison card (9pt, colour = measure) | panel x+4 | 200 | w-8 | 30 |
| Content row 1 / row 2 | 188 | 240 / 462 | 1076 total | 214 / 246 |
| More-filters panel (hidden; bookmarks): square rectangle, outline `#DCDDDE`, drop shadow; title 880,68 / Close 1176,68 (text margins 0); slicers x 880 w 368 at y 108/176/244/312 with background+border off | 864 | 60 | 400 | 324 |

Gutters 12 px horizontal, 8 px vertical. Common splits: 700|364, 591|473, 530|534, 650|414, 200|864. Never use `card` titles under 56 px height or values > 18pt in KPI cards (clips). Do not rely on shape text vertical alignment `top` (renders middle) - put labels in card titles instead.

**Pages** (visible order: Optum Impact on Centene, Optum Services & Analytics, Centene Executive Summary, Centene Provider Insights. Hidden: Savings Analysis, Analytic Performance, Definitions & Data Notes (via `i` / nav), Provider Detail (drill-through), TT Month (tooltip 320x240)):

| Page | KPIs | Row 1 | Row 2 |
|---|---|---|---|
| Executive Summary | Total, Pre-Pay, Post-Pay Savings, Savings Rate, TPR | Combo: Pre/Post columns by month + dashed PY line (tooltip page) \| LOB bar drilling to client | Provider ranking table (data bars) \| "View savings by" selector + Segment bar |
| Savings Analysis | Billed, Paid, Paid to Billed (neutral), Savings Rate, Savings per Claim | YTD vs PY YTD line \| 36-month Savings Rate trend (Year/Quarter interactions = NoFilter) | Selector + explainer \| Segment matrix (YoY font colour) |
| Analytic Performance | TPR, Total Savings, Pre-Pay Share, Claims Processed (neutral), Analytics with Savings | Scatter TPR vs savings (portfolio TPR reference line) \| TPR by quarter vs PY | Service x Claim Type matrix (white->sky gradient) \| TPR by analytic (red below portfolio) |
| Provider Insights | Providers (NPI), Total Savings, Top Provider Share (+ name), Avg per Provider, TPR | Top N selector (default 5) + caption \| Savings by state | Provider ranking table (TopN measures) \| Savings by provider type |
| Provider Detail | Total, Pre, Post, Paid to Billed, TPR | Monthly combo, title `[Title Provider Detail]` \| Savings by PI service | Fact-row table (lowest grain; no claim/member IDs exist) |
| Optum Impact on Centene | Savings Delivered by Optum, Prevented Before Payment, Recovered After Payment, Savings per $ Billed, Savings per Claim Reviewed | Focus-year YTD vs prior-year YTD line (title `[Title Optum YTD]`, subtitle `[Optum Impact Summary]`; works with Year = All) \| clustered columns Prevented % vs Recovered % by year (Year/Quarter slicers NoFilter) | Savings by Centene LOB, pre/post clustered bar (labels outside) \| claims reviewed columns + savings-per-claim line by month |
| Optum Services & Analytics | Claims Reviewed (neutral), Flag Accuracy (TPR), Optum Services Active, Analytics Active (+ below-portfolio count), Top Service Share (+ name) | Savings by Optum PI service, pre/post stacked bar \| analytic accuracy-vs-value scatter + portfolio TPR line | Service x LOB matrix (white -> `#FFB59A`) \| Centene providers most impacted (drill-through) |
| Definitions & Data Notes | - | KPI definitions + colour meaning \| Data notes D1-D11 + assumptions | Validation card, row count, data currency |

## 8. Interactive features - how built (PBIR)

### 8.1 Feature table

| Feature | Implementation |
|---|---|
| Page navigation | `actionButton` per page, `visualContainerObjects.visualLink` = `{show:true, type:'PageNavigation', navigationSection:'<pageId>'}` |
| Drill-through + back | Provider Detail `page.json`: categorical filter on `dim_provider.provider_name` (`howCreated: Drillthrough`) **plus** `pageBinding {type: Drillthrough, parameters:[{boundFilter, fieldExpr}]}`; hidden; Back button `type:'Back'` |
| Drill-down | LOB bar (`lob_name` > `client_name` in Category), matrix rows timing > service |
| Dynamic titles/subtitles | `title.text` / `subTitle.text` = `{expr:{Measure:...}}`; theme default `subTitle.show=false`, set show + text per visual |
| Slicers + sync | Dropdown slicers, `projection.displayName` = friendly label, `visual.syncGroup {groupName, fieldChanges, filterChanges}` on every page; Year single-select default 2025 (`objects.general.filter` In 2025L) + visual filter `[Total Savings]` not blank |
| More-filters panel | 7 visuals (panel shape, title, Close, 4 slicers: Claim Type, Provider State, Source System, Analytic) with `"isHidden": true`; Filters button -> open bookmark, Close -> closed bookmark (8.2) |
| Reset | `visualLink type:'ClearAllSlicers'` (clears Year too -> all years) |
| Report-page tooltip | TT Month page `type: Tooltip`, `pageBinding {type: Tooltip}`, hidden; on charts `visualTooltip {show, type:'Canvas', section:'<pageId>'}` |
| Segment selector (replaces field parameters) | 8.3 |
| Top N | `Top N` table + dropdown (default 5) + `TopN *` measures in the table (no visual-level measure filter needed) |
| Conditional formatting | Data bars (`columnFormatting.dataBars`, sky), measure-driven font colour (`values.fontColor` = `[Segment Savings YoY Color]`), gradient (`backColor` FillRule) , bar colour by measure (`dataPoint.fill` = `[TPR Color vs Portfolio]`) |
| KPI cards | 3 layers: rounded panel shape, value `card` (title = label), comparison `card` with `labels.color` = `<KPI> Var Color` |
| Accessibility | `general.altText` on every non-decorative visual (measure-driven for main charts); `tabOrder`: header -> nav -> slicers -> KPIs -> content -> hidden panel -> decorative shapes |

### 8.2 Bookmarks (write files yourself - `pbir_add_bookmark` writes an invalid folder layout)

`definition/bookmarks/bookmarks.json` (`bookmarksMetadata/1.0.0`: `items:[{name, displayName, children:[...]}]`) + one `<name>.bookmark.json` per bookmark (`bookmark/2.0.0`):
```json
{"name":"bm…","displayName":"Filters open – Executive Summary",
 "options":{"targetVisualNames":["<7 panel ids>"],"suppressData":true,"applyOnlyToTargetVisuals":true,"suppressActiveSection":true},
 "explorationState":{"version":"1.3","activeSection":"<pageId>","sections":{"<pageId>":{"visualContainers":{"<id>":{"singleVisual":{"visualType":"slicer","objects":{}}}}}}}}
```
Closed variant adds `"display":{"mode":"hidden"}` inside each `singleVisual`. Validate against the published schemas before reload.

### 8.3 Segment selector (field-parameter replacement)

Field parameters bound from PBIR failed ("capacity or license issue"). Use a disconnected table and TREATAS:
```DAX
Segment = DISTINCT ( UNION ( SELECTCOLUMNS ( dim_pi_service, "Dimension", "PI Service", "Member", dim_pi_service[pi_service_name], "Dimension Order", 1 ), ... LOB 2, Client 3, Funding 4, Claim Type 5 ) )
Segment Total Savings = VAR d = SELECTEDVALUE ( Segment[Dimension], "PI Service" ) VAR m = VALUES ( Segment[Member] )
  RETURN SWITCH ( d, "PI Service", CALCULATE ( [Total Savings], KEEPFILTERS ( TREATAS ( m, dim_pi_service[pi_service_name] ) ) ), "Line of Business", ... )
```
`KEEPFILTERS` keeps the slicer bar effective. Slicer on `Segment[Dimension]` (single select, default 'PI Service', sync group `Segment`); axis/rows = `Segment[Member]`.

## 9. Branding (`centene-theme.json`)

| Hex | Role | Contrast on white |
|---|---|---|
| `#00598C` Centene Blue | Primary series, titles, pre-pay, nav selection, table headers, **neutral comparisons** | 7.48 |
| `#262768` Indigo | Header band, KPI values, post-pay | 13.35 |
| `#00AEEF` Sky | Spare (fills only; NOT under table text) | 2.53 |
| `#B3D1E2` / `#CCDEE8` / `#EAF1F6` | Data bars + matrix gradient max (table text 5.29:1) / nav hover / nav rail tint | - |
| `#2C8641` Green / `#B72032` Red | Favourable / unfavourable vs PY only | 4.57 / 6.43 |
| `#CB187D` Cerise | Highlight one item (rare) | 5.29 |
| `#6E6E6E` Grey | No comparison available, PY line, secondary text | 5.10 |
| `#58595B` / `#4D4D4D` | Body / table text | 7.01 / 8.45 |
| `#DCDDDE` / `#F4F4F4` / `#FFFFFF` | Borders / canvas / panels | - |
| `#F58220`, `#00A0A4`, `#5C2F92`, `#AAC932` | Spare series (fills only; lime decoration only) | - |

Fonts (theme): Roboto -> Segoe UI fallback. Sizes: page title 16, visual title 11, KPI value 18, everything else 9 (axes, legends, labels, slicers, tables, nav). Tables/matrices: `columnHeaders.columnAdjustment = growToFit`, word wrap, 9pt, row padding 3. Shapes/textboxes/buttons: theme sets background/border/title off.

### 9.1 Optum audience pages (one report theme; Optum styling set per visual)

Framing: the report is presented to Optum to show its impact on Centene claims. Verified: Centene payment policy CC.PP.074 names Optum Comprehensive Payment Integrity for pre-pay claim editing; Optum is part of UnitedHealth Group. **ASSUMPTION** (shown on the Optum rail footnote and Definitions page): all savings in the data are Optum's - there is no vendor column.

| Hex (optum.com CSS) | Role | Contrast on white |
|---|---|---|
| `#FF612B` Optum orange | Pre-pay series, header rule (4 px at y 52), selected nav tint, panel outline - **fills only** | 3.00 |
| `#D74120` Dark orange | OPTUM rail label, button hover | 4.50 |
| `#3D3C38` Charcoal | Header text, KPI values, titles, slicer headers, table headers, buttons, `Optum Neutral Color` | 11.04 |
| `#002677` Deep blue | Post-pay series, claims columns | 13.60 |
| `#73716A` Warm grey | PY dashed line, KPI labels, data card | 4.88 |
| `#FAF8F2` Cream | Page background + outspace (`page.json objects`) | - |
| `#FFB59A` / `#FFD3C2` / `#FFF4EF` | Matrix gradient max, data bars / nav hover / nav rail tint | - |

Header band white with charcoal title `Optum  \|  ...`; green/red stay for vs-PY semantics. Centene pages keep the Centene theme unchanged.

## 10. Build sequence

1. Load 12 CSVs (3.3) -> delete auto relationships + LocalDateTables -> verify row counts (248 / 2557 / 10 / 1).
2. Rename swapped tables, add `date_yyyymmdd`, types, hide columns -> refresh -> create 10 relationships -> Calculate refresh -> unmatched-row check = 0.
3. Mark date table, sort-by, hierarchies -> measures folder by folder -> section 5 query.
4. Theme -> pages via one generator (header/rail/slicers/KPI templates) -> post-patch dynamic properties -> reload -> screenshots -> iterate.
5. Bookmarks, alt text, tab order -> schema validation -> section 13.

## 11. PBIR authoring gotchas (learned on this build)

| Symptom | Cause / fix |
|---|---|
| Report won't render (`visitLinearGradient2`) | Inside expression trees (FillRule) literals are bare `{"Literal":...}` - no `{"expr":...}` wrapper |
| Display units ignored / "$0.0MM" | `labelDisplayUnits` must be numeric literal `1000000D` (not a string); with `$#,0,,.0\M` format set units to `1D` |
| Series colours ignored | `dataPoint` selector `metadata` must be the queryRef (`_Measures.Pre-Pay Savings`) |
| Buttons dark / no text | Button `fill`/`text` need a `selector {id:"default"}` entry; actions belong in `visualContainerObjects.visualLink` |
| Fonts stuck at Segoe 8pt | The report tool stamps fontFamily/8D on every visual - strip so the theme applies |
| Header text / KPI values clipped | Shape/button text margins default to ~16px - set top/bottom 0; card value needs >= 70 px with title |
| Visual-level measure filter silently ignored | Prefer measures that blank out rows (TopN pattern) |
| Model edits lost | Desktop holds the model in memory: Ctrl+S before any `pbir_reload_report`; or edit TMDL on disk then reload (validate with `ImportFromTmdlFolder` first) |
| Report edits lost | Saving in Desktop after file edits overwrites them - reload first, save after |
| Inside data labels stay white (colour ignored) | Desktop auto-contrasts labels inside stacked/100% bars; use clustered visuals with `labelPosition 'OutsideEnd'` + explicit `labels.color` |
| Small button/shape text clipped | Theme `*` padding is 8 px top/bottom; set `visualContainerObjects.padding` 0 on visuals under ~36 px |
| YTD line empty when Year = All | `TOTALYTD` needs one year; use a focus-year measure (latest year with data in `ALLSELECTED ( dim_date )`) |
| Indian digit grouping (1,54,83,130) | Desktop uses the Windows locale; `$M` format strings and FORMAT-based KPI text avoid it |

## 12. Edit interactions

Slicers filter all visuals except the 36-month trend and the Optum pre/post mix-by-year chart (Year/Quarter -> NoFilter). Visual-to-visual: default cross-filter. Tooltip and Definitions pages: none.

## 13. Final QA checklist (status 2026-10-05: all passed, incl. Optum pages)

**Data & model**
- [x] 12 source tables with correct names (D1); `git status datasets` clean
- [x] Row counts 248 / 2557 / 10 / 1; no text `null`; "Fraud, Waste & Abuse" intact
- [x] 10 relationships `*:1` single; 0 unmatched dates/providers/services; 50 orphan employer groups (D3, expected)
- [x] Date table marked; sort-by; auto date/time off; 4 hierarchies
- [x] Keys, `updated_at`, `date_yyyymmdd`, all fact columns hidden

**Measures**
- [x] 128 measures in `_Measures`, 10 folders, all described, numeric ones formatted
- [x] No implicit measures in visuals (no `Aggregation` in any visual.json); no SUM of rates; DIVIDE everywhere
- [x] Section 5 totals reproduced to the cent; `Savings Check Status` PASS
- [x] PY/YoY blank for 2023, 2026+, all-years

**Report**
- [x] Theme applied; no colours outside the palette (scan visual.json hex literals)
- [x] All pages 1280x720; grid 7 respected; overlap/bounds audit clean
- [x] <=5 KPIs and <=4 content visuals per page
- [x] Nav (48 buttons, CENTENE/OPTUM groups on 8 pages) targets valid; Back; drill-through binding; drill-down
- [x] Dynamic titles/subtitles; data label "Data through Dec 2025 · Refreshed Aug 19, 2026"
- [x] Slicers synced (6 + Segment + 4 panel); Filters panel opens/closes; Reset clears slicers
- [x] Tooltip page on 3 charts; Segment selector; Top N default 5 with subtotal
- [x] Conditional formatting: green good / red bad / blue neutral / grey no PY
- [x] Definitions page: KPI definitions, D1-D11 notes, assumptions, validation cards

**Accessibility & publish readiness**
- [x] Alt text on all 225 non-decorative visuals; tab order header -> nav -> slicers -> KPIs -> content -> hidden panel -> decorative
- [x] Text contrast >= 4.5:1 (no text in sky/orange/lime); ▲/▼ + sign, never colour alone
- [x] Optum pages: only Optum palette (9.1) except the CENTENE rail label; labels inside orange bars use a white label background + charcoal text
- [x] Every KPI card tested for 2025, 2024, 2023 (no PY), all years, 2025 Medicaid, 2026 (no data -> "No data" / "No savings in filters", never a stale name)
- [x] No invented targets; every number from a measure
- [x] All 391 PBIR files (364 visuals, 14 bookmarks, 9 pages) validate against the schema version each declares; TMDL imports cleanly
- [x] Heaviest queries (segment matrix + Top N table) 139 ms total (< 2 s)
