# 10-Minute Customer Demo + 5-Minute Q&A: PI Healthcare Capstone

**Audience:** Payment Integrity leadership (client: State Medicaid Agency and HealthFirst Employer Trust)
**File:** `Documents\PI_Capstone\PI_Healthcare_Capstone.pbip`
**Before you start:** open the report on Executive Overview, clear all slicers, and close the Filters pane.

| Time | Section | What to show / click | What to say (key numbers) |
|---|---|---|---|
| 0:00–1:00 | Opening | Executive Overview banner | "This report answers three questions: how much are we saving, where does it come from, and which providers drive it. Every number you'll see has been reconciled to the source extracts with 30 automated tests." |
| 1:00–3:00 | Headline KPIs | KPI cards | **Total Savings $156.8M**: **$69.7M pre-pay** (cost avoidance, 44.5%) plus **$87.0M post-pay** (recovery). **Savings rate 3.57% of paid.** **Analytic true-positive rate 63.3%**, weighted by claims processed. **+23.3% YoY** in 2025 vs 2024. |
| 3:00–4:30 | Drill-down | Trend chart → click the drill arrow → double-click 2025 → Quarter → Month | "2023 was $58.0M, 2024 dipped to $44.2M, and 2025 recovered to $54.5M. The line is the savings rate on the secondary axis." Demonstrate Year → Quarter → Month. |
| 4:30–5:30 | Slicers | Client slicer → State Medicaid Agency, then LOB → Medicare | "All visuals respond. State Medicaid Agency is $83.2M. Medicare is the largest LOB at $47.3M." Clear the slicers afterwards. |
| 5:30–7:00 | Service & Analytic page | Matrix: expand Postpay → a service → analytics. Scatter chart | "Coordination of Benefits ($26.5M) and Prepayment Claim Editing ($24.6M) lead. The scatter plot shows accuracy against dollars, so it flags analytics that save a lot but have low precision, meaning more provider abrasion." Point at the claims funnel: 9.0% of submitted claims are stopped at pre-edit. |
| 7:00–8:30 | Drill-through | Back on Executive Overview, right-click **Riverside Medical Group PC** → Drill through → Provider Detail | "Riverside is #2 at $29.8M. Here is its monthly trend, its savings by service, and every line of activity for audit. The Back button returns to the overview." |
| 8:30–9:30 | Trust and data quality | Open the validation workbook → Validation Tests (30/30 PASS) → Data Quality sheet | "We found and fixed 4 data-quality issues: a date-key format mismatch, 124 null and 50 orphan employer-group keys, and a claim-status table with no link to the fact table. They are handled in the model and remain visible, not hidden." |
| 9:30–10:00 | Close | Model diagram | "It's a clean star schema with one fact table, 10 dimensions and 28 documented measures, and it refreshes from the CSV folder parameter." |

## Q&A prep (likely questions)

1. **"How do you know the numbers are right?"** Each of the 30 tests compares a DAX result to an independent Excel formula over the raw rows. All pass to $0.01, or 1e-9 for ratios.
2. **"Why weight the TP rate?"** A simple average treats a 600-claim row like a 23,000-claim row. Weighted is 63.3% and simple is 64.2%.
3. **"Why does YoY show on the card without a year selected?"** The card measure finds the latest year with data (2025) and compares it with 2024. The chart version uses SAMEPERIODLASTYEAR.
4. **"What is 'Unmapped Employer Group'?"** 50 fact rows point to employer-group keys 2–6, which aren't in the dimension extract. We surface them rather than drop them, and the fix belongs upstream in the eligibility feed.
5. **"Can we slice by claim status?"** Not yet. The fact table has no claim_status_key. The table is loaded and ready for when the extract adds it.
6. **"How does refresh work?"** Change the `DataFolder` parameter or drop new CSVs into the folder, then refresh. Unknown employer-group members are generated automatically.
7. **"Explain the rank measure."** RANKX over ALLSELECTED(dim_provider) evaluates Total Savings for every provider in the current selection. Using the whole table, not one column, removes the other provider-attribute filters coming from the table row.

## Rehearsal checklist

- [ ] Run through twice with a timer (target 9:30).
- [ ] Practise explaining the DAX for Total Savings YoY %, Latest Year Savings YoY %, TP Rate (Weighted) and Provider Savings Rank out loud without notes.
- [ ] Clear all slicers and save before presenting.
- [ ] Keep the validation workbook open in a second window.
