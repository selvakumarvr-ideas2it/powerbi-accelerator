# centene-data: what differs from the files as delivered

Two changes were made to this folder on 2026-10-06, at the report owner's request. Everything else is exactly as delivered. The two affected files are kept unchanged, under their delivered names, in `../centene-data-original/`.

## 1. Two lookup files were renamed

The two files arrived with each other's contents (Issue 1). They were renamed so that each name matches what the file holds.

| File now | Holds | Delivered as |
|---|---|---|
| `dim_pi_service.csv` | The 10 PI services | `dim_employer_group.csv` |
| `dim_employer_group.csv` | The employer groups | `dim_pi_service.csv` |

No row or value changed in the PI service file.

## 2. Five synthetic employer groups were added

The delivered employer group file had one row, key 1. Fact rows also use keys 2 to 6, which had no lookup row (Issue 4). Five rows were added so that every keyed fact row has a group name.

**These five rows are synthetic. They are not client data.** The names, codes and dates are made up. They can be told apart by `updated_at = 2026-10-06T00:00:00.000Z`.

| Key | Code | Name | Client key | Primary LOB | Primary funding | Effective date | Origin |
|---|---|---|---|---|---|---|---|
| 1 | EG-101873 | HealthFirst Trust Members | 2 | COMM | ASO | 2022-07-01 | Delivered |
| 2 | EG-102214 | State Employees Group | 1 | MCD | FI | 2021-07-01 | Synthetic |
| 3 | EG-103567 | County Workers Plan | 1 | ACA | FI | 2021-10-01 | Synthetic |
| 4 | EG-104902 | Public Schools Trust | 1 | MCR | FI | 2022-01-01 | Synthetic |
| 5 | EG-105338 | Municipal Retirees Group | 1 | MCD | ASO | 2022-04-01 | Synthetic |
| 6 | EG-106741 | Transit Authority Members | 1 | COMM | FI | 2022-07-01 | Synthetic |

How the synthetic values were chosen, so they stay consistent with the fact rows:

- **Client key 1** for all five, because every fact row using keys 2 to 6 belongs to client 1 (State Medicaid Agency). This adds no new client/group mismatches.
- **Primary LOB and funding type:** the most common value among that key's fact rows.
- **Effective date:** after the client's own effective date (2021-03-15) and before the key's earliest fact row.
- **Code, expiry and "is current":** the same pattern as the delivered row.

## What was not changed

- `fact_pi_measures.csv` is untouched. The 124 fact rows with no employer group key still have no key and show as "Not supplied" in the report.
- No other file was edited.

## If the client supplies the real groups

Replace rows 2 to 6 of `dim_employer_group.csv` with the client's rows and refresh. Nothing else in the project depends on the synthetic names.
