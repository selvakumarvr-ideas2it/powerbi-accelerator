# Centene Power BI theme brief

Colours and fonts for the Centene PI capstone report, taken from centene.com on 2026-10-03.

**Source caveat:** these values come from the public website's stylesheets, the logo image and the 2025 homepage banner. They are **not** from an official Centene brand guide, which the site doesn't publish. If the client has a brand guide, it replaces this brief (client question Q18).

## How the values were collected

| Method | Where | What it gave |
|---|---|---|
| Computed styles of visible elements | centene.com home and Who We Are pages | Fonts, text colours, link colour, heading sizes |
| Every colour declared in Centene's own CSS files (`clientlibs-main`, `clientlibs-site`) | Site stylesheets | Brand palette, ranked by how often each colour is used |
| Pixel sampling of `centene_logo_2023.jpg` | Logo | Logo blue = `#00598C` (matches the CSS) |
| Pixel sampling of `2025-centene-homepage-banner-copy-2.jpg` and `purple-background-2025.png` | Hero banner | Indigo `#262768` background, bright cyan ring ≈ `#00B4F0` |

Cyan `#00B4F0` is sampled from a JPEG, so it's approximate (±1 shade). Every other hex value is declared exactly in the CSS.

## Typography

| Use on centene.com | Font | Weight | Size |
|---|---|---|---|
| Page title (h1) | Roboto | 500 (Medium) | 32 px |
| Section heading (h2) | Roboto | 500 | 29 px |
| Display heading ("By The Numbers") | Roboto Regular | 400 | 45 px |
| Stat headline ("25.9 MILLION MANAGED CARE MEMBERS") | Roboto, uppercase | 700 (Bold) | 18 px, in Centene Blue |
| Body text | Roboto | 400 | 16–18 px |
| Fallback in some components | Arial, Helvetica | 400 | — |

Centene ships Roboto Regular, Medium, Bold and Italic as web fonts. Roboto Slab is also loaded from Google Fonts but wasn't seen on any visible text.

**For Power BI:** Roboto isn't one of Power BI's built-in fonts. It displays only on machines that have Roboto installed (it's free from Google Fonts). Proposed theme setting: `Roboto, Segoe UI, sans-serif`. Where Roboto is missing, Power BI falls back to Segoe UI, which has similar proportions. Check this in Power BI Desktop before the demo.

## Brand colours

Ranked by how often each colour appears in Centene's CSS. Contrast is the WCAG ratio against a white background: 4.5 or more is readable as text, 3 or more works for large text and chart marks.

| Role | Name (ours) | Hex | Uses in CSS | Contrast on white | Seen on site as |
|---|---|---|---|---|---|
| Primary | Centene Blue | `#00598C` | 96 | 7.48 | Logo, links, buttons, stat headlines, nav bars |
| Primary dark | Deep Navy | `#003356` | 20 | 13.06 | Dark backgrounds, hover states |
| Primary dark | Indigo | `#262768` | 15 | 13.35 | Hero banner background (`bg-navy`) |
| Accent | Bright Cyan | `#00B4F0` (approx.) | image only | 2.39 | Hero banner ring |
| Accent | Teal | `#00A0A4` | 36 | 3.20 | Accents, brand arcs |
| Accent | Magenta | `#CB187D` | 27 | 5.29 | Section blocks, brand arcs |
| Accent | Purple | `#5C2F92` | 24 | 9.22 | Purple 2025 background panels |
| Accent | Orange | `#F58220` | 24 | 2.59 | Brand arcs |
| Accent | Lime | `#AAC932` | 20 | 1.89 | Brand arcs, purple panel highlights |
| Accent | Green | `#2C8641` | 20 | 4.57 | Section blocks |
| Accent | Gold | `#FDB733` | 12 | 1.75 | Highlights |
| Alert | Red | `#B72032` | 13 | 6.43 | Alerts |
| Alert | Orange-red | `#CC401D` | n/a (seen as background) | 4.86 | Section block on Who We Are |
| Text | Text Gray | `#58595B` | 154 | 7.01 | Main body and nav text |
| Text | Body Dark | `#333333` | 109 | 12.63 | Body copy, h2 |
| Text | Mid Gray | `#6E6E6E` | 14 | 5.10 | Secondary text |
| Background | Page Gray | `#F4F4F4` | 43 | — | Page background |
| Background | Panel Gray | `#DCDDDE` | 21 | — | Banner panels |
| Lines | Border Gray | `#DDDDDD` / `#CCCCCC` | 49 / 27 | — | Borders, dividers |

## Proposed Power BI theme mapping

| Theme setting | Value | Why |
|---|---|---|
| `dataColors` (in order) | `#00598C`, `#00A0A4`, `#CB187D`, `#F58220`, `#5C2F92`, `#2C8641`, `#262768`, `#AAC932` | Brand blue first; the next colours alternate warm and cool so neighbouring series stay distinct |
| `foreground` (main text) | `#333333` | Site body colour, 12.6:1 contrast |
| `foregroundNeutralSecondary` (labels, axes) | `#58595B` | Site's main UI text grey, 7.0:1 |
| `foregroundNeutralTertiary` (quiet text) | `#6E6E6E` | 5.1:1, still readable |
| `background` (visuals) | `#FFFFFF` | Visual cards |
| Page background (wallpaper) | `#F4F4F4` | Site page grey; white cards stand out against it |
| `tableAccent` | `#00598C` | Brand blue for table headers |
| `good` / `neutral` / `bad` | `#2C8641` / `#FDB733` / `#B72032` | Centene's own green, gold and red |
| `maximum` / `center` / `minimum` (diverging) | `#00598C` / `#FFFFFF` / `#CB187D` | Blue to magenta, both brand colours |
| Report title and header band | `#262768` with white text | Matches the hero banner (13.35:1 contrast) |
| KPI card values | `#00598C`, Roboto Bold | Mirrors the site's "By The Numbers" stat style |
| Font: titles | Roboto, Medium (500) | Site headings |
| Font: body, labels, data | Roboto, Regular (400) | Site body |

## Accessibility notes

- **Teal, orange, lime, gold and cyan are below 4.5:1 on white.** Use them only as chart fills and marks, never as text colour or thin lines that must be read.
- **Lime (1.89) and gold (1.75) are very light.** Data labels on them need dark text (`#333333`), and they're placed last in the data colour order so small charts don't use them.
- **Don't rely on colour alone** for the good/bad status: add an arrow or a +/- sign, because red–green differences are hard for colour-blind viewers.
- **Every colour used as text** (Centene Blue, Navy, Indigo, Purple, Magenta, Red, the three greys) passes 4.5:1 on both white and `#F4F4F4`.

## Open points

- **Q18 (added to the client questions document):** do they have an official brand guide or Power BI theme that should replace these website-derived values?
- Check Roboto rendering in Power BI Desktop on the Windows machine used for the demo.
- Theme file: [theme/centene-pi-theme.json](../theme/centene-pi-theme.json). It validates against Power BI's report theme schema 2.152 with 0 errors. Next step: apply it to the PBIP report with the report MCP server.
