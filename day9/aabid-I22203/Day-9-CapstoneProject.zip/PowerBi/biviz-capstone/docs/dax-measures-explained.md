# DAX measures explained: Centene PI report

All 36 measures in the `CentenePI` model, each with its DAX and a plain-language explanation of what every part does. Written 2026-10-05; measures 28 and 29 and four insight sentences were added on 2026-10-07 for the two audience pages, and measures 30 to 34 and eight more sentences the same day for the Analytic Detail and Provider Detail drill-through pages, and measures 35 and 36 and three more sentences for the Explore page. The DAX blocks are copied from the saved model file, `CentenePI.SemanticModel/definition/tables/PI Measures.tmdl`.

- **Where they live:** on the `PI Measures` table, in seven display folders.
- **Values quoted** are with no filters unless stated, and match the source CSVs.
- **Related document:** [kpi-dictionary.md](kpi-dictionary.md) has the status of each measure (final or interim) and the values it reconciles to.

## DAX functions used, in one line each

| Function | What it does |
|---|---|
| `SUM` | Adds up one column over the rows the current filters leave |
| `AVERAGE` | Takes the plain mean of one column |
| `COUNTROWS` | Counts the rows of a table |
| `DIVIDE` | Divides, returning blank instead of an error when the bottom number is zero |
| `SUMX` | Goes through a table row by row, calculates something for each row, and adds the results |
| `CALCULATE` | Re-runs a calculation with filters added or changed |
| `COALESCE` | Returns the first value that is not blank; used to show 0 instead of blank |
| `TOTALYTD` | Adds up from 1 January to the last date in the filter |
| `SAMEPERIODLASTYEAR` | Shifts the dates in the filter back one year |
| `HASONEVALUE` | True when exactly one value of a column is in the filter |
| `SELECTEDVALUE` | Returns the one value in the filter, or a fallback when there are several |
| `TOPN` | Keeps the top rows of a table by some value |
| `ADDCOLUMNS` | Adds a calculated column to a table inside a measure |
| `VALUES` | Lists the distinct values of a column in the current filter |
| `SUMMARIZE` | Lists the distinct combinations of several columns |
| `SELECTCOLUMNS` | Builds a new table that keeps only the columns you name, under names you choose |
| `CONCATENATEX` | Goes through a table row by row, builds a piece of text for each row, and joins the pieces with a separator |
| `SWITCH` | Picks one result out of several, depending on a value |
| `FORMAT` | Turns a number into text in a chosen format |
| `REMOVEFILTERS` | Ignores the filters on a table or column |
| `IF` | Returns one result when a test is true and another when it is false |
| `FILTER` | Keeps only the rows of a table that pass a test |
| `MAXX`, `MINX` | Go through a table row by row and return the largest or smallest value |
| `ISBLANK` | True when a value is blank |
| `ALL` | Returns a whole table or column, ignoring the filters on it |
| `VAR … RETURN` | Stores a value under a name so it can be reused |

## Savings

### 1. Total Savings

```dax
Total Savings = SUM ( 'PI Measures'[Total Savings Amount] )
```

Adds up `total_savings_amount` over the rows left by the current filters. Result: $156,764,903.24.

### 2. Pre-Pay Savings

```dax
Pre-Pay Savings = SUM ( 'PI Measures'[Pre-Pay Savings Amount] )
```

The same, for savings identified before the claim was paid. Result: $69,744,660.79.

### 3. Post-Pay Savings

```dax
Post-Pay Savings = SUM ( 'PI Measures'[Post-Pay Savings Amount] )
```

The same, for savings recovered after the claim was paid. Result: $87,020,242.45. Pre-pay plus post-pay equals total savings in every row.

### 4. Pre-Pay Share of Savings %

```dax
Pre-Pay Share of Savings % = DIVIDE ( [Pre-Pay Savings], [Total Savings] )
```

One measure divided by another: the part of savings that was pre-pay. `DIVIDE` is used instead of `/` so that a filter with no savings shows blank instead of an error. Result: 44.49%.

## Billed and paid

### 5. Total Billed

```dax
Total Billed = SUM ( 'PI Measures'[Total Billed Amount] )
```

Adds up what providers charged. Result: $6,332,770,753.40.

### 6. Total Paid

```dax
Total Paid = SUM ( 'PI Measures'[Total Paid Amount] )
```

Adds up what was paid. Result: $4,391,703,679.79.

### 7. Paid % of Billed

```dax
Paid % of Billed = DIVIDE ( [Total Paid], [Total Billed] )
```

Paid divided by billed. Result: 69.35%.

### 8. Savings % of Billed (interim)

```dax
Savings % of Billed (interim) = DIVIDE ( [Total Savings], [Total Billed] )
```

Savings divided by billed. It is plain arithmetic on two source columns and is labelled interim because the client has not defined a savings rate. Result: 2.48%.

### 28. Savings % of Paid (interim)

```dax
Savings % of Paid (interim) = DIVIDE ( [Total Savings], [Total Paid] )
```

Savings divided by paid: the same idea as measure 8, but measured against what was actually paid out. It is used on the Programme View page. Interim for the same reason: no savings rate has been defined. Result: 3.57%.

## Claim volumes (unit pending Q9)

The three source columns are named as amounts but hold whole numbers that look like claim counts. The measures show them as whole numbers with no currency symbol, and their names carry the source column name.

### 9. Claims Submitted (source: total_claims_submitted_amount)

```dax
Claims Submitted (source: total_claims_submitted_amount) = SUM ( 'PI Measures'[total_claims_submitted_amount] )
```

A plain sum. Result: 3,130,776.

### 10. Claims Pre-Edit Allowed (source: total_claims_pre_edit_allowed_amount)

```dax
Claims Pre-Edit Allowed (source: total_claims_pre_edit_allowed_amount) = SUM ( 'PI Measures'[total_claims_pre_edit_allowed_amount] )
```

A plain sum. Result: 2,848,948.

### 11. Claims Processed (source: total_claims_processed_amount)

```dax
Claims Processed (source: total_claims_processed_amount) = SUM ( 'PI Measures'[total_claims_processed_amount] )
```

A plain sum. Result: 2,715,219.

### 29. Savings per Processed Claim (interim)

```dax
Savings per Processed Claim (interim) = DIVIDE ( [Total Savings], [Claims Processed (source: total_claims_processed_amount)] )
```

Savings divided by the processed-claims total (measure 11). `DIVIDE` returns blank, not an error, if there are no processed claims in the filter. It is used on the Analytic Performance page to compare analytics: AN-0001 gives $89.17 and AN-0002 gives $39.00. Interim: it means "dollars per claim" only if the source column is a claim count, which is pending Q9. Result: $57.74.

## True positive rate (definition pending Q10)

The source gives a rate per row, stored as 55.5 for 55.5%. Rates must not be summed, and the client has not said how to combine them, so two averages are offered.

### 12. True Positive Rate - Simple Average (definition pending)

```dax
True Positive Rate - Simple Average (definition pending) = DIVIDE ( AVERAGE ( 'PI Measures'[True Positive Rate Pct] ), 100 )
```

- `AVERAGE` takes the plain mean of the row rates, so every row counts the same.
- Dividing by 100 turns 64.25 into 0.6425, which the percent format shows as 64.25%.

Example with rows 1 and 2 only: (55.5 + 85.4) ÷ 2 = 70.45%.

### 13. True Positive Rate - Savings Weighted (definition pending)

```dax
True Positive Rate - Savings Weighted (definition pending) =
DIVIDE (
    SUMX (
        'PI Measures',
        'PI Measures'[True Positive Rate Pct] * 'PI Measures'[Total Savings Amount]
    ),
    [Total Savings]
) / 100
```

- `SUMX` goes through the fact table row by row, multiplies each row's rate by its savings, and adds the results.
- Dividing by `[Total Savings]` makes that an average in which rows with more savings count more.
- Dividing by 100 converts it to a percentage.

Result: 64.38%. Example with rows 1 and 2 only: (55.5 × 483,087.78 + 85.4 × 449,906.50) ÷ 932,994.28 = 69.92%.

## Data quality

### 14. Fact Rows

```dax
Fact Rows = COUNTROWS ( 'PI Measures' )
```

Counts the fact rows left by the current filters. Result: 248.

### 15. Rows on a Not-Yet-Valid Version

```dax
Rows on a Not-Yet-Valid Version =
COALESCE (
    CALCULATE (
        [Fact Rows],
        'PI Measures'[History Version Check] = "Version not valid on row date"
    ),
    0
)
```

- `CALCULATE` re-runs `[Fact Rows]` with one more filter: only rows whose history check says the analytic or provider version was not yet valid on the row's date.
- `COALESCE ( …, 0 )` shows 0 instead of blank when no row matches, so a card never reads "(Blank)".

Result: 37.

### 16. Rows with PI Service Route Disagreement

```dax
Rows with PI Service Route Disagreement =
COALESCE (
    CALCULATE (
        [Fact Rows],
        'PI Measures'[PI Service Route Check] = "Routes disagree"
    ),
    0
)
```

The same pattern, counting rows whose own PI service differs from the service their analytic belongs to. Result: 96.

### 17. Rows with Group Client Mismatch

```dax
Rows with Group Client Mismatch =
COALESCE (
    CALCULATE (
        [Fact Rows],
        'PI Measures'[Employer Group Client Check] = "Group client differs from row client"
    ),
    0
)
```

The same pattern, counting rows whose employer group belongs to a different client than the row's client. Result: 9.

### 18. Savings Without a Known Employer Group

```dax
Savings Without a Known Employer Group =
CALCULATE (
    [Total Savings],
    'PI Measures'[Employer Group Status] <> "In lookup"
)
```

`CALCULATE` sums savings only for rows whose employer group status is not "In lookup": that is, the key is empty or points to a group the lookup does not contain. Result: $82,648,215.38, which is the 124 rows with no key. (It was $117,373,051.30 until 2026-10-06, when synthetic lookup rows were added for keys 2 to 6.)

### 19. Savings Without a Known Employer Group %

```dax
Savings Without a Known Employer Group % = DIVIDE ( [Savings Without a Known Employer Group], [Total Savings] )
```

The measure above divided by all savings. Result: 52.72%.

## Time intelligence

The sample is uneven (2 to 14 rows per month), so these two are for testing the date logic, not for trend claims. No visual uses them directly.

### 20. Total Savings YTD

```dax
Total Savings YTD = TOTALYTD ( [Total Savings], 'Date'[Date] )
```

`TOTALYTD` adds savings from 1 January to the last date in the current filter. It relies on `Date` being the marked date table. With no date filter it is blank, because the calendar runs to 2028 and that year has no data. At June 2025: $31,378,066.14.

### 21. Total Savings Prior Year

```dax
Total Savings Prior Year =
IF (
    HASONEVALUE ( 'Date'[Year] ),
    CALCULATE ( [Total Savings], SAMEPERIODLASTYEAR ( 'Date'[Date] ) )
)
```

- `SAMEPERIODLASTYEAR` shifts the dates in the filter back one year, and `CALCULATE` sums savings for those dates.
- `IF ( HASONEVALUE ( 'Date'[Year] ), … )` returns a value only when exactly one year is in the filter. Without it, an unfiltered view shifted the whole calendar back a year and returned the grand total.

With 2025 selected: $44,207,864.48, the 2024 total.

## Insights and titles

These six measures return text. They feed the dynamic titles, the chart tooltips and the Insights panels.

### 22. Selected PI Service

```dax
Selected PI Service = SELECTEDVALUE ( 'PI Service'[PI Service], "All PI services" )
```

`SELECTEDVALUE` returns the PI service when exactly one is in the filter, and "All PI services" otherwise. It supplies the "Full name" line in the PI service chart's tooltip and feeds the two titles below.

### 23. Service Detail Title

```dax
Service Detail Title = "PI Service Detail: " & [Selected PI Service]
```

`&` joins text. After a drill-through this reads "PI Service Detail: Prepayment Claim Editing"; with no drill-through it reads "PI Service Detail: All PI services". It is the banner on the Service Detail page.

### 24. Fact Rows Title

```dax
Fact Rows Title = "Fact rows for " & [Selected PI Service] & " (" & FORMAT ( [Fact Rows], "#,0" ) & " rows), with validation checks"
```

Joins the selected service with the row count. `FORMAT ( [Fact Rows], "#,0" )` turns the count into text with a thousands separator. Example: "Fact rows for Prepayment Claim Editing (13 rows), with validation checks".

### 25. Insight Text

```dax
Insight Text =
VAR InsightId = SELECTEDVALUE ( Insight[Insight ID] )
VAR Total = [Total Savings]
VAR PrePay = [Pre-Pay Savings]
VAR PostPay = [Post-Pay Savings]
VAR TotalText = "$" & FORMAT ( DIVIDE ( Total, 1000000 ), "#,0.00" ) & "M"
-- top PI service
VAR TopService = TOPN ( 1, ADDCOLUMNS ( VALUES ( 'PI Service'[PI Service] ), "@Savings", [Total Savings] ), [@Savings], DESC )
VAR TopServiceName = MAXX ( TopService, 'PI Service'[PI Service] )
VAR TopServiceSavings = MAXX ( TopService, [@Savings] )
VAR ServiceCount = COUNTROWS ( FILTER ( VALUES ( 'PI Service'[PI Service] ), [Fact Rows] > 0 ) )
-- top line of business
VAR TopLob = TOPN ( 1, ADDCOLUMNS ( VALUES ( 'Line of Business'[Line of Business] ), "@Savings", [Total Savings] ), [@Savings], DESC )
VAR TopLobName = MAXX ( TopLob, 'Line of Business'[Line of Business] )
VAR TopLobSavings = MAXX ( TopLob, [@Savings] )
-- sample size by reporting month
VAR MonthRows = FILTER ( ADDCOLUMNS ( VALUES ( 'Date'[Month Start] ), "@Rows", [Fact Rows] ), [@Rows] > 0 )
VAR MonthCount = COUNTROWS ( MonthRows )
-- top analytic, grouped by analytic code
VAR TopAnalytic = TOPN ( 1, ADDCOLUMNS ( SUMMARIZE ( Analytic, Analytic[Analytic Code], Analytic[Analytic Description] ), "@Savings", [Total Savings], "@Rows", [Fact Rows] ), [@Savings], DESC )
VAR TopAnalyticCode = MAXX ( TopAnalytic, Analytic[Analytic Code] )
VAR TopAnalyticName = MAXX ( TopAnalytic, Analytic[Analytic Description] )
VAR TopAnalyticSavings = MAXX ( TopAnalytic, [@Savings] )
VAR TopAnalyticRows = MAXX ( TopAnalytic, [@Rows] )
VAR AnalyticText = TopAnalyticCode & " (" & TopAnalyticName & ") leads with $" & FORMAT ( DIVIDE ( TopAnalyticSavings, 1000000 ), "#,0.00" ) & "M, " & FORMAT ( DIVIDE ( TopAnalyticSavings, Total ), "0.0%" ) & " of savings in the filter, from " & FORMAT ( TopAnalyticRows, "#,0" ) & " rows."
-- top provider, grouped by NPI; the name shown is the lookup's current version
VAR TopProvider = TOPN ( 1, ADDCOLUMNS ( VALUES ( Provider[Provider NPI] ), "@Savings", [Total Savings] ), [@Savings], DESC )
VAR TopProviderNpi = MAXX ( TopProvider, Provider[Provider NPI] )
VAR TopProviderSavings = MAXX ( TopProvider, [@Savings] )
VAR TopProviderName = MAXX ( FILTER ( ALL ( Provider ), Provider[Provider NPI] = TopProviderNpi && Provider[Provider Is Current] ), Provider[Provider Name] )
-- pre-pay and post-pay split, larger side first
VAR PrePayText = "$" & FORMAT ( DIVIDE ( PrePay, 1000000 ), "#,0.00" ) & "M"
VAR PostPayText = "$" & FORMAT ( DIVIDE ( PostPay, 1000000 ), "#,0.00" ) & "M"
VAR TimingText =
    IF (
        PostPay >= PrePay,
        "Post-pay savings are " & FORMAT ( DIVIDE ( PostPay, Total ), "0.0%" ) & " of savings (" & PostPayText & " of " & TotalText & "); pre-pay is the other " & FORMAT ( DIVIDE ( PrePay, Total ), "0.0%" ) & ".",
        "Pre-pay savings are " & FORMAT ( DIVIDE ( PrePay, Total ), "0.0%" ) & " of savings (" & PrePayText & " of " & TotalText & "); post-pay is the other " & FORMAT ( DIVIDE ( PostPay, Total ), "0.0%" ) & "."
    )
-- share of all services, ignoring the PI service filter
VAR AllServices = CALCULATE ( [Total Savings], REMOVEFILTERS ( 'PI Service' ) )
-- employer group coverage: rows with no key, rows whose key the lookup lacks, rows on synthetic group names
VAR NoKeySavings = COALESCE ( CALCULATE ( [Total Savings], 'PI Measures'[Employer Group Status] = "Not supplied" ), 0 )
VAR MissingKeySavings = COALESCE ( CALCULATE ( [Total Savings], 'PI Measures'[Employer Group Status] = "Not in lookup" ), 0 )
VAR SyntheticSavings = COALESCE ( CALCULATE ( [Total Savings], 'Employer Group'[Employer Group Origin] = "Synthetic" ), 0 )
VAR GroupText =
    FORMAT ( DIVIDE ( NoKeySavings, Total ), "0.0%" ) & " of savings ($" & FORMAT ( DIVIDE ( NoKeySavings, 1000000 ), "#,0.00" ) & "M) is on rows with no employer group key."
        & IF ( MissingKeySavings > 0, " A further " & FORMAT ( DIVIDE ( MissingKeySavings, Total ), "0.0%" ) & " ($" & FORMAT ( DIVIDE ( MissingKeySavings, 1000000 ), "#,0.00" ) & "M) has a key the lookup does not contain.", "" )
        & IF ( SyntheticSavings > 0, " A further " & FORMAT ( DIVIDE ( SyntheticSavings, Total ), "0.0%" ) & " ($" & FORMAT ( DIVIDE ( SyntheticSavings, 1000000 ), "#,0.00" ) & "M) is on groups with synthetic names.", "" )
        & " Interim, pending Q4-Q6."
-- savings by funding type, largest first
VAR FundingRows = FILTER ( ADDCOLUMNS ( VALUES ( 'Funding Type'[Funding Type] ), "@Savings", [Total Savings] ), [@Savings] > 0 )
VAR FundingText = CONCATENATEX ( FundingRows, 'Funding Type'[Funding Type] & " $" & FORMAT ( DIVIDE ( [@Savings], 1000000 ), "#,0.00" ) & "M (" & FORMAT ( DIVIDE ( [@Savings], Total ), "0.0%" ) & ")", "; ", [@Savings], DESC ) & "."
-- savings against paid
VAR Paid = [Total Paid]
VAR PaidAmountText = IF ( Paid >= 1000000000, "$" & FORMAT ( DIVIDE ( Paid, 1000000000 ), "#,0.00" ) & "bn", "$" & FORMAT ( DIVIDE ( Paid, 1000000 ), "#,0.00" ) & "M" )
VAR PaidText = "Savings are " & FORMAT ( [Savings % of Paid (interim)], "0.00%" ) & " of paid (" & TotalText & " of " & PaidAmountText & "). Interim: plain arithmetic on two source columns; no savings rate has been defined."
-- per analytic code: true positive rate and savings per processed claim
VAR AnalyticRows = FILTER ( ADDCOLUMNS ( VALUES ( Analytic[Analytic Code] ), "@Rows", [Fact Rows], "@Rate", [True Positive Rate - Simple Average (definition pending)], "@Yield", [Savings per Processed Claim (interim)] ), [@Rows] > 0 )
VAR AnalyticCodeCount = COUNTROWS ( AnalyticRows )
VAR LowRate = TOPN ( 1, AnalyticRows, [@Rate], ASC )
VAR HighRate = TOPN ( 1, AnalyticRows, [@Rate], DESC )
VAR LowYield = TOPN ( 1, AnalyticRows, [@Yield], ASC )
VAR HighYield = TOPN ( 1, AnalyticRows, [@Yield], DESC )
VAR RateText =
    IF (
        AnalyticCodeCount = 1,
        MINX ( AnalyticRows, Analytic[Analytic Code] ) & " is the only analytic code in the filter, with a simple average of " & FORMAT ( MINX ( AnalyticRows, [@Rate] ), "0.00%" ) & ".",
        "By analytic code the simple average runs from " & FORMAT ( MINX ( LowRate, [@Rate] ), "0.00%" ) & " (" & MINX ( LowRate, Analytic[Analytic Code] ) & ") to " & FORMAT ( MAXX ( HighRate, [@Rate] ), "0.00%" ) & " (" & MAXX ( HighRate, Analytic[Analytic Code] ) & "), across " & AnalyticCodeCount & " codes."
    ) & " Interim, pending Q10."
VAR YieldText =
    "Savings per processed claim: $" & FORMAT ( [Savings per Processed Claim (interim)], "#,0.00" ) & " overall"
        & IF (
            AnalyticCodeCount = 1,
            " (" & MINX ( AnalyticRows, Analytic[Analytic Code] ) & " is the only analytic code in the filter).",
            "; highest " & MAXX ( HighYield, Analytic[Analytic Code] ) & " ($" & FORMAT ( MAXX ( HighYield, [@Yield] ), "#,0.00" ) & "), lowest " & MINX ( LowYield, Analytic[Analytic Code] ) & " ($" & FORMAT ( MINX ( LowYield, [@Yield] ), "#,0.00" ) & ")."
        )
        & " Interim: the unit of the claim columns is pending Q9."
-- reused by the drill-through pages
VAR TopServiceText = TopServiceName & " leads with $" & FORMAT ( DIVIDE ( TopServiceSavings, 1000000 ), "#,0.00" ) & "M, " & FORMAT ( DIVIDE ( TopServiceSavings, Total ), "0.0%" ) & " of savings, among " & ServiceCount & " PI services with rows in the filter."
VAR FlagsText = "Flagged rows: " & [Rows on a Not-Yet-Valid Version] & " on a not-yet-valid version, " & [Rows with PI Service Route Disagreement] & " with a service route disagreement, " & [Rows with Group Client Mismatch] & " with a group/client mismatch, out of " & FORMAT ( [Fact Rows], "#,0" ) & ". No row was changed."
-- drill-through pages: the selection against everything else in the same filter
VAR AllAnalytics = CALCULATE ( [Total Savings], REMOVEFILTERS ( Analytic ) )
VAR AllProviders = CALCULATE ( [Total Savings], REMOVEFILTERS ( Provider ) )
VAR AllAnalyticsRate = CALCULATE ( [True Positive Rate - Simple Average (definition pending)], REMOVEFILTERS ( Analytic ) )
VAR AllAnalyticsYield = CALCULATE ( [Savings per Processed Claim (interim)], REMOVEFILTERS ( Analytic ) )
VAR RowsText = FORMAT ( [Fact Rows], "#,0" )
VAR AccuracyText = "True positive rate " & FORMAT ( [True Positive Rate - Simple Average (definition pending)], "0.00%" ) & " (all analytics: " & FORMAT ( AllAnalyticsRate, "0.00%" ) & "); savings per processed claim $" & FORMAT ( [Savings per Processed Claim (interim)], "#,0.00" ) & " (all analytics: $" & FORMAT ( AllAnalyticsYield, "#,0.00" ) & "). Interim, pending Q9 and Q10."
-- Explore page: lowest and highest savings % of paid for three groupings
VAR ServiceRates = FILTER ( ADDCOLUMNS ( VALUES ( 'PI Service'[PI Service] ), "@Rows", [Fact Rows], "@Rate", [Savings % of Paid (interim)] ), [@Rows] > 0 )
VAR ServiceLow = TOPN ( 1, ServiceRates, [@Rate], ASC )
VAR ServiceHigh = TOPN ( 1, ServiceRates, [@Rate], DESC )
VAR ServiceRateText =
    IF (
        COUNTROWS ( ServiceRates ) = 1,
        MINX ( ServiceRates, 'PI Service'[PI Service] ) & " is the only PI service in the filter, with savings at " & FORMAT ( MINX ( ServiceRates, [@Rate] ), "0.00%" ) & " of paid.",
        "By PI service, savings run from " & FORMAT ( MINX ( ServiceLow, [@Rate] ), "0.00%" ) & " of paid (" & MINX ( ServiceLow, 'PI Service'[PI Service] ) & ") to " & FORMAT ( MAXX ( ServiceHigh, [@Rate] ), "0.00%" ) & " (" & MAXX ( ServiceHigh, 'PI Service'[PI Service] ) & "); overall " & FORMAT ( [Savings % of Paid (interim)], "0.00%" ) & "."
    ) & " Interim: no savings rate has been defined."
VAR LobRates = FILTER ( ADDCOLUMNS ( VALUES ( 'Line of Business'[Line of Business] ), "@Rows", [Fact Rows], "@Rate", [Savings % of Paid (interim)] ), [@Rows] > 0 )
VAR LobLow = TOPN ( 1, LobRates, [@Rate], ASC )
VAR LobHigh = TOPN ( 1, LobRates, [@Rate], DESC )
VAR LobRateText =
    IF (
        COUNTROWS ( LobRates ) = 1,
        MINX ( LobRates, 'Line of Business'[Line of Business] ) & " is the only line of business in the filter, with savings at " & FORMAT ( MINX ( LobRates, [@Rate] ), "0.00%" ) & " of paid.",
        "By line of business, savings run from " & FORMAT ( MINX ( LobLow, [@Rate] ), "0.00%" ) & " of paid (" & MINX ( LobLow, 'Line of Business'[Line of Business] ) & ") to " & FORMAT ( MAXX ( LobHigh, [@Rate] ), "0.00%" ) & " (" & MAXX ( LobHigh, 'Line of Business'[Line of Business] ) & "); overall " & FORMAT ( [Savings % of Paid (interim)], "0.00%" ) & "."
    ) & " Interim: no savings rate has been defined."
VAR ClientRates = FILTER ( ADDCOLUMNS ( VALUES ( Client[Client Name] ), "@Rows", [Fact Rows], "@Rate", [Savings % of Paid (interim)] ), [@Rows] > 0 )
VAR ClientLow = TOPN ( 1, ClientRates, [@Rate], ASC )
VAR ClientHigh = TOPN ( 1, ClientRates, [@Rate], DESC )
VAR ClientRateText =
    IF (
        COUNTROWS ( ClientRates ) = 1,
        MINX ( ClientRates, Client[Client Name] ) & " is the only client in the filter, with savings at " & FORMAT ( MINX ( ClientRates, [@Rate] ), "0.00%" ) & " of paid.",
        "By client, savings run from " & FORMAT ( MINX ( ClientLow, [@Rate] ), "0.00%" ) & " of paid (" & MINX ( ClientLow, Client[Client Name] ) & ") to " & FORMAT ( MAXX ( ClientHigh, [@Rate] ), "0.00%" ) & " (" & MAXX ( ClientHigh, Client[Client Name] ) & "); overall " & FORMAT ( [Savings % of Paid (interim)], "0.00%" ) & "."
    ) & " Interim: no savings rate has been defined."
RETURN
    IF (
        ISBLANK ( Total ),
        "No rows in the current filter.",
        SWITCH (
            InsightId,
            1, TimingText,
            2, TopServiceText,
            3, TopLobName & " is the largest line of business with $" & FORMAT ( DIVIDE ( TopLobSavings, 1000000 ), "#,0.00" ) & "M, " & FORMAT ( DIVIDE ( TopLobSavings, Total ), "0.0%" ) & " of savings.",
            4, FORMAT ( [Fact Rows], "#,0" ) & " rows across " & MonthCount & " reporting months, from " & MINX ( MonthRows, [@Rows] ) & " to " & MAXX ( MonthRows, [@Rows] ) & " rows per month. Uneven sample: differences between periods are not trends.",
            5, AnalyticText,
            6, TopProviderName & " (NPI " & TopProviderNpi & ") leads with $" & FORMAT ( DIVIDE ( TopProviderSavings, 1000000 ), "#,0.00" ) & "M, " & FORMAT ( DIVIDE ( TopProviderSavings, Total ), "0.0%" ) & " of savings in the filter.",
            7, GroupText,
            8, "Simple average " & FORMAT ( [True Positive Rate - Simple Average (definition pending)], "0.00%" ) & "; savings-weighted " & FORMAT ( [True Positive Rate - Savings Weighted (definition pending)], "0.00%" ) & ". Both are interim: how to combine row rates is pending Q10.",
            9, [Selected PI Service] & ": " & TotalText & " savings from " & FORMAT ( [Fact Rows], "#,0" ) & " rows, " & FORMAT ( DIVIDE ( Total, AllServices ), "0.0%" ) & " of savings across all PI services in the same filter.",
            10, AnalyticText,
            11, TimingText,
            12, FlagsText,
            13, FundingText,
            14, PaidText,
            15, YieldText,
            16, RateText,
            17, [Selected Analytic] & ": " & TotalText & " savings from " & RowsText & " rows, " & FORMAT ( DIVIDE ( Total, AllAnalytics ), "0.0%" ) & " of savings across all analytics in the same filter.",
            18, TopServiceText,
            19, AccuracyText,
            20, FlagsText,
            21, [Selected Provider] & ": " & TotalText & " savings from " & RowsText & " rows, " & FORMAT ( DIVIDE ( Total, AllProviders ), "0.0%" ) & " of savings across all providers in the same filter.",
            22, TopServiceText,
            23, TimingText,
            24, FlagsText,
            25, ServiceRateText,
            26, LobRateText,
            27, ClientRateText
        )
    )
```

One measure that returns a different sentence for each of the 27 rows of the `Insight` helper table.

- **Which sentence:** `SELECTEDVALUE ( Insight[Insight ID] )` finds the row being drawn, and the `SWITCH` at the end picks that row's sentence.
- **Shared values:** the `VAR` lines at the top calculate things once (total, pre-pay, post-pay) so several sentences can reuse them.
- **"Top" items:** `TOPN ( 1, ADDCOLUMNS ( VALUES ( … ), "@Savings", [Total Savings] ), [@Savings], DESC )` lists the categories in the filter, attaches each one's savings, and keeps the largest. `MAXX` then reads the name and the amount out of that one-row table.
- **Analytics and providers:** analytics are grouped by code and description with `SUMMARIZE`, and providers by NPI. The provider name shown is the lookup row marked current.
- **Months:** `MonthRows` lists the months that have rows, so the sample-size sentence can state how many months there are and the fewest and most rows in a month.
- **Timing sentence:** an `IF` leads with whichever of pre-pay and post-pay is larger.
- **Employer group coverage sentence:** three amounts are worked out with `CALCULATE`: savings on rows with no key, savings on rows whose key the lookup does not contain, and savings on groups flagged "Synthetic" in the lookup. `COALESCE ( …, 0 )` turns a blank into 0. The sentence always states the first amount, and the two `IF`s add the second and third only when they are above zero. With no filters it reads: "52.7% of savings ($82.65M) is on rows with no employer group key. A further 22.2% ($34.72M) is on groups with synthetic names. Interim, pending Q4-Q6."
- **Share of all services:** `CALCULATE ( [Total Savings], REMOVEFILTERS ( 'PI Service' ) )` gives savings across every service in the same filter, so a drilled-through service can be shown as a share of that.
- **Funding type sentence:** `FundingRows` lists the funding types that have savings in the filter. `CONCATENATEX` writes "name $x.xxM (share%)" for each one, largest first, and joins them with "; ".
- **Savings against paid sentence:** shows measure 28, then the two amounts behind it. `PaidAmountText` writes the paid amount in billions when it is at least $1bn and in millions otherwise.
- **Yield and rate sentences:** `AnalyticRows` lists each analytic code in the filter with its rows, its simple-average true positive rate and its savings per processed claim. `TOPN ( 1, …, ASC )` and `TOPN ( 1, …, DESC )` pick the lowest and the highest. When only one code is in the filter, an `IF` names that code instead of a highest and a lowest.
- **Sentences shared with the detail pages:** `TopServiceText` and `FlagsText` hold the "top PI service" and "flagged rows" sentences once, so the Overview, Service Detail, Analytic Detail and Provider Detail panels all reuse them.
- **Selection against everything else:** `AllAnalytics` and `AllProviders` use `CALCULATE ( …, REMOVEFILTERS ( Analytic ) )` or `REMOVEFILTERS ( Provider )` to get the figure for every analytic or provider in the same filter, so a drilled-through analytic or provider can be shown as a share of that. `AllAnalyticsRate` and `AllAnalyticsYield` do the same for the true positive rate and the savings per processed claim.
- **Rate sentences (Explore page):** for PI service, line of business and client in turn, a table lists each item in the filter with its rows and its savings % of paid; `TOPN ( 1, …, ASC )` and `TOPN ( 1, …, DESC )` pick the lowest and the highest, and an `IF` names the single item when only one is in the filter.
- **Money as text:** `"$" & FORMAT ( DIVIDE ( x, 1000000 ), "#,0.00" ) & "M"` shows an amount in millions.
- **Empty filter:** `IF ( ISBLANK ( Total ), … )` returns "No rows in the current filter."

### 26. Insight Colour

```dax
Insight Colour =
VAR InsightId = SELECTEDVALUE ( Insight[Insight ID] )
VAR NoGroupShare = [Savings Without a Known Employer Group %]
VAR FlaggedRows = [Rows on a Not-Yet-Valid Version] + [Rows with PI Service Route Disagreement] + [Rows with Group Client Mismatch]
RETURN
    SWITCH (
        InsightId,
        7, IF ( NoGroupShare > 0.5, "#B72032", IF ( NoGroupShare > 0, "#CC401D", "#2C8641" ) ),
        12, IF ( FlaggedRows > 0, "#CC401D", "#2C8641" ),
        20, IF ( FlaggedRows > 0, "#CC401D", "#2C8641" ),
        24, IF ( FlaggedRows > 0, "#CC401D", "#2C8641" ),
        4, "#58595B",
        "#333333"
    )
```

Returns a colour code for each insight row; the Insights table uses it as the text colour (conditional formatting).

- Row 7, employer group coverage: red above 50% of savings with no known group, orange-red above 0%, green at 0%.
- Rows 12, 20 and 24, validation flags: orange-red when any row is flagged, green when none.
- Row 4, sample size: grey.
- Everything else: the normal dark text.

The thresholds are a presentation choice, not a client rule.

### 27. Selected Analytic

```dax
Selected Analytic = SELECTEDVALUE ( Analytic[Analytic Label], "All analytics" )
```

Returns the analytic (code and description) when exactly one is in the filter, and "All analytics" otherwise. It supplies the "Full name" line in the analytic chart's tooltip, where the axis shows only the first 15 characters.

### 30. Analytic Detail Title

```dax
Analytic Detail Title = "Analytic Detail: " & [Selected Analytic]
```

Joins fixed text to measure 27 with `&`. It is the banner of the Analytic Detail drill-through page, so the banner names whichever analytic was right-clicked: "Analytic Detail: AN-0001 Duplicate Claim Detection".

### 31. Analytic Fact Rows Title

```dax
Analytic Fact Rows Title = "Fact rows for " & [Selected Analytic] & " (" & FORMAT ( [Fact Rows], "#,0" ) & " rows)"
```

The title of the fact-row table on Analytic Detail. `FORMAT ( [Fact Rows], "#,0" )` turns the row count into text so it can be joined to the rest: "Fact rows for AN-0001 Duplicate Claim Detection (37 rows)".

### 32. Selected Provider

```dax
Selected Provider =
VAR Npi = SELECTEDVALUE ( Provider[Provider NPI] )
VAR CurrentName = MAXX ( FILTER ( ALL ( Provider ), Provider[Provider NPI] = Npi && Provider[Provider Is Current] ), Provider[Provider Name] )
RETURN
    IF ( ISBLANK ( Npi ), "All providers", CurrentName )
```

Finds the one provider in the filter by NPI, not by name (Issue 5).

- `SELECTEDVALUE ( Provider[Provider NPI] )` returns the NPI when exactly one is in the filter, and blank otherwise.
- `FILTER ( ALL ( Provider ), … )` looks through the whole provider lookup for the row with that NPI that is marked current, and `MAXX` reads its name. `ALL` is needed because the filter may be on an older version of the provider.
- `IF ( ISBLANK ( Npi ), … )` returns "All providers" when there is no single NPI.

For NPI 1567892341 it returns "Sunrise Rehabilitation Hospital LLC", the current name, not the earlier "Sunrise Rehabilitation Hospital".

### 33. Provider Detail Title

```dax
Provider Detail Title = "Provider Detail: " & [Selected Provider]
```

The banner of the Provider Detail drill-through page: fixed text joined to measure 32.

### 34. Provider Fact Rows Title

```dax
Provider Fact Rows Title =
VAR Npi = SELECTEDVALUE ( Provider[Provider NPI] )
RETURN
    "Fact rows for " & [Selected Provider] & IF ( ISBLANK ( Npi ), "", ", NPI " & Npi ) & " (" & FORMAT ( [Fact Rows], "#,0" ) & " rows)"
```

The title of the fact-row table on Provider Detail. The `IF` adds ", NPI …" only when one provider is in the filter: "Fact rows for Sunrise Rehabilitation Hospital LLC, NPI 1567892341 (41 rows)".

### 35. Explore Title

```dax
Explore Title =
VAR PickedMeasure = SELECTCOLUMNS ( SUMMARIZE ( 'Explore Measure', 'Explore Measure'[Explore Measure], 'Explore Measure'[Explore Measure Fields] ), "@Name", 'Explore Measure'[Explore Measure] )
VAR PickedGrouping = SELECTCOLUMNS ( SUMMARIZE ( 'Explore By', 'Explore By'[Explore By], 'Explore By'[Explore By Fields] ), "@Name", 'Explore By'[Explore By] )
RETURN
    IF ( COUNTROWS ( PickedMeasure ) = 1, MAXX ( PickedMeasure, [@Name] ), "Selected measures" )
        & "  |  Group by: "
        & IF ( COUNTROWS ( PickedGrouping ) = 1, MAXX ( PickedGrouping, [@Name] ), "several" )
```

The title of the chart on the Explore page. It names what the two dropdowns are set to.

- **Why it looks roundabout:** `Explore Measure` and `Explore By` are field-parameter tables. In such a table the visible column is tied to a hidden companion column, and the engine refuses to read one without the other, so `SELECTEDVALUE` fails. `SUMMARIZE` over both columns satisfies the rule, and `SELECTCOLUMNS` then keeps just the visible name.
- **`COUNTROWS ( … ) = 1`:** true when exactly one choice is picked; `MAXX` then reads its name. Otherwise fallback text is shown.

With the default picks it returns "Savings % of paid (interim)  |  Group by: PI service".

### 36. Savings % of Paid Colour

```dax
Savings % of Paid Colour =
VAR Rate = [Savings % of Paid (interim)]
VAR Overall = CALCULATE ( [Savings % of Paid (interim)], REMOVEFILTERS ( 'PI Service' ), REMOVEFILTERS ( 'Line of Business' ) )
RETURN
    IF ( ISBLANK ( Rate ), BLANK (), IF ( Rate >= Overall, "#D6EAF5", "#FCE9C8" ) )
```

Returns a background colour for each cell of the matrix on the Explore page.

- `Rate` is the cell's own savings % of paid.
- `Overall` is the same measure with the PI service and line of business filters removed by `REMOVEFILTERS`, so it is the rate for everything in the current Year and Client selection.
- The cell is light blue when its rate is at or above that overall rate and light amber when below; an empty cell gets no colour.

It is a reading aid, not a target: 6.41% (Prepayment Claim Editing, Commercial) is blue and 1.46% (Data Mining, Commercial) is amber against an overall 3.57%.
