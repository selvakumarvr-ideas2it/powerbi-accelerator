# Day 9 Exercise — Build and certify your chosen capstone

Source: Ideas2IT BI Visualization Accelerator
- Exercise: https://bivizstyq67gc2er6uww.z13.web.core.windows.net/exercise/exercise-day-9
- Captured: 2026-10-01
- Study guide (rubric, critical failures, demo structure): [day9-study-guide.md](day9-study-guide.md)

---

## Objective
Build, validate and demo one of the three certification capstones end-to-end, meeting every common
capstone requirement.

## Business scenario
This is the certification deliverable. Choose one of `capstone-healthcare`, `capstone-supplychain`
or `capstone-sales360` and deliver it as if to the real customer described in that capstone's brief.

## Dataset
One of the following. The chosen capstone's brief lists the exact tables.
| Capstone | Dataset | Tables |
|---|---|---|
| `capstone-healthcare` | Healthcare | FactClaims, DimMember, DimProvider |
| `capstone-supplychain` | Supply Chain | FactInventory, DimSupplier, DimWarehouse |
| `capstone-sales360` | Sales | FactSales, FactTargets, DimCustomer, DimProduct, DimRegion, DimDate |

## Requirements
1. Choose one capstone and build its required data model.
2. Implement all required KPIs for that capstone as validated DAX measures.
3. Build all required pages, with drill-down or drill-through.
4. Build a validation sheet with at least 10 explicit tests that reconcile KPIs to expected values.
5. Produce a Claude prompt log documenting the AI-assisted work and the validation performed during the build.
6. Rehearse and deliver a 10-minute customer demo followed by 5 minutes of Q&A.

## Expected outcome
A complete, reconciled capstone package that is ready for the certification demo and meets the
chosen capstone's own acceptance criteria.

### Deliverables
- [ ] Data model (`.pbix` / `.pbip`)
- [ ] Report (3 pages)
- [ ] Validation sheet (10+ tests)
- [ ] KPI dictionary
- [ ] Model diagram
- [ ] Claude prompt log

## Acceptance criteria
- [ ] The report has exactly the required pages for the chosen capstone (**three pages**), **at least 8 DAX measures** and **3+ slicers**
- [ ] At least one drill-down or drill-through path is implemented **and tested**
- [ ] The validation sheet contains **10 tests**, and every primary KPI reconciles to its expected or supplied value
- [ ] A **model diagram** and a **KPI dictionary** are included in the submission
- [ ] A **Claude prompt log** is included, documenting the prompts used and the validation performed
- [ ] The chosen capstone's own acceptance criteria are fully met
- [ ] The 10-minute demo plus 5-minute Q&A is rehearsed and ready to deliver

## Hints
- Re-read the chosen capstone brief's acceptance criteria before you start. Build to the criteria, not to habit.
- Budget time for the validation sheet. It is graded as heavily as the report itself.
- Practise explaining your own DAX out loud. "I can't explain my own logic" is a certification critical failure.

## Submission
Submitted through the form on the exercise page (click "Start Exercise" first):
- GitHub repository URL
- Branch
- Commit or PR URL
- Comments

---

## Open items
- [ ] Choose the capstone
- [ ] Capture that capstone's brief (KPI list, required pages, specific acceptance criteria, expected values)
- [ ] Get the dataset files
- [ ] Create the GitHub repository for submission
