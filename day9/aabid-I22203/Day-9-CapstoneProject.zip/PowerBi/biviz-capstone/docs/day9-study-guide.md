# Day 9 — Capstone + Certification (Study Guide)

Source: Ideas2IT BI Visualization Accelerator
- Exercise page: https://bivizstyq67gc2er6uww.z13.web.core.windows.net/exercise/exercise-day-9
- Captured: 2026-10-01

---

## What "done" means
Everything from Days 1–8 converges into one capstone package a real customer could receive:
BI fundamentals and Power BI architecture, Power Query and data connectivity, semantic modelling,
visualization and report UX, DAX essentials and interactive report development, rapid prototyping,
Claude-assisted development (including your own Claude Skill), and legacy migration discipline.
Day 9 is about proving these skills, not learning new ones.

## Choose one capstone
| Capstone | Title | Dataset tables |
|---|---|---|
| `capstone-healthcare` | Healthcare Financial & Claims Dashboard | FactClaims, DimMember, DimProvider |
| `capstone-supplychain` | Supply Chain Command Center | FactInventory, DimSupplier, DimWarehouse |
| `capstone-sales360` | Sales & Customer 360 | FactSales, FactTargets, DimCustomer, DimProduct, DimRegion, DimDate |

Each capstone has its own KPI list, required pages and acceptance criteria in its brief. Read
the brief before you build. (The briefs have not been captured yet.)

## Technical validation
- **Critical failure:** presenting unvalidated AI output as correct.
- Every KPI must reconcile to a supplied or SQL-derived expected value before demo day.
- The validation sheet needs **at least 10 explicit tests** covering:
  - filter combinations
  - totals
  - time intelligence
  - drill-through
  - reconciliation to SQL

## Presentation: 10-minute demo plus 5-minute Q&A
Walk through, in this order:
1. The original requirement
2. Your design decisions
3. The report itself
4. The insights it surfaces
5. How you validated the numbers
6. The trade-offs you made because it is a prototype, not a hardened production system

Practise defending your own DAX out loud.

## Production hardening (beyond the prototype; discuss as trade-offs)
- **Security:** row-level security, workspace permissions
- **Performance:** query folding, aggregations, incremental refresh
- **Governance:** naming standards, documentation
- **Scheduled refresh**
- **Maintainability plan** for when the schema changes

## Certification rubric
| Area | Weight |
|---|---|
| BI fundamentals & Power BI architecture | 10% |
| Power Query & data connectivity | 15% |
| Semantic modelling | 15% |
| DAX & KPI correctness | 15% |
| Visualization & report UX | 10% |
| Interactive report development | 10% |
| Rapid prototyping | 5% |
| Claude-assisted development (incl. Claude Skill authoring) | 10% |
| Legacy migration | 5% |
| Capstone delivery | 5% |

**Pass: 70%+ overall with no critical failure.**
- 90–100%: Advanced Practitioner
- 80–89%: Practitioner
- 70–79%: Certified Foundation
- Below 70%: Reassessment

**Critical failures (fail regardless of score):**
- Materially incorrect KPI results that go undetected
- A fundamentally broken model
- Being unable to explain your own DAX
- Missing reconciliation of important numbers
- Presenting unvalidated AI output as correct

## Lab plan
- Hour 1: Build or finalize the chosen capstone
- Hour 2: Complete the validation sheet
- Hour 3: Rehearse the 10-minute demo
- Hour 4: Live Q&A and certification assessment

## Resources
- Microsoft Learn: Power BI documentation home
- SQLBI: DAX Guide (function reference)
- Microsoft Learn: Understand star schema and its importance for Power BI

---

## Exercise
The exercise requirements, acceptance criteria and submission details are in
[day9-exercise.md](day9-exercise.md).
