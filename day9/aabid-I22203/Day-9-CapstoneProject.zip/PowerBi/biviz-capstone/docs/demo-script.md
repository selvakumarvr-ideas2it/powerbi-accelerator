# Demo script: Centene PI report

A walk-through of the eight-page report, about 12 minutes. Written 2026-10-07 for the page order Home, Overview, Service Detail, Programme View, Provider Detail, Analytic Performance, Analytic Detail, Explore.

- **Figures:** every figure here has been checked against the source CSVs (see [validation-sheet.md](validation-sheet.md)). If the data or a measure changes, re-check the figures before presenting.
- **Buttons:** in Power BI Desktop, buttons need Ctrl+click. In a published report a plain click works.
- **Personas:** the four roles on the Home page are a prediction made for this exercise, not something the client supplied.

## Before you start

- Open `CentenePI.pbip`. It opens on Home with nothing selected.
- If a detail page still shows an earlier selection, press Back on it, then Reset filters.

## 1. Home (1 minute)

- **Say:** "This report serves two organisations. Centene is the payer; Optum is a payment integrity vendor Centene uses. There is one view per role."
- **Point to "Read this first":** "The data has no vendor column, so every row is treated as in scope for both. That is an assumption, and it is client question 19. Anything labelled interim is waiting on a client definition."
- **Click:** Open Overview.

## 2. Overview: Centene management (2.5 minutes)

- **Cards:** "Total savings are $156.76M: $69.74M stopped before payment and $87.02M recovered after. That is against $6.33bn billed and $4.39bn paid."
- **PI service chart:** "Coordination of Benefits leads with $26.48M, 16.9% of savings."
- **Year chart:** click the drill-down arrow twice. "Year, quarter, month. The sample is uneven, 2 to 14 rows a month, so I make no trend claims." Drill back up.
- **Year slicer → 2025:** "Savings for 2025 are $54.52M."
- **Right-click the Prepayment Claim Editing bar → Drill through → Service Detail.**

## 3. Service Detail (1 minute)

- **Say:** "The title follows what I clicked, and 2025 came with me: 13 rows, $11.98M."
- **Cards:** "These are data-quality checks. All 13 rows have a service route disagreement, which is an open client question. No row was changed."
- **Click:** Back, then Reset filters.

## 4. Programme View: Centene client account manager (2.5 minutes)

- **Click:** Programme View in the banner.
- **Cards:** "Savings are 3.57% of what was paid. 44.49% is pre-pay."
- **Funding chart and Insights:** "Fully Insured is $81.03M and Administrative Services Only is $75.73M."
- **Employer group chart:** "52.72% of savings has no employer group key. Groups 2 to 6 carry synthetic names, as the title says."
- **Client slicer → HealthFirst Employer Trust:** "This client's savings are $73.61M." Then Reset filters.
- **Right-click the Sunrise Rehabilitation Hospital LLC row → Drill through → Provider Detail.**

## 5. Provider Detail (1 minute)

- **Say:** "Sunrise: $29.86M from 41 rows, 3.89% of paid. 19 of those rows point to a provider or analytic version that was not yet valid on the row's date, another open question."
- **PI service chart:** "Its largest service is Prepayment Claim Editing at $8.01M." Optionally right-click that bar → Service Detail to show the chain (4 rows), then Back.
- **Click:** Back.

## 6. Analytic Performance: Optum analytics owner (2 minutes)

- **Click:** Analytic Performance.
- **Cards:** "True positive rate is 64.25% as a simple average and 64.38% weighted by savings; the definition is pending. Savings per processed claim is $57.74, interim until the claim columns' unit is confirmed."
- **Middle chart (columns and line):** "Columns are savings, the line is the true positive rate. AN-0001 saves the most, $38.28M, but its rate is 60.65%. AN-0005 has the highest rate, 69.92%."
- **Right-click the AN-0001 bar → Drill through → Analytic Detail:** "37 rows, $89.17 per claim, 89.76% pre-pay. Coordination of Benefits is 69.2% of its savings."
- **Click:** Back.

## 7. Explore: Optum sales and growth (1.5 minutes)

- **Click:** Home, then Open Explore.
- **Say:** "One chart, two dropdowns." The default shows savings % of paid by PI service: "5.45% for Prepayment Claim Editing down to 2.63% for Data Mining."
- **Matrix:** "Blue is at or above the overall 3.57%, amber is below. Prepayment Claim Editing is 6.41% in Commercial but 3.03% in Medicaid. This is a comparison; the data cannot say why."
- **Switch Show → True positive rate, Group by → Analytic:** "Same chart, new question: 69.92% down to 60.44%." Switch back to Savings % of paid and PI service.

## 8. Close (30 seconds)

- "Every number reconciles to the source files: 52 tests, all passing."
- "Open items are with the client: 19 questions, including the true positive rate definition, the claim columns' unit, and which rows are the vendor's."
- "Not in the data, so not in the report: vendor fees, appeals, and recovered versus identified amounts."

## If asked

- **"Why did Reset not clear the detail page?"** A selection made before a drill-through travels with it; Back clears it.
- **"Can Optum see Centene's provider page?"** Yes. The Home buttons are shortcuts, not access control.
- **"Whose savings are these, Optum's or Centene's?"** The data cannot say. No row names who did the checking, which is why question 19 is open.
- **"Are the employer groups real?"** One is as delivered (HealthFirst Trust Members). Groups 2 to 6 have synthetic names added for this exercise, and 124 rows have no group key at all.
