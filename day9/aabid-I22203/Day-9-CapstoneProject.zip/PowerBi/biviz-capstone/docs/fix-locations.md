# Where each data fix happens

Which of the Centene PI dataset fixes can be done in Power Query (Power BI data transformation), and what is needed elsewhere (model, DAX, report or client).

Issue details and client questions: [Centene PI Dataset: Data Quality Issues & Client Clarifications](https://claude.ai/code/artifact/4516e5f8-5bfb-4d4b-a699-9e10d9925ed0)

| # | Issue | Power Query? | What Power Query does | What's still needed elsewhere |
|---|---|---|---|---|
| 1 | Swapped files | **Fixed in the files** | Nothing to do now. On 2026-10-06 the two files were renamed so each name matches its contents (originals kept in `centene-data-original/`); `PI Service` loads `dim_pi_service.csv` and `Employer Group` loads `dim_employer_group.csv` | Nothing |
| 2 | Date codes don't match | **Yes** | Add a column that converts `20250401` to the date 2025-04-01 | **Model:** link that new column to the date table's `full_date` |
| 3 | The word "null" | **Yes, fully** | *Replace Values* turns `"null"` into a real empty value, then *Change Type* | Nothing |
| 4 | Missing employer groups | **Partly** | Add a label column: the group name when the key is found, "Not in lookup (key n)" when it is not, or "Not supplied" when there is no key. Since 2026-10-06 keys 2–6 are found, through five synthetic lookup rows | **Client:** only they can supply the real groups 2–6 and explain the 124 rows with no key (Q4–Q6) |
| 5 | Wrong history versions | **Only as a check** | Add a flag column marking rows whose version wasn't valid on their date, for the validation sheet. Re-pointing rows is technically possible, but not done until the client answers Q7 | **Report:** group visuals by `analytic_code` and NPI |
| 6 | Counts named as amounts | **Mostly** | Set the three columns' type to whole number. The columns keep their source names (for example `total_claims_submitted_amount`); they are not renamed, because the unit is still pending Q9 | **Model:** whole-number format, no currency symbol, columns hidden. **DAX:** the measure carries the readable label, for example *Claims submitted (source: total_claims_submitted_amount)* |
| 7 | True positive rate gets summed | **No** | Nothing to transform; the values themselves are fine | **Model:** turn off default summing on the column. **DAX:** the two average measures |
| 8 | Two routes to service | **Only as a check** | Add a flag column marking the 96 rows where the two routes disagree, for the validation sheet | **Model:** don't create the Analytic → PI Service link |
| 9 | Claim status not linked | **Yes, trivially** | Untick *Enable load* so the table isn't loaded into the model | Write a note in the model documentation |
| 10 | Uneven sample | **No** | Nothing to fix in the data | **Demo:** explain it rather than presenting trends |
| 11 | Calendar details | **Partly** | Could filter the date table to 2023–2025, but all dates are left in and charts are limited instead | **Model:** mark as date table. **Report:** limit axes, hide empty slicer items, don't use `week_of_year` |

## Summary

- **Fixed in the source files (2026-10-06, at the report owner's request):** 1 (renamed), and 4 in part (synthetic groups 2–6).
- **Fully fixed in Power Query:** 2 (plus one relationship), 3, 6 (plus formatting), 9.
- **Power Query helps, with work elsewhere:** 4 (labels), 5 and 8 (validation flag columns), 11.
- **Outside Power Query:** 7 (model and DAX) and 10 (how it is presented).

On Linux, these steps are written as Power Query (M) code inside the PBIP project files using the modeling MCP server. They only run for real when the project is opened in Power BI Desktop on Windows.
