# KPI dictionary: Centene PI report

All 36 DAX measures in the `CentenePI` semantic model, with what each one means, its formula and the value it must reconcile to. Written 2026-10-04; measures 22 to 27 were added the same day for the Insights panels, the dynamic titles and the chart tooltips. Measures 28 and 29 were added on 2026-10-07 for the two audience pages (Programme View for Centene, Analytic Performance for Optum); they keep the next free numbers but sit in the sections they belong to. Measures 30 to 34 were added the same day for the Analytic Detail and Provider Detail drill-through pages, and measures 35 and 36 for the Explore page.

- **Where the measures live:** on the fact table `PI Measures`, grouped into seven display folders.
- **How the expected values were produced:** summed straight from `centene-data/fact_pi_measures.csv` with a script outside Power BI, then compared with the measure's result from a DAX query on the loaded model. All 21 numeric measures matched on 2026-10-04. The five text measures were checked sentence by sentence against the same CSV figures. Measures 28 and 29 were checked the same way on 2026-10-07 (validation tests V21 and V22).
- **Data change on 2026-10-06:** the two swapped lookup files were renamed and five synthetic employer groups (keys 2 to 6) were added at the report owner's request. Only measures 18 and 19 and one Insights sentence changed value; every other figure here is unchanged. See `centene-data/README.md`.
- **Status meanings:** *Final* means the files themselves prove the calculation. *Interim* means the calculation is plain arithmetic on source values but its business definition waits on a numbered client question.
- **Issue and question numbers** refer to [Centene PI Dataset: Data Quality Issues & Client Clarifications](https://claude.ai/code/artifact/4516e5f8-5bfb-4d4b-a699-9e10d9925ed0).

## Summary

| # | Measure | Folder | Value with no filters | Format | Status |
|---|---|---|---|---|---|
| 1 | Total Savings | Savings | $156,764,903.24 | Currency | Final |
| 2 | Pre-Pay Savings | Savings | $69,744,660.79 | Currency | Final |
| 3 | Post-Pay Savings | Savings | $87,020,242.45 | Currency | Final |
| 4 | Pre-Pay Share of Savings % | Savings | 44.49% | Percent | Final |
| 5 | Total Billed | Billed and paid | $6,332,770,753.40 | Currency | Final |
| 6 | Total Paid | Billed and paid | $4,391,703,679.79 | Currency | Final |
| 7 | Paid % of Billed | Billed and paid | 69.35% | Percent | Final |
| 8 | Savings % of Billed (interim) | Billed and paid | 2.48% | Percent | Interim: no client definition of a savings rate |
| 9 | Claims Submitted (source: total_claims_submitted_amount) | Claim volumes | 3,130,776 | Whole number | Interim: unit pending Q9 |
| 10 | Claims Pre-Edit Allowed (source: total_claims_pre_edit_allowed_amount) | Claim volumes | 2,848,948 | Whole number | Interim: unit pending Q9 |
| 11 | Claims Processed (source: total_claims_processed_amount) | Claim volumes | 2,715,219 | Whole number | Interim: unit pending Q9 |
| 12 | True Positive Rate - Simple Average (definition pending) | True positive rate | 64.25% | Percent | Interim: definition pending Q10 |
| 13 | True Positive Rate - Savings Weighted (definition pending) | True positive rate | 64.38% | Percent | Interim: definition pending Q10 |
| 14 | Fact Rows | Data quality | 248 | Whole number | Final |
| 15 | Rows on a Not-Yet-Valid Version | Data quality | 37 | Whole number | Final (check only) |
| 16 | Rows with PI Service Route Disagreement | Data quality | 96 | Whole number | Final (check only) |
| 17 | Rows with Group Client Mismatch | Data quality | 9 | Whole number | Final (check only) |
| 18 | Savings Without a Known Employer Group | Data quality | $82,648,215.38 | Currency | Interim: pending Q4–Q6 |
| 19 | Savings Without a Known Employer Group % | Data quality | 52.72% | Percent | Interim: pending Q4–Q6 |
| 20 | Total Savings YTD | Time intelligence | Blank (see below) | Currency | Final; not for trend claims |
| 21 | Total Savings Prior Year | Time intelligence | Blank (see below) | Currency | Final; not for trend claims |
| 22 | Selected PI Service | Insights and titles | "All PI services" | Text | Final |
| 23 | Service Detail Title | Insights and titles | "PI Service Detail: All PI services" | Text | Final |
| 24 | Fact Rows Title | Insights and titles | "Fact rows for All PI services (248 rows), with validation checks" | Text | Final |
| 25 | Insight Text | Insights and titles | One sentence per insight row (see below) | Text | Final wording; interim items say so in the sentence |
| 26 | Insight Colour | Insights and titles | A hex colour per insight row | Text | Presentation choice |
| 27 | Selected Analytic | Insights and titles | "All analytics" | Text | Final |
| 28 | Savings % of Paid (interim) | Billed and paid | 3.57% | Percent | Interim: no client definition of a savings rate |
| 29 | Savings per Processed Claim (interim) | Claim volumes | $57.74 | Currency | Interim: unit pending Q9 |
| 30 | Analytic Detail Title | Insights and titles | "Analytic Detail: All analytics" | Text | Final |
| 31 | Analytic Fact Rows Title | Insights and titles | "Fact rows for All analytics (248 rows)" | Text | Final |
| 32 | Selected Provider | Insights and titles | "All providers" | Text | Final |
| 33 | Provider Detail Title | Insights and titles | "Provider Detail: All providers" | Text | Final |
| 34 | Provider Fact Rows Title | Insights and titles | "Fact rows for All providers (248 rows)" | Text | Final |
| 35 | Explore Title | Insights and titles | "Savings % of paid (interim)  \|  Group by: PI service" with the default picks | Text | Final |
| 36 | Savings % of Paid Colour | Insights and titles | A hex colour per matrix cell | Text | Presentation choice |

## Savings

### 1. Total Savings

```dax
SUM ( 'PI Measures'[Total Savings Amount] )
```

- **Meaning:** all savings in the current filter, pre-pay and post-pay together.
- **Source column:** `total_savings_amount`.
- **Example:** fact row 1 has $483,087.78; row 2 has $449,906.50.
- **Reconciles to:** $156,764,903.24. By year: 2023 $58,039,611.22, 2024 $44,207,864.48, 2025 $54,517,427.54.

### 2. Pre-Pay Savings

```dax
SUM ( 'PI Measures'[Pre-Pay Savings Amount] )
```

- **Meaning:** savings identified before the claim was paid.
- **Source column:** `pre_pay_savings_amount`.
- **Example:** row 1 has $0.00; row 2 has $213,045.14.
- **Reconciles to:** $69,744,660.79.

### 3. Post-Pay Savings

```dax
SUM ( 'PI Measures'[Post-Pay Savings Amount] )
```

- **Meaning:** savings identified after the claim was paid.
- **Source column:** `post_pay_savings_amount`.
- **Example:** row 1 has $483,087.78; row 2 has $236,861.36.
- **Reconciles to:** $87,020,242.45. Pre-pay plus post-pay equals total savings in all 248 rows.

### 4. Pre-Pay Share of Savings %

```dax
DIVIDE ( [Pre-Pay Savings], [Total Savings] )
```

- **Meaning:** the part of total savings that came from pre-pay. The rest is post-pay.
- **Why `DIVIDE`:** it returns blank instead of an error when total savings is zero.
- **Reconciles to:** 44.49% ($69,744,660.79 ÷ $156,764,903.24).

## Billed and paid

### 5. Total Billed

```dax
SUM ( 'PI Measures'[Total Billed Amount] )
```

- **Source column:** `total_billed_amount`.
- **Example:** row 1 has $33,018,049.27.
- **Reconciles to:** $6,332,770,753.40.

### 6. Total Paid

```dax
SUM ( 'PI Measures'[Total Paid Amount] )
```

- **Source column:** `total_paid_amount`.
- **Example:** row 1 has $19,172,362.28.
- **Reconciles to:** $4,391,703,679.79.

### 7. Paid % of Billed

```dax
DIVIDE ( [Total Paid], [Total Billed] )
```

- **Meaning:** how much of the billed amount was paid.
- **Reconciles to:** 69.35% ($4,391,703,679.79 ÷ $6,332,770,753.40).

### 8. Savings % of Billed (interim)

```dax
DIVIDE ( [Total Savings], [Total Billed] )
```

- **Meaning:** total savings divided by total billed.
- **Status:** interim. The client has not said how a savings rate should be calculated, so this is plain arithmetic on two source columns and is labelled "interim" in its name. It is not an official KPI.
- **Reconciles to:** 2.48% ($156,764,903.24 ÷ $6,332,770,753.40).

### 28. Savings % of Paid (interim)

```dax
DIVIDE ( [Total Savings], [Total Paid] )
```

- **Meaning:** total savings divided by total paid. It sizes the savings against what was actually paid out, which is the payer's view. Added 2026-10-07 for the Programme View page.
- **Status:** interim, for the same reason as measure 8: the client has not said how a savings rate should be calculated, so this is plain arithmetic on two source columns.
- **Example:** State Medicaid Agency 3.44%; HealthFirst Employer Trust 3.73%.
- **Reconciles to:** 3.57% ($156,764,903.24 ÷ $4,391,703,679.79).

## Claim volumes (unit pending Q9)

These three source columns are named `…_amount` but hold whole numbers that look like claim counts (Issue 6). The measures show them as whole numbers with no currency symbol and keep the source column name in the label. They are never added to a dollar measure. On the Analytics and Providers page the claim-volume chart shows short series names (Claims Submitted, Claims Pre-Edit Allowed, Claims Processed) at the report owner's request; the measure names in the model still carry the source column names.

### 9. Claims Submitted (source: total_claims_submitted_amount)

```dax
SUM ( 'PI Measures'[total_claims_submitted_amount] )
```

- **Example:** row 1 has 11,649.
- **Reconciles to:** 3,130,776.

### 10. Claims Pre-Edit Allowed (source: total_claims_pre_edit_allowed_amount)

```dax
SUM ( 'PI Measures'[total_claims_pre_edit_allowed_amount] )
```

- **Example:** row 1 has 10,322.
- **Reconciles to:** 2,848,948.

### 11. Claims Processed (source: total_claims_processed_amount)

```dax
SUM ( 'PI Measures'[total_claims_processed_amount] )
```

- **Example:** row 1 has 9,512.
- **Reconciles to:** 2,715,219.

### 29. Savings per Processed Claim (interim)

```dax
DIVIDE ( [Total Savings], [Claims Processed (source: total_claims_processed_amount)] )
```

- **Meaning:** total savings divided by the sum of `total_claims_processed_amount`. Added 2026-10-07 for the Analytic Performance page, where it shows how much each analytic saves for the volume it handles.
- **Status:** interim. It reads as "dollars of savings per processed claim" only if that source column is a claim count, which is pending Q9.
- **Example:** AN-0001 (Duplicate Claim Detection) $89.17, the highest; AN-0002 (Unbundling Detection) $39.00, the lowest.
- **Reconciles to:** $57.74 ($156,764,903.24 ÷ 2,715,219).

## True positive rate (definition pending Q10)

`true_positive_rate_pct` is already a percentage on each row, stored as 55.50 for 55.5% (Issue 7). It must never be summed: rows 1 and 2 (55.5% and 85.4%) would add up to 140.9%. The column's default summing is switched off and two interim averages are offered. Neither is "the" true positive rate until Q10 is answered.

### 12. True Positive Rate - Simple Average (definition pending)

```dax
DIVIDE ( AVERAGE ( 'PI Measures'[True Positive Rate Pct] ), 100 )
```

- **Meaning:** the plain average of the row rates. Every row counts equally.
- **Why divide by 100:** the source stores 55.50, and a percent format needs 0.555.
- **Example:** rows 1 and 2 alone give (55.5 + 85.4) ÷ 2 = 70.45%.
- **Reconciles to:** 64.25%.

### 13. True Positive Rate - Savings Weighted (definition pending)

```dax
DIVIDE (
    SUMX (
        'PI Measures',
        'PI Measures'[True Positive Rate Pct] * 'PI Measures'[Total Savings Amount]
    ),
    [Total Savings]
) / 100
```

- **Meaning:** an average where rows with more savings count more.
- **How it works:** `SUMX` goes row by row, multiplies each row's rate by its savings and adds the results. Dividing by total savings turns that into an average.
- **Example:** rows 1 and 2 alone give (55.5 × 483,087.78 + 85.4 × 449,906.50) ÷ 932,994.28 = 69.92%, a little below the simple 70.45% because row 1 has slightly more savings and the lower rate.
- **Reconciles to:** 64.38%.

## Data quality

These support the validation sheet. The check columns they filter on are built in Power Query and never change a source value. The three row-count measures use `COALESCE ( …, 0 )` so a card shows 0 rather than "(Blank)" when no row matches, for example after drilling through to a service with no route disagreements.

### 14. Fact Rows

```dax
COUNTROWS ( 'PI Measures' )
```

- **Reconciles to:** 248. By client: State Medicaid Agency 136, HealthFirst Employer Trust 112.

### 15. Rows on a Not-Yet-Valid Version

```dax
COALESCE (
    CALCULATE (
        [Fact Rows],
        'PI Measures'[History Version Check] = "Version not valid on row date"
    ),
    0
)
```

- **Meaning:** rows that point to an analytic or provider version that was not yet valid on the row's date (Issue 5).
- **Reconciles to:** 37. That is 22 analytic rows (14 on AN-0007 v2, 8 on AN-0006) and 19 provider rows (Sunrise Rehabilitation Hospital LLC), with 4 rows in both groups.

### 16. Rows with PI Service Route Disagreement

```dax
COALESCE (
    CALCULATE (
        [Fact Rows],
        'PI Measures'[PI Service Route Check] = "Routes disagree"
    ),
    0
)
```

- **Meaning:** rows whose own PI service differs from the service their analytic belongs to (Issue 8).
- **Example:** row 3 says Fraud, Waste & Abuse, but its analytic AN-0006 belongs to Clinical Chart Review.
- **Reconciles to:** 96.

### 17. Rows with Group Client Mismatch

```dax
COALESCE (
    CALCULATE (
        [Fact Rows],
        'PI Measures'[Employer Group Client Check] = "Group client differs from row client"
    ),
    0
)
```

- **Meaning:** rows whose employer group belongs to a different client than the row's own client (Issue 4).
- **Example:** row 37 has employer group 1, which belongs to HealthFirst, but the row's client is State Medicaid Agency.
- **Reconciles to:** 9.

### 18. Savings Without a Known Employer Group

```dax
CALCULATE (
    [Total Savings],
    'PI Measures'[Employer Group Status] <> "In lookup"
)
```

- **Meaning:** savings on rows whose employer group key is empty or is not in the lookup (Issue 4).
- **Reconciles to:** $82,648,215.38, the 124 rows with no employer group key. Until 2026-10-06 it was $117,373,051.30, because the 50 rows with keys 2 to 6 ($34,724,835.92) had no lookup row either; five synthetic lookup rows now give those keys a name.

### 19. Savings Without a Known Employer Group %

```dax
DIVIDE ( [Savings Without a Known Employer Group], [Total Savings] )
```

- **Reconciles to:** 52.72% (74.87% before the synthetic lookup rows were added).

## Time intelligence

The sample is uneven, with 2 to 14 rows per month (Issue 10). These two measures exist so the date logic can be tested and reconciled. They must not be presented as trends.

### 20. Total Savings YTD

```dax
TOTALYTD ( [Total Savings], 'Date'[Date] )
```

- **Meaning:** total savings from 1 January up to the last date in the current filter.
- **With no date filter:** blank. The calendar runs to 2028, so "year to date" means 2028, which has no data.
- **Reconciles to:** $31,378,066.14 at June 2025; $54,517,427.54 at December 2025, the same as the 2025 total.

### 21. Total Savings Prior Year

```dax
IF (
    HASONEVALUE ( 'Date'[Year] ),
    CALCULATE ( [Total Savings], SAMEPERIODLASTYEAR ( 'Date'[Date] ) )
)
```

- **Meaning:** total savings for the same dates one year earlier.
- **Why the `IF`:** with several years in the filter, shifting every date back one year covers all the data again and returns the grand total. The measure therefore shows a value only when exactly one year is selected.
- **Reconciles to:** $44,207,864.48 with 2025 selected (the 2024 total); $58,039,611.22 with 2024 selected; $20,235,540.09 for January to June 2025 (January to June 2024); blank for 2023, because there is no 2022 data.

## Insights and titles

These thirteen measures return text, not numbers. They power the dynamic titles on the three drill-through pages (Service Detail, Analytic Detail, Provider Detail), the Insights panel at the bottom right of each page, and the full-name tooltips on the two bar charts whose axis labels are cut to 15 characters. They reuse the measures above, so they follow every slicer and drill-through filter.

The Insights panel reads its rows from a small helper table, `Insight` (27 rows: an ID, the page it belongs to and a topic; rows 13 to 27 were added on 2026-10-07). The table is typed into the model with `DATATABLE`. It is not source data and has no relationship to any other table.

### 22. Selected PI Service

```dax
SELECTEDVALUE ( 'PI Service'[PI Service], "All PI services" )
```

- **Meaning:** the one PI service in the current filter, for example after a drill-through. With more than one service in the filter it returns "All PI services".
- **Also used for:** the "Full name" line in the tooltip of the Overview PI service chart. That chart's axis shows `PI Service[PI Service Short]`, a Power Query column holding the first 15 characters of the name plus an ellipsis ("Coordination of…"). On a single bar the measure returns the full name ("Coordination of Benefits").

### 23. Service Detail Title

```dax
"PI Service Detail: " & [Selected PI Service]
```

- **Used for:** the banner on the Service Detail page.
- **Example:** after drilling through from the Prepayment Claim Editing bar it reads "PI Service Detail: Prepayment Claim Editing".

### 24. Fact Rows Title

```dax
"Fact rows for " & [Selected PI Service] & " (" & FORMAT ( [Fact Rows], "#,0" ) & " rows), with validation checks"
```

- **Used for:** the title of the fact-row table on the Service Detail page.
- **Example:** with Year 2025 and Prepayment Claim Editing it reads "Fact rows for Prepayment Claim Editing (13 rows), with validation checks".

### 25. Insight Text

One long measure that returns a different sentence for each row of the `Insight` table. The full DAX is in the model file `PI Measures.tmdl`. How it works:

- `SELECTEDVALUE ( Insight[Insight ID] )` finds which row is being drawn, and `SWITCH` picks that row's sentence.
- "Top" items use `TOPN ( 1, ADDCOLUMNS ( VALUES ( … ), "@Savings", [Total Savings] ), [@Savings], DESC )`: list the categories, attach each one's savings, keep the largest.
- Analytics are grouped by Analytic Code and providers by Provider NPI, as Issue 5 requires. The provider name shown is the lookup row marked current.
- Amounts are shown in millions with `FORMAT ( DIVIDE ( x, 1000000 ), "#,0.00" )`.
- If the filter has no rows, every sentence reads "No rows in the current filter."

| ID | Page | Topic | Sentence with no filters (each figure checked against the CSV) |
|---|---|---|---|
| 1 | Overview | Pre-pay vs post-pay | Post-pay savings are 55.5% of savings ($87.02M of $156.76M); pre-pay is the other 44.5%. |
| 2 | Overview | Top PI service | Coordination of Benefits leads with $26.48M, 16.9% of savings, among 10 PI services with rows in the filter. |
| 3 | Overview | Top line of business | Medicare is the largest line of business with $47.28M, 30.2% of savings. |
| 4 | Overview | Sample size | 248 rows across 36 reporting months, from 2 to 14 rows per month. Uneven sample: differences between periods are not trends. |
| 5 | Analytic Performance | Top analytic | AN-0001 (Duplicate Claim Detection) leads with $38.28M, 24.4% of savings in the filter, from 37 rows. |
| 6 | Programme View | Top provider | Sunrise Rehabilitation Hospital LLC (NPI 1567892341) leads with $29.86M, 19.0% of savings in the filter. |
| 7 | Programme View | Employer group coverage | 52.7% of savings ($82.65M) is on rows with no employer group key. A further 22.2% ($34.72M) is on groups with synthetic names. Interim, pending Q4-Q6. (The "synthetic" part comes from the lookup's `Employer Group Origin` flag and disappears if the client's real groups replace the synthetic rows; a "key the lookup does not contain" part appears if a key is ever missing again.) |
| 8 | Analytic Performance | True positive rate | Simple average 64.25%; savings-weighted 64.38%. Both are interim: how to combine row rates is pending Q10. |
| 9 | Service Detail | Selection total | All PI services: $156.76M savings from 248 rows, 100.0% of savings across all PI services in the same filter. |
| 10 | Service Detail | Leading analytic | The same sentence as ID 5, for the rows in the filter. |
| 11 | Service Detail | Savings timing | The same sentence as ID 1. It leads with whichever of pre-pay and post-pay is larger. |
| 12 | Service Detail | Validation flags | Flagged rows: 37 on a not-yet-valid version, 96 with a service route disagreement, 9 with a group/client mismatch, out of 248. No row was changed. |
| 13 | Programme View | Funding type | Fully Insured $81.03M (51.7%); Administrative Services Only $75.73M (48.3%). |
| 14 | Programme View | Savings against paid | Savings are 3.57% of paid ($156.76M of $4.39bn). Interim: plain arithmetic on two source columns; no savings rate has been defined. |
| 15 | Analytic Performance | Yield by analytic | Savings per processed claim: $57.74 overall; highest AN-0001 ($89.17), lowest AN-0002 ($39.00). Interim: the unit of the claim columns is pending Q9. |
| 16 | Analytic Performance | Rate by analytic | By analytic code the simple average runs from 60.44% (AN-0007) to 69.92% (AN-0005), across 7 codes. Interim, pending Q10. (With one analytic code in the filter, sentences 15 and 16 name that code instead of a highest and lowest.) |
| 17 | Analytic Detail | Analytic total | All analytics: $156.76M savings from 248 rows, 100.0% of savings across all analytics in the same filter. (Drilled to AN-0001: "AN-0001 Duplicate Claim Detection: $38.28M savings from 37 rows, 24.4% …") |
| 18 | Analytic Detail | Leading PI service | The same sentence as ID 2, for the rows in the filter. (AN-0001: "Coordination of Benefits leads with $26.48M, 69.2% of savings, among 5 PI services …") |
| 19 | Analytic Detail | Accuracy and yield | True positive rate 64.25% (all analytics: 64.25%); savings per processed claim $57.74 (all analytics: $57.74). Interim, pending Q9 and Q10. (AN-0001: 60.65% and $89.17 against the same two "all analytics" figures.) |
| 20 | Analytic Detail | Flagged rows | The same sentence as ID 12. (AN-0001: 2, 14 and 1, out of 37.) |
| 21 | Provider Detail | Provider total | All providers: $156.76M savings from 248 rows, 100.0% of savings across all providers in the same filter. (Drilled to NPI 1567892341: "Sunrise Rehabilitation Hospital LLC: $29.86M savings from 41 rows, 19.0% …") |
| 22 | Provider Detail | Top service for provider | The same sentence as ID 2. (Sunrise: "Prepayment Claim Editing leads with $8.01M, 26.8% of savings, among 10 PI services …") |
| 23 | Provider Detail | Pre-pay and post-pay | The same sentence as ID 1. (Sunrise: "Post-pay savings are 60.5% of savings ($18.08M of $29.86M) …") |
| 24 | Provider Detail | Row checks | The same sentence as ID 12. (Sunrise: 19, 19 and 2, out of 41.) |
| 25 | Explore | Rate by PI service | By PI service, savings run from 2.63% of paid (Data Mining / Analytics Overpayment) to 5.45% (Prepayment Claim Editing); overall 3.57%. Interim: no savings rate has been defined. |
| 26 | Explore | Rate by line of business | By line of business, savings run from 3.12% of paid (Medicaid) to 4.00% (Exchange/ACA); overall 3.57%. Interim: no savings rate has been defined. |
| 27 | Explore | Rate by client | By client, savings run from 3.44% of paid (State Medicaid Agency) to 3.73% (HealthFirst Employer Trust); overall 3.57%. Interim: no savings rate has been defined. (With one item in the filter, each of these three sentences names that item instead of a lowest and highest.) |

The sentences state facts only. They set no targets and make no trend claims, and the interim items say they are interim.

### 26. Insight Colour

```dax
VAR InsightId = SELECTEDVALUE ( Insight[Insight ID] )
VAR NoGroupShare = [Savings Without a Known Employer Group %]
VAR FlaggedRows =
    [Rows on a Not-Yet-Valid Version] + [Rows with PI Service Route Disagreement] + [Rows with Group Client Mismatch]
RETURN
    SWITCH (
        InsightId,
        7, IF ( NoGroupShare > 0.5, "#B72032", IF ( NoGroupShare > 0, "#CC401D", "#2C8641" ) ),
        12, IF ( FlaggedRows > 0, "#CC401D", "#2C8641" ),
        20, IF ( FlaggedRows > 0, "#CC401D", "#2C8641" ),
        24, IF ( FlaggedRows > 0, "#CC401D", "#2C8641" ),
        4, "#58595B",
        "#333333"
    )
```

- **Used for:** conditional formatting. The Insights table takes its text colour from this measure.
- **Rules:** employer group coverage is red above 50% of savings with no known group, orange-red above 0% and green at 0%. Validation flags (sentences 12, 20 and 24) are orange-red when any row is flagged and green when none is. The sample-size note is grey. Everything else is the normal dark text.
- **Status:** the thresholds are a presentation choice, not a client rule. Every colour used passes 4.5:1 contrast on white, and each sentence carries its own meaning, so colour is never the only signal.

### 27. Selected Analytic

```dax
SELECTEDVALUE ( Analytic[Analytic Label], "All analytics" )
```

- **Meaning:** the one analytic (code and description) in the current filter; "All analytics" when there is more than one.
- **Used for:** the "Full name" line in the tooltip of the analytic charts on the Analytic Performance page. That chart's axis shows `Analytic[Analytic Label Short]`, the first 15 characters of the label plus an ellipsis ("AN-0001 Duplica…"). The code is the first 7 characters, so every short label is different and the chart still groups by analytic code.
- **Example:** hovering the first bar shows "Full name: AN-0001 Duplicate Claim Detection".

### 30. Analytic Detail Title

```dax
"Analytic Detail: " & [Selected Analytic]
```

- **Used for:** the banner of the Analytic Detail drill-through page. Added 2026-10-07.
- **Example:** "Analytic Detail: AN-0001 Duplicate Claim Detection" after drilling through from the AN-0001 bar; "Analytic Detail: All analytics" when the page is opened directly.

### 31. Analytic Fact Rows Title

```dax
"Fact rows for " & [Selected Analytic] & " (" & FORMAT ( [Fact Rows], "#,0" ) & " rows)"
```

- **Used for:** the title of the fact-row table on Analytic Detail.
- **Example:** "Fact rows for AN-0001 Duplicate Claim Detection (37 rows)". The count matches the CSV.

### 32. Selected Provider

```dax
VAR Npi = SELECTEDVALUE ( Provider[Provider NPI] )
VAR CurrentName =
    MAXX (
        FILTER ( ALL ( Provider ), Provider[Provider NPI] = Npi && Provider[Provider Is Current] ),
        Provider[Provider Name]
    )
RETURN
    IF ( ISBLANK ( Npi ), "All providers", CurrentName )
```

- **Meaning:** the one provider in the current filter, found by NPI as Issue 5 requires, and shown under the name on the lookup row marked current. "All providers" when more than one NPI is in the filter.
- **Example:** NPI 1567892341 has two lookup rows, "Sunrise Rehabilitation Hospital" (to March 2024) and "Sunrise Rehabilitation Hospital LLC" (current); the measure returns the second.

### 33. Provider Detail Title

```dax
"Provider Detail: " & [Selected Provider]
```

- **Used for:** the banner of the Provider Detail drill-through page.
- **Example:** "Provider Detail: Sunrise Rehabilitation Hospital LLC".

### 34. Provider Fact Rows Title

```dax
VAR Npi = SELECTEDVALUE ( Provider[Provider NPI] )
RETURN
    "Fact rows for " & [Selected Provider]
        & IF ( ISBLANK ( Npi ), "", ", NPI " & Npi )
        & " (" & FORMAT ( [Fact Rows], "#,0" ) & " rows)"
```

- **Used for:** the title of the fact-row table on Provider Detail. It adds the NPI when one provider is in the filter.
- **Example:** "Fact rows for Sunrise Rehabilitation Hospital LLC, NPI 1567892341 (41 rows)". The count matches the CSV.

### 35. Explore Title

```dax
VAR PickedMeasure =
    SELECTCOLUMNS (
        SUMMARIZE ( 'Explore Measure', 'Explore Measure'[Explore Measure], 'Explore Measure'[Explore Measure Fields] ),
        "@Name", 'Explore Measure'[Explore Measure]
    )
VAR PickedGrouping =
    SELECTCOLUMNS (
        SUMMARIZE ( 'Explore By', 'Explore By'[Explore By], 'Explore By'[Explore By Fields] ),
        "@Name", 'Explore By'[Explore By]
    )
RETURN
    IF ( COUNTROWS ( PickedMeasure ) = 1, MAXX ( PickedMeasure, [@Name] ), "Selected measures" )
        & "  |  Group by: "
        & IF ( COUNTROWS ( PickedGrouping ) = 1, MAXX ( PickedGrouping, [@Name] ), "several" )
```

- **Used for:** the title of the chart on the Explore page. It names the measure picked in the "Show" dropdown and the grouping picked in "Group by". Added 2026-10-07.
- **Example:** "Total savings  |  Group by: Line of business".
- **Why not `SELECTEDVALUE`:** a field-parameter column is tied to a hidden companion column, and the engine refuses to read one without the other. `SUMMARIZE` over both columns satisfies that rule.

### 36. Savings % of Paid Colour

```dax
VAR Rate = [Savings % of Paid (interim)]
VAR Overall =
    CALCULATE (
        [Savings % of Paid (interim)],
        REMOVEFILTERS ( 'PI Service' ),
        REMOVEFILTERS ( 'Line of Business' )
    )
RETURN
    IF ( ISBLANK ( Rate ), BLANK (), IF ( Rate >= Overall, "#D6EAF5", "#FCE9C8" ) )
```

- **Used for:** the cell background of the matrix on the Explore page (savings % of paid, PI service by line of business).
- **Rule:** light blue when the cell's rate is at or above the rate for all PI services and lines of business in the same filter (3.57% with no filters), light amber when it is below.
- **Example:** Prepayment Claim Editing in Commercial, 6.41%, is blue; Data Mining / Analytics Overpayment in Commercial, 1.46%, is amber.
- **Status:** a reading aid, not a target or a client rule. The figure is printed in every cell, so colour is never the only signal, and the dark text passes 4.5:1 contrast on both tints.

## Field parameters (Explore page)

Two small tables, created with the modeling tool's field-parameter operation on 2026-10-07. They are not source data and have no relationships. Each row names one measure or column; the dropdown on the Explore page filters the table to one row, and the chart then draws that measure or grouping.

| Table | Dropdown label | Choices |
|---|---|---|
| `Explore Measure` | Show | Savings % of paid (interim); Total savings; Savings per processed claim (interim); True positive rate (interim); Fact rows |
| `Explore By` | Group by | PI service; Line of business; Client; Funding type; Claim type; Analytic; Year |

Every choice points at an existing measure or column, so the figures are the ones validated elsewhere in this dictionary.
