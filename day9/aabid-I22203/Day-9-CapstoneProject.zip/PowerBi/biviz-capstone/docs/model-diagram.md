# Model diagram: CentenePI semantic model

The model is a star schema: one fact table, `PI Measures`, with a many-to-one relationship to each of ten lookup tables. Drawn from the saved model definition in `CentenePI.SemanticModel/definition` on 2026-10-04.

![Star schema: PI Measures in the centre linked to ten lookup tables](model-diagram.svg)

A PNG copy for slides is in [model-diagram.png](model-diagram.png).

## Relationships

All ten are many-to-one from the fact, single direction (the lookup filters the fact) and active.

| From `PI Measures` | To | Lookup source file | Lookup rows |
|---|---|---|---|
| Client Key | `Client`[Client Key] | `dim_client.csv` | 3 |
| LOB Key | `Line of Business`[LOB Key] | `dim_line_of_business.csv` | 4 |
| Funding Type Key | `Funding Type`[Funding Type Key] | `dim_funding_type.csv` | 2 |
| PI Service Key | `PI Service`[PI Service Key] | `dim_pi_service.csv` | 10 |
| Claim Type Key | `Claim Type`[Claim Type Key] | `dim_claim_type.csv` | 4 |
| Analytic Key | `Analytic`[Analytic Key] | `dim_analytic.csv` | 8 |
| Provider Key | `Provider`[Provider Key] | `dim_provider.csv` | 8 |
| Employer Group Key | `Employer Group`[Employer Group Key] | `dim_employer_group.csv` | 6 (keys 2 to 6 synthetic) |
| Source System Key | `Source System`[Source System Key] | `dim_source_system.csv` | 6 |
| Reporting Month | `Date`[Date] | `dim_date.csv` | 2,557 |

## Design decisions the diagram shows

- **Swapped files (Issue 1).** The two lookup files were delivered with each other's contents. They were renamed on 2026-10-06, so `PI Service` now loads `dim_pi_service.csv` and `Employer Group` loads `dim_employer_group.csv`. The delivered files are kept in `centene-data-original/`.
- **Date link (Issue 2).** The fact links to `Date` on a real date, `Reporting Month`, built from the fact's `date_key` (`20250401` becomes 1 April 2025). The date table's own `date_key` is a row counter and is not used. `Date` is marked as the date table.
- **Employer group (Issue 4).** The client delivered one group, key 1. Keys 2 to 6 are synthetic rows added on 2026-10-06 so that the 50 fact rows using them have a name. The 124 fact rows with no key still have no match, so the fact carries `Employer Group Label` and `Employer Group Status` to show them as "Not supplied".
- **Hidden numbers.** Every numeric fact column is hidden with default summarisation off. Report visuals use the 36 measures instead.

## Links that are deliberately not in the model

- **Analytic → PI Service (Issue 8).** The analytic lookup names a PI service for each analytic, but it disagrees with the fact row's own service in 96 of 248 rows. Only the fact → `PI Service` link exists; the analytic's service code is a hidden column.
- **Employer Group → Client.** The employer group lookup has a `client_key`, but linking it would create a second filter path from `Client` to the fact. It is kept as a hidden column for the group/client check (9 mismatching rows).
- **Claim Status (Issue 9).** `dim_claim_status.csv` has no key in the fact table, so it is kept as a query with load switched off and has no relationship.
- **Explore Measure and Explore By.** Two field-parameter tables behind the "Show" and "Group by" dropdowns on the Explore page (5 measures and 7 groupings to choose from). Like `Insight`, they are not source data and are left unlinked.
- **Insight.** A 27-row helper table typed into the model for the Insights panels (an ID, a page name and a topic per row). It is not source data and is deliberately left unlinked: the `Insight Text` measure reads which row is being drawn and builds the sentence from the other measures.
