# Added columns on the PI Measures table

The eight columns that were added to the fact table, with the formula behind each one. Written 2026-10-05; row counts updated 2026-10-06 after five synthetic employer groups were added to the lookup.

**These formulas are Power Query (M), not DAX.** The model has no DAX calculated columns. Each column below is worked out once, when the data is refreshed, by a step in the `PI Measures` query (Transform data → `PI Measures` → Applied Steps). The formulas are copied from the saved model file, `CentenePI.SemanticModel/definition/tables/PI Measures.tmdl`.

For the DAX in the report, which is all in measures, see [dax-measures-explained.md](dax-measures-explained.md).

## Which columns are which

| Column in the model | Source or added | Power Query step |
|---|---|---|
| PI Measures Key … True Positive Rate Pct (20 columns) | Source file | Types set only; the text `null` replaced with a real blank |
| Updated At | Source file (`updated_at`) | Loaded as delivered; hidden |
| Reporting Month | Added | Added reporting_month |
| Employer Group Label | Added | Added employer_group_label |
| Employer Group Status | Added | Added employer_group_status |
| Employer Group Client Check | Added | Added employer_group_client_check |
| Analytic Version Check | Added | Added analytic_version_check |
| Provider Version Check | Added | Added provider_version_check |
| History Version Check | Added | Added history_version_check |
| PI Service Route Check | Added | Added pi_service_route_check |

None of the added columns changes, fills in or removes a source value. They only label or flag rows.

## How to read the formulas

- `each …` means "for each row, work out the following".
- `[column_name]` is that row's value in a column. The names are the source names (`employer_group_key`), not the friendly model names (`Employer Group Key`).
- `if … then … else …` picks one of two results.
- `null` is an empty value.
- `&` joins pieces of text.
- Columns starting `eg_`, `an_`, `pr_` or `svc_` are helper columns brought in from a lookup table by a merge, used in the formula and then removed in the last step.

## 1. Reporting Month

**Purpose (Issue 2):** the fact's `date_key` is a number like `20250401`, while the date table's key is a row counter. This column turns the number into a real date so the fact can be linked to the date table.

```powerquery
#date(Number.IntegerDivide([date_key], 10000), Number.IntegerDivide(Number.Mod([date_key], 10000), 100), Number.Mod([date_key], 100))
```

- `Number.IntegerDivide([date_key], 10000)` drops the last four digits: 20250401 → 2025 (the year).
- `Number.Mod([date_key], 10000)` keeps the last four digits, 0401; dividing by 100 gives 4 (the month).
- `Number.Mod([date_key], 100)` keeps the last two digits: 1 (the day).
- `#date(year, month, day)` builds the date.

**Example:** row 1 has `date_key` 20250401, so Reporting Month is 1 April 2025. Every row is dated the 1st of a month, from January 2023 to December 2025.

## 2. Employer Group Label

**Purpose (Issue 4):** gives every row a readable employer group, with honest labels where the group is unknown.

The lookup is merged in first:

```powerquery
#"Merged Employer Group" = Table.NestedJoin(#"Added reporting_month", {"employer_group_key"}, #"Employer Group", {"employer_group_key"}, "eg", JoinKind.LeftOuter)
#"Expanded Employer Group" = Table.ExpandTableColumn(#"Merged Employer Group", "eg", {"employer_group_name", "client_key"}, {"eg_name", "eg_client_key"})
```

This is a left outer join: every fact row is kept, and `eg_name` and `eg_client_key` are filled only when the row's key exists in the Employer Group lookup.

```powerquery
if [employer_group_key] = null
    then "Not supplied"
else if [eg_name] = null
    then "Not in lookup (key " & Text.From([employer_group_key]) & ")"
else [eg_name]
```

- If the row has no key at all → "Not supplied".
- If it has a key but the lookup found no name → "Not in lookup (key 3)", keeping the original key visible.
- Otherwise → the group's name.

**Result:** a group name on 124 rows (HealthFirst Trust Members on 74, and the five synthetic groups for keys 2 to 6 on 50) and "Not supplied" on 124 rows. Example: row 2 has no key, so "Not supplied"; row 20 has key 3, so "County Workers Plan".

Until 2026-10-06 the lookup held key 1 only, so the 50 rows with keys 2 to 6 read "Not in lookup (key 2)" to "(key 6)". Five synthetic lookup rows now name those keys (see `centene-data/README.md`). The middle branch of the formula stays, so any future key that is missing from the lookup is still labelled honestly.

## 3. Employer Group Status

**Purpose (Issue 4):** the same three cases as the label, without the key number, so the three buckets can be totalled or filtered.

```powerquery
if [employer_group_key] = null
    then "Not supplied"
else if [eg_name] = null
    then "Not in lookup"
else "In lookup"
```

**Result:** "In lookup" 124 rows ($74,116,687.86) and "Not supplied" 124 rows ($82,648,215.38). No row is "Not in lookup" now; before the synthetic lookup rows were added, 50 rows ($34,724,835.92) were.

## 4. Employer Group Client Check

**Purpose (Issue 4):** the employer group lookup says which client each group belongs to. This column checks whether that agrees with the client on the fact row.

```powerquery
if [eg_client_key] = null
    then "No group in lookup"
else if [eg_client_key] = [client_key]
    then "Group client matches row client"
else "Group client differs from row client"
```

- No group found in the lookup → "No group in lookup" (124 rows, all with no key).
- The group's client equals the row's client → "Group client matches row client" (115 rows: 65 on key 1 and the 50 on the synthetic groups, which were given the client their rows already had).
- Otherwise → "Group client differs from row client" (9 rows).

**Example:** row 37 uses group 1, which belongs to HealthFirst (client 2), but the row's client is State Medicaid Agency (client 1).

## 5. Analytic Version Check

**Purpose (Issue 5):** the analytic lookup keeps a go-live date and a retire date for each version. This column flags rows dated outside the version they point to.

The lookups are merged in first:

```powerquery
#"Merged Analytic" = Table.NestedJoin(#"Added employer_group_client_check", {"analytic_key"}, Analytic, {"analytic_key"}, "an", JoinKind.LeftOuter)
#"Expanded Analytic" = Table.ExpandTableColumn(#"Merged Analytic", "an", {"analytic_go_live_date", "analytic_retire_date", "pi_service_code"}, {"an_go_live", "an_retire", "an_service_code"})
#"Merged Provider" = Table.NestedJoin(#"Expanded Analytic", {"provider_key"}, Provider, {"provider_key"}, "pr", JoinKind.LeftOuter)
#"Expanded Provider" = Table.ExpandTableColumn(#"Merged Provider", "pr", {"effective_date", "expiration_date"}, {"pr_effective", "pr_expiration"})
```

```powerquery
if [reporting_month] < [an_go_live] or ([an_retire] <> null and [reporting_month] > [an_retire])
    then "Not valid on row date"
else "Valid on row date"
```

- The row is dated before the version went live, or
- the version has a retire date and the row is dated after it → "Not valid on row date".
- Otherwise → "Valid on row date".

**Result:** 22 rows are not valid: 14 point to AN-0007 version 2 (live from 1 December 2023) but are dated February to November 2023, and 8 point to AN-0006 (live from 20 June 2023) but are dated earlier.

## 6. Provider Version Check

**Purpose (Issue 5):** the same test for the provider version, using its effective and expiration dates.

```powerquery
if [reporting_month] < [pr_effective] or ([pr_expiration] <> null and [reporting_month] > [pr_expiration])
    then "Not valid on row date"
else "Valid on row date"
```

**Result:** 19 rows are not valid. All point to Sunrise Rehabilitation Hospital LLC (effective 1 April 2024) but are dated January 2023 to January 2024.

## 7. History Version Check

**Purpose (Issue 5):** one combined flag for the validation sheet.

```powerquery
if [analytic_version_check] = "Not valid on row date" or [provider_version_check] = "Not valid on row date"
    then "Version not valid on row date"
else "OK"
```

If either of the two checks above failed → "Version not valid on row date"; otherwise "OK".

**Result:** 37 rows are flagged. That is 22 + 19, less 4 rows that fail both checks. No row was re-pointed to another version.

## 8. PI Service Route Check

**Purpose (Issue 8):** a fact row names its PI service directly, and its analytic also belongs to a PI service according to the analytic lookup. This column checks whether the two agree.

```powerquery
#"Merged PI Service" = Table.NestedJoin(#"Added history_version_check", {"pi_service_key"}, #"PI Service", {"pi_service_key"}, "svc", JoinKind.LeftOuter)
#"Expanded PI Service" = Table.ExpandTableColumn(#"Merged PI Service", "svc", {"pi_service_code"}, {"svc_code"})
```

```powerquery
if [svc_code] = [an_service_code]
    then "Routes agree"
else "Routes disagree"
```

- `svc_code` is the code of the service the row names.
- `an_service_code` is the code of the service the row's analytic belongs to.

**Result:** "Routes disagree" on 96 rows and "Routes agree" on 152. Example: row 3 names Fraud, Waste & Abuse, but its analytic AN-0006 belongs to Clinical Chart Review. The model links the fact to PI Service only, never Analytic to PI Service.

## Clean-up step

The helper columns are removed once the formulas have used them:

```powerquery
#"Removed helper columns" = Table.RemoveColumns(#"Added pi_service_route_check", {"eg_name", "eg_client_key", "an_go_live", "an_retire", "an_service_code", "pr_effective", "pr_expiration", "svc_code"})
```

## The whole query

For reference, every step of the `PI Measures` query in order:

```powerquery
let
    Source = Csv.Document(File.Contents(DataFolder & "fact_pi_measures.csv"), [Delimiter = ",", Encoding = 65001, QuoteStyle = QuoteStyle.Csv]),
    #"Promoted Headers" = Table.PromoteHeaders(Source, [PromoteAllScalars = true]),
    // Issue 3: missing values arrive as the text "null"; make them real nulls before setting types
    #"Replaced text null" = Table.ReplaceValue(#"Promoted Headers", "null", null, Replacer.ReplaceValue, Table.ColumnNames(#"Promoted Headers")),
    #"Changed Type" = Table.TransformColumnTypes(#"Replaced text null", {{"pi_measures_key", Int64.Type}, {"client_key", Int64.Type}, {"lob_key", Int64.Type}, {"funding_type_key", Int64.Type}, {"pi_service_key", Int64.Type}, {"claim_type_key", Int64.Type}, {"analytic_key", Int64.Type}, {"provider_key", Int64.Type}, {"employer_group_key", Int64.Type}, {"source_system_key", Int64.Type}, {"date_key", Int64.Type}, {"total_claims_submitted_amount", type number}, {"total_claims_pre_edit_allowed_amount", type number}, {"total_claims_processed_amount", type number}, {"total_billed_amount", Currency.Type}, {"total_paid_amount", Currency.Type}, {"pre_pay_savings_amount", Currency.Type}, {"post_pay_savings_amount", Currency.Type}, {"total_savings_amount", Currency.Type}, {"true_positive_rate_pct", type number}, {"updated_at", type text}}, "en-US"),
    // Issue 6: the three total_claims_*_amount columns hold whole numbers (claim counts), not dollars. Source names are kept; unit pending Q9
    #"Counts as whole numbers" = Table.TransformColumnTypes(#"Changed Type", {{"total_claims_submitted_amount", Int64.Type}, {"total_claims_pre_edit_allowed_amount", Int64.Type}, {"total_claims_processed_amount", Int64.Type}}),
    // Issue 2: date_key is yyyymmdd (20250401 = 1 April 2025); the date table's date_key is a row counter, so build a real date to link on
    #"Added reporting_month" = Table.AddColumn(#"Counts as whole numbers", "reporting_month", each #date(Number.IntegerDivide([date_key], 10000), Number.IntegerDivide(Number.Mod([date_key], 10000), 100), Number.Mod([date_key], 100)), type date),
    // Issue 4: label the employer group without re-mapping, filling in or deleting anything
    #"Merged Employer Group" = Table.NestedJoin(#"Added reporting_month", {"employer_group_key"}, #"Employer Group", {"employer_group_key"}, "eg", JoinKind.LeftOuter),
    #"Expanded Employer Group" = Table.ExpandTableColumn(#"Merged Employer Group", "eg", {"employer_group_name", "client_key"}, {"eg_name", "eg_client_key"}),
    #"Added employer_group_label" = Table.AddColumn(#"Expanded Employer Group", "employer_group_label", each if [employer_group_key] = null then "Not supplied" else if [eg_name] = null then "Not in lookup (key " & Text.From([employer_group_key]) & ")" else [eg_name], type text),
    #"Added employer_group_status" = Table.AddColumn(#"Added employer_group_label", "employer_group_status", each if [employer_group_key] = null then "Not supplied" else if [eg_name] = null then "Not in lookup" else "In lookup", type text),
    #"Added employer_group_client_check" = Table.AddColumn(#"Added employer_group_status", "employer_group_client_check", each if [eg_client_key] = null then "No group in lookup" else if [eg_client_key] = [client_key] then "Group client matches row client" else "Group client differs from row client", type text),
    // Issue 5: flag rows whose analytic or provider version was not valid on the row's date. Check only; no row is re-pointed
    #"Merged Analytic" = Table.NestedJoin(#"Added employer_group_client_check", {"analytic_key"}, Analytic, {"analytic_key"}, "an", JoinKind.LeftOuter),
    #"Expanded Analytic" = Table.ExpandTableColumn(#"Merged Analytic", "an", {"analytic_go_live_date", "analytic_retire_date", "pi_service_code"}, {"an_go_live", "an_retire", "an_service_code"}),
    #"Merged Provider" = Table.NestedJoin(#"Expanded Analytic", {"provider_key"}, Provider, {"provider_key"}, "pr", JoinKind.LeftOuter),
    #"Expanded Provider" = Table.ExpandTableColumn(#"Merged Provider", "pr", {"effective_date", "expiration_date"}, {"pr_effective", "pr_expiration"}),
    #"Added analytic_version_check" = Table.AddColumn(#"Expanded Provider", "analytic_version_check", each if [reporting_month] < [an_go_live] or ([an_retire] <> null and [reporting_month] > [an_retire]) then "Not valid on row date" else "Valid on row date", type text),
    #"Added provider_version_check" = Table.AddColumn(#"Added analytic_version_check", "provider_version_check", each if [reporting_month] < [pr_effective] or ([pr_expiration] <> null and [reporting_month] > [pr_expiration]) then "Not valid on row date" else "Valid on row date", type text),
    #"Added history_version_check" = Table.AddColumn(#"Added provider_version_check", "history_version_check", each if [analytic_version_check] = "Not valid on row date" or [provider_version_check] = "Not valid on row date" then "Version not valid on row date" else "OK", type text),
    // Issue 8: flag rows where the row's own PI service differs from the service its analytic belongs to. Check only
    #"Merged PI Service" = Table.NestedJoin(#"Added history_version_check", {"pi_service_key"}, #"PI Service", {"pi_service_key"}, "svc", JoinKind.LeftOuter),
    #"Expanded PI Service" = Table.ExpandTableColumn(#"Merged PI Service", "svc", {"pi_service_code"}, {"svc_code"}),
    #"Added pi_service_route_check" = Table.AddColumn(#"Expanded PI Service", "pi_service_route_check", each if [svc_code] = [an_service_code] then "Routes agree" else "Routes disagree", type text),
    #"Removed helper columns" = Table.RemoveColumns(#"Added pi_service_route_check", {"eg_name", "eg_client_key", "an_go_live", "an_retire", "an_service_code", "pr_effective", "pr_expiration", "svc_code"})
in
    #"Removed helper columns"
```

## If these had been DAX calculated columns

They could have been written in DAX instead, but Power Query was chosen on purpose:

- **One place for all data fixes.** The project rule is that the source files are never edited and every fix happens in Power Query.
- **Worked out before the model loads.** `Reporting Month` has to exist before the relationship to the date table can be built.
- **Visible as steps.** Each column is a named step that can be clicked and inspected in the Power Query editor.
