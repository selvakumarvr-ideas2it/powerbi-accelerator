// Expected values for validation tests V01-V25 and the drill-through tests,
// computed straight from the source CSVs (no Power BI involved).
//   node scripts/expected-values.js
const fs = require('fs'), path = require('path');
const dir = path.join(__dirname, '..', 'centene-data');
function csv(file) {
  const lines = fs.readFileSync(path.join(dir, file), 'utf8').replace(/\r/g, '').trim().split('\n');
  const parse = l => { const o = []; let c = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { o.push(c); c = ''; } else c += ch; } o.push(c); return o; };
  const h = parse(lines[0]);
  return lines.slice(1).map(l => { const v = parse(l), r = {}; h.forEach((k, i) => r[k] = v[i]); return r; });
}
const by = (rows, k) => Object.fromEntries(rows.map(r => [r[k], r]));
const F = csv('fact_pi_measures.csv');
// Issue 1: the two lookup files were delivered with swapped names and were renamed on 2026-10-06
// (originals in centene-data-original). Employer groups 2-6 are synthetic rows added the same day.
const service = by(csv('dim_pi_service.csv'), 'pi_service_key');
const group = by(csv('dim_employer_group.csv'), 'employer_group_key');
const client = by(csv('dim_client.csv'), 'client_key'), lob = by(csv('dim_line_of_business.csv'), 'lob_key');
const funding = by(csv('dim_funding_type.csv'), 'funding_type_key'), analytic = by(csv('dim_analytic.csv'), 'analytic_key');
const provider = by(csv('dim_provider.csv'), 'provider_key');
const dates = new Set(csv('dim_date.csv').map(r => r.full_date));
const cents = x => BigInt(Math.round(parseFloat(x) * 100));           // exact money arithmetic
const money = c => (Number(c) / 100).toFixed(2);
const sum = (col, f = () => true) => F.filter(f).reduce((a, r) => a + cents(r[col]), 0n);
const count = f => F.filter(f).length;
const iso = r => `${r.date_key.slice(0, 4)}-${r.date_key.slice(4, 6)}-${r.date_key.slice(6)}`;
const groupBy = (keyFn) => { const m = {}; for (const r of F) { const k = keyFn(r); m[k] = m[k] || { rows: 0, c: 0n }; m[k].rows++; m[k].c += cents(r.total_savings_amount); } return Object.fromEntries(Object.entries(m).map(([k, v]) => [k, { rows: v.rows, savings: money(v.c) }])); };
const notValid = r => { const d = iso(r), a = analytic[r.analytic_key], p = provider[r.provider_key]; return d < a.analytic_go_live_date || (a.analytic_retire_date !== 'null' && d > a.analytic_retire_date) || d < p.effective_date || (p.expiration_date !== 'null' && d > p.expiration_date); };
const routeDisagrees = r => service[r.pi_service_key].pi_service_code !== analytic[r.analytic_key].pi_service_code;
const groupClientDiffers = r => r.employer_group_key !== 'null' && group[r.employer_group_key] && group[r.employer_group_key].client_key !== r.client_key;
const S = sum('total_savings_amount');
const tpr = F.map(r => parseFloat(r.true_positive_rate_pct));
// Added 2026-10-07 for the Programme View and Analytic Performance pages (V21-V25).
const intSum = (col, f = () => true) => F.filter(f).reduce((a, r) => a + parseInt(r[col]), 0);
const ratio = (num, den, dp) => (Number(num) / Number(den)).toFixed(dp);
const audience = keyFn => { const m = {}; for (const r of F) { const k = keyFn(r); (m[k] = m[k] || []).push(r); }
  return Object.fromEntries(Object.keys(m).sort().map(k => { const g = r => m[k].includes(r), sav = sum('total_savings_amount', g);
    return [k, { rows: m[k].length, savings: money(sav), pre_pay: money(sum('pre_pay_savings_amount', g)), post_pay: money(sum('post_pay_savings_amount', g)),
      savings_pct_of_paid: ratio(sav * 100n, sum('total_paid_amount', g), 4), processed: intSum('total_claims_processed_amount', g), savings_per_processed_claim: ratio(sav, 100 * intSum('total_claims_processed_amount', g), 4),
      true_positive_rate_simple_pct: (m[k].reduce((a, r) => a + parseFloat(r.true_positive_rate_pct), 0) / m[k].length).toFixed(4),
      true_positive_rate_weighted_pct: (m[k].reduce((a, r) => a + parseFloat(r.true_positive_rate_pct) * Number(cents(r.total_savings_amount)), 0) / Number(sav)).toFixed(4),
      pre_pay_share_pct: ratio(sum('pre_pay_savings_amount', g) * 100n, sav, 4), no_known_group_pct: ratio(sum('total_savings_amount', r => g(r) && (r.employer_group_key === 'null' || !group[r.employer_group_key])) * 100n, sav, 4) }]; })); };
const combo = f => audience(r => f(r) ? 'in' : 'out').in;
const y25 = r => r.date_key.startsWith('2025'), isLob = n => r => lob[r.lob_key].lob_name === n, isService = n => r => service[r.pi_service_key].pi_service_name === n;
// Added 2026-10-07 for the Analytic Detail and Provider Detail drill-through pages (V26-V27).
const detail = f => { const R = F.filter(f), sav = sum('total_savings_amount', f), bySvc = {}; for (const r of R) { const k = service[r.pi_service_key].pi_service_name; bySvc[k] = (bySvc[k] || 0n) + cents(r.total_savings_amount); }
  const top = Object.entries(bySvc).sort((a, b) => (b[1] > a[1] ? 1 : -1))[0];
  return Object.assign(combo(f), { share_of_all_savings_pct: ratio(sav * 100n, S, 4), services_with_rows: Object.keys(bySvc).length, top_service: top[0], top_service_savings: money(top[1]), top_service_share_pct: ratio(top[1] * 100n, sav, 4),
    flags: { not_yet_valid: R.filter(notValid).length, route_disagrees: R.filter(routeDisagrees).length, group_client_mismatch: R.filter(groupClientDiffers).length } }); };
const isAnalytic = c => r => analytic[r.analytic_key].analytic_code === c, isNpi = n => r => provider[r.provider_key].provider_npi === n;
// Added 2026-10-07 for the Explore page (V28).
const claimType = by(csv('dim_claim_type.csv'), 'claim_type_key');
const out = {
  V01_rows: F.length,
  V02_total_savings: money(S),
  V03: { pre_pay: money(sum('pre_pay_savings_amount')), post_pay: money(sum('post_pay_savings_amount')), rows_where_pre_plus_post_differs: count(r => cents(r.pre_pay_savings_amount) + cents(r.post_pay_savings_amount) !== cents(r.total_savings_amount)) },
  V04: { billed: money(sum('total_billed_amount')), paid: money(sum('total_paid_amount')) },
  V05: { submitted: F.reduce((a, r) => a + parseInt(r.total_claims_submitted_amount), 0), pre_edit_allowed: F.reduce((a, r) => a + parseInt(r.total_claims_pre_edit_allowed_amount), 0), processed: F.reduce((a, r) => a + parseInt(r.total_claims_processed_amount), 0), rows_with_fraction: count(r => !/^\d+\.00$/.test(r.total_claims_submitted_amount + '') || !/^\d+\.00$/.test(r.total_claims_pre_edit_allowed_amount) || !/^\d+\.00$/.test(r.total_claims_processed_amount)) },
  V06_rows_with_matching_date: count(r => dates.has(iso(r))),
  V07_by_year: groupBy(r => r.date_key.slice(0, 4)),
  V08_by_service: groupBy(r => service[r.pi_service_key].pi_service_name),
  V09_empty_employer_group_key: count(r => r.employer_group_key === 'null'),
  V10_by_group_bucket: groupBy(r => r.employer_group_key === 'null' ? 'Not supplied' : group[r.employer_group_key] ? 'In lookup' : 'Not in lookup'),
  V11_by_client: groupBy(r => client[r.client_key].client_name),
  V12_AN0007: groupBy(r => analytic[r.analytic_key].analytic_code)['AN-0007'],
  V13_sunrise_npi_1567892341: groupBy(r => provider[r.provider_key].provider_npi)['1567892341'],
  V14: { simple_pct: (tpr.reduce((a, b) => a + b, 0) / F.length).toFixed(4), savings_weighted_pct: (F.reduce((a, r) => a + parseFloat(r.true_positive_rate_pct) * Number(cents(r.total_savings_amount)), 0) / Number(S)).toFixed(4) },
  V15: (f => ({ rows: count(f), savings: money(sum('total_savings_amount', f)) }))(r => client[r.client_key].client_name === 'State Medicaid Agency' && lob[r.lob_key].lob_name === 'Medicaid' && r.date_key.startsWith('2024')),
  issue_checks: { rows_on_not_yet_valid_version: count(notValid), rows_route_disagrees: count(routeDisagrees), rows_group_client_mismatch: count(groupClientDiffers) },
  V16: (f => ({ rows: count(f), savings: money(sum('total_savings_amount', f)) }))(r => client[r.client_key].client_name === 'HealthFirst Employer Trust' && lob[r.lob_key].lob_name === 'Commercial' && funding[r.funding_type_key].funding_type_code === 'ASO' && r.date_key.startsWith('2025')),
  time_intelligence: { ytd_at_jun_2025: money(sum('total_savings_amount', r => r.date_key >= '20250101' && r.date_key <= '20250630')), prior_year_for_2025: money(sum('total_savings_amount', r => r.date_key.startsWith('2024'))) },
  drill_through: Object.fromEntries(['Coordination of Benefits', 'Prepayment Claim Editing', 'DRG Validation'].map(name => { const f = r => service[r.pi_service_key].pi_service_name === name; return [name, { rows: count(f), savings: money(sum('total_savings_amount', f)), rows_on_not_yet_valid_version: count(r => f(r) && notValid(r)), rows_route_disagrees: count(r => f(r) && routeDisagrees(r)), rows_group_client_mismatch: count(r => f(r) && groupClientDiffers(r)), with_year_2025: { rows: count(r => f(r) && r.date_key.startsWith('2025')), savings: money(sum('total_savings_amount', r => f(r) && r.date_key.startsWith('2025'))) }, by_analytic_code: (() => { const m = {}; for (const r of F.filter(f)) { const k = analytic[r.analytic_key].analytic_code; m[k] = (m[k] || 0n) + cents(r.total_savings_amount); } return Object.fromEntries(Object.entries(m).sort().map(([k, v]) => [k, money(v)])); })() }]; })),
  V21_savings_pct_of_paid: ratio(S * 100n, sum('total_paid_amount'), 4),
  V22_savings_per_processed_claim: ratio(S, 100 * intSum('total_claims_processed_amount'), 4),
  V23_by_analytic_code: audience(r => analytic[r.analytic_key].analytic_code),
  V24_by_lob_and_funding_type: Object.assign(audience(r => lob[r.lob_key].lob_name + ' | ' + funding[r.funding_type_key].funding_type_name), audience(r => 'ALL | ' + funding[r.funding_type_key].funding_type_name)),
  V25_by_client: audience(r => client[r.client_key].client_name),
  V26_analytic_detail: { 'AN-0001': detail(isAnalytic('AN-0001')), 'AN-0001 + Year 2025': detail(r => isAnalytic('AN-0001')(r) && y25(r)), 'AN-0005': detail(isAnalytic('AN-0005')), 'AN-0006': detail(isAnalytic('AN-0006')) },
  V27_provider_detail: { 'NPI 1567892341 (Sunrise)': detail(isNpi('1567892341')), 'NPI 1567892341 + Year 2025': detail(r => isNpi('1567892341')(r) && y25(r)), 'NPI 1567892341 + AN-0001': detail(r => isNpi('1567892341')(r) && isAnalytic('AN-0001')(r)), 'NPI 1567892341 + AN-0007': detail(r => isNpi('1567892341')(r) && isAnalytic('AN-0007')(r)), 'NPI 1567892341 + Prepayment Claim Editing': detail(r => isNpi('1567892341')(r) && isService('Prepayment Claim Editing')(r)), 'NPI 1932345670 (Riverside)': detail(isNpi('1932345670')) },
  V28_explore_page: { by_service: audience(r => service[r.pi_service_key].pi_service_name), by_lob: audience(r => lob[r.lob_key].lob_name), by_claim_type: audience(r => claimType[r.claim_type_key].claim_type_name), by_year: audience(r => r.date_key.slice(0, 4)),
    by_service_and_lob: audience(r => service[r.pi_service_key].pi_service_name + ' | ' + lob[r.lob_key].lob_name), year_2025_by_service: Object.fromEntries(Object.entries(audience(r => (y25(r) ? '' : 'other years: ') + service[r.pi_service_key].pi_service_name)).filter(([k]) => !k.startsWith('other'))) },
  F11_detail_pages_with_synced_slicers: { 'Year 2025': detail(y25), 'Year 2025 + Medicaid': detail(r => y25(r) && isLob('Medicaid')(r)) },
  F10_slicer_combinations: { 'Year 2025': combo(y25), 'Year 2025 + Medicaid': combo(r => y25(r) && isLob('Medicaid')(r)), 'Year 2025 + Medicaid + Fully Insured': combo(r => y25(r) && isLob('Medicaid')(r) && funding[r.funding_type_key].funding_type_name === 'Fully Insured'),
    'Prepayment Claim Editing': combo(isService('Prepayment Claim Editing')), 'Year 2025 + Prepayment Claim Editing': combo(r => y25(r) && isService('Prepayment Claim Editing')(r)) },
};
console.log(JSON.stringify(out, null, 2));

// Row lists for the validation sheet (fact row numbers = pi_measures_key). Printed with:  node scripts/expected-values.js --rows
if (process.argv.includes('--rows')) {
  const keys = f => F.filter(f).map(r => +r.pi_measures_key).sort((a, b) => a - b).join(',');
  console.log(JSON.stringify({
    not_yet_valid_version: keys(notValid),
    group_client_mismatch: keys(groupClientDiffers),
    route_disagrees: keys(routeDisagrees),
    group_not_in_lookup: keys(r => r.employer_group_key !== 'null' && !group[r.employer_group_key]),
  }, null, 2));
}
