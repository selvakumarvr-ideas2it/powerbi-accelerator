# Open, close or inspect Power BI Desktop (Microsoft Store version) for this project.
#   .\scripts\pbi.ps1 open            open CentenePI.pbip and wait until it has loaded
#   .\scripts\pbi.ps1 status          list running instances and any dialogs in front of them
#   .\scripts\pbi.ps1 capture -OutDir X   save a PNG of each Power BI Desktop window into folder X
#   .\scripts\pbi.ps1 close           ask every instance to close (same as clicking X)
#   .\scripts\pbi.ps1 close -Force    end the processes; unsaved changes are lost
param(
    [Parameter(Mandatory)][ValidateSet('open', 'close', 'status', 'capture')][string]$Action,
    [string]$Project,
    [int]$TimeoutSeconds = 90,
    [switch]$Force,
    [string]$OutDir = $env:TEMP
)

if (-not $Project) { $Project = Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) '..\CentenePI.pbip' }

Add-Type @"
using System; using System.Text; using System.Collections.Generic; using System.Runtime.InteropServices;
public class PbiWin {
    public delegate bool EnumProc(IntPtr h, IntPtr l);
    [StructLayout(LayoutKind.Sequential)] public struct RECT { public int L, T, R, B; }
    [DllImport("user32.dll")] public static extern bool EnumWindows(EnumProc cb, IntPtr l);
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
    [DllImport("user32.dll")] public static extern bool IsWindowVisible(IntPtr h);
    [DllImport("user32.dll")] public static extern bool IsWindowEnabled(IntPtr h);
    [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr h, out RECT r);
    [DllImport("user32.dll")] public static extern bool PrintWindow(IntPtr h, IntPtr hdc, uint flags);
    public static List<IntPtr> Handles(uint target) {
        var r = new List<IntPtr>();
        EnumWindows((h, l) => { uint pid; GetWindowThreadProcessId(h, out pid); if (pid == target && IsWindowVisible(h)) r.Add(h); return true; }, IntPtr.Zero);
        return r;
    }
    [DllImport("user32.dll", CharSet=CharSet.Unicode)] public static extern int GetWindowText(IntPtr h, StringBuilder s, int n);
    public static List<string> List(uint target) {
        var r = new List<string>();
        EnumWindows((h, l) => {
            uint pid; GetWindowThreadProcessId(h, out pid);
            if (pid == target && IsWindowVisible(h)) {
                var sb = new StringBuilder(256); GetWindowText(h, sb, 256);
                RECT rc; GetWindowRect(h, out rc);
                r.Add((rc.R - rc.L) + "x" + (rc.B - rc.T) + " enabled=" + IsWindowEnabled(h) + " '" + sb + "'");
            }
            return true;
        }, IntPtr.Zero);
        return r;
    }
}
"@

function Get-Pbi { Get-Process -Name 'PBIDesktop' -ErrorAction SilentlyContinue }

# Power BI Desktop opens a Windows "Work or school account" sign-in window at start-up and waits behind it
# ("Working on it"). The project needs no sign-in, so close that window (the same as clicking X; nothing is entered).
function Close-SignInWindows {
    Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes
    $scope = [System.Windows.Automation.TreeScope]; $el = [System.Windows.Automation.AutomationElement]
    $isSignIn = New-Object System.Windows.Automation.PropertyCondition($el::NameProperty, 'Work or school account')
    $closed = 0
    $frames = $el::RootElement.FindAll($scope::Children, [System.Windows.Automation.Condition]::TrueCondition) |
        Where-Object { $_.Current.ClassName -eq 'ApplicationFrameWindow' }
    foreach ($w in $frames) {
        if (-not $w.FindFirst($scope::Descendants, $isSignIn)) { continue }
        $wp = $null
        if ($w.TryGetCurrentPattern([System.Windows.Automation.WindowPattern]::Pattern, [ref]$wp)) { $wp.Close(); $closed++ }
    }
    $closed
}

function Show-Status {
    $procs = Get-Pbi
    if (-not $procs) { 'Power BI Desktop is not running'; return }
    foreach ($p in $procs) {
        "PID $($p.Id): '$($p.MainWindowTitle)' responding=$($p.Responding)"
        # More than one window means a dialog is in front; the main window is disabled while it is.
        [PbiWin]::List([uint32]$p.Id) | ForEach-Object { "    window $_" }
    }
}

switch ($Action) {
    'open' {
        $path = (Resolve-Path $Project).Path
        $name = [IO.Path]::GetFileNameWithoutExtension($path)
        Start-Process "$env:LOCALAPPDATA\Microsoft\WindowsApps\PBIDesktopStore.exe" -ArgumentList "`"$path`""
        $sw = [Diagnostics.Stopwatch]::StartNew()
        $loaded = $false
        $signIns = 0
        while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
            if (Get-Pbi | Where-Object { $_.MainWindowTitle -like "$name*" }) { $loaded = $true; break }
            $signIns += Close-SignInWindows
            Start-Sleep -Seconds 2
        }
        "Loaded: $loaded after $([int]$sw.Elapsed.TotalSeconds)s (sign-in windows closed: $signIns)"
        Show-Status
    }
    'close' {
        foreach ($p in Get-Pbi) {
            if ($Force) { Stop-Process -Id $p.Id -Force; "PID $($p.Id): ended"; continue }
            $sent = $p.CloseMainWindow()
            $exited = $p.WaitForExit(30000)
            "PID $($p.Id): close requested=$sent exited=$exited"
        }
        Start-Sleep -Seconds 2
        Show-Status
    }
    'status' { Show-Status }
    'capture' {
        Add-Type -AssemblyName System.Drawing
        foreach ($p in Get-Pbi) {
            $i = 0
            foreach ($h in [PbiWin]::Handles([uint32]$p.Id)) {
                $rc = New-Object PbiWin+RECT
                [void][PbiWin]::GetWindowRect($h, [ref]$rc)
                $w = $rc.R - $rc.L; $ht = $rc.B - $rc.T
                if ($w -lt 100 -or $ht -lt 50) { continue }
                $bmp = New-Object System.Drawing.Bitmap $w, $ht
                $g = [System.Drawing.Graphics]::FromImage($bmp)
                $hdc = $g.GetHdc(); [void][PbiWin]::PrintWindow($h, $hdc, 2); $g.ReleaseHdc($hdc); $g.Dispose()
                $file = Join-Path $OutDir "pbi_$($p.Id)_$i.png"
                $bmp.Save($file); $bmp.Dispose()
                "${w}x${ht} -> $file"
                $i++
            }
        }
    }
}
